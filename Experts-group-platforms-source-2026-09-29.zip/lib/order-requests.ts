import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { getDb } from "../db";
import { repairParts, stockRequests } from "../db/schema";

export async function allocateReceivedQuantity(input: { productId: number; shop: string; quantity: number }) {
  let available = Math.max(0, Math.round(input.quantity));
  if (!available) return { allocated: 0, remaining: 0 };
  const db = getDb(); const initial = available;
  const repairRows = await db.select().from(repairParts)
    .where(and(eq(repairParts.productId, input.productId), eq(repairParts.shop, input.shop), inArray(repairParts.status, ["À commander", "Demandée"])))
    .orderBy(asc(repairParts.id));
  for (const row of repairRows.filter((item) => !["Reçue / Clôturée", "Annulée"].includes(item.orderStatus))) {
    if (!available) break;
    const missing = Math.max(0, row.quantity - row.receivedQuantity); if (!missing) continue;
    const assigned = Math.min(missing, available); const receivedQuantity = row.receivedQuantity + assigned; const complete = receivedQuantity >= row.quantity;
    await db.update(repairParts).set({
      receivedQuantity, orderStatus: complete ? "Reçue / Clôturée" : "Partiellement reçue",
      status: complete ? "Reçue" : row.status, reservedQuantity: complete ? row.quantity : row.reservedQuantity,
      flow: complete ? "Stock local" : row.flow, updatedAt: sql`CURRENT_TIMESTAMP`,
    }).where(eq(repairParts.id, row.id));
    available -= assigned;
  }
  const stockRows = await db.select().from(stockRequests)
    .where(and(eq(stockRequests.productId, input.productId), eq(stockRequests.shop, input.shop)))
    .orderBy(asc(stockRequests.id));
  for (const row of stockRows.filter((item) => !["Reçue / Clôturée", "Annulée"].includes(item.orderStatus))) {
    if (!available) break;
    const missing = Math.max(0, row.quantity - row.receivedQuantity); if (!missing) continue;
    const assigned = Math.min(missing, available); const receivedQuantity = row.receivedQuantity + assigned;
    await db.update(stockRequests).set({ receivedQuantity, orderStatus: receivedQuantity >= row.quantity ? "Reçue / Clôturée" : "Partiellement reçue", updatedAt: sql`CURRENT_TIMESTAMP` }).where(eq(stockRequests.id, row.id));
    available -= assigned;
  }
  return { allocated: initial - available, remaining: available };
}
