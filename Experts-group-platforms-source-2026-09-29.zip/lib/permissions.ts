export const permissionGroups = [
  { label: "Réparations", items: [["repairs.view", "Voir les réparations"], ["repairs.create", "Ajouter une réparation"], ["repairs.edit", "Modifier une fiche"], ["repairs.status", "Changer le statut / livrer"], ["repairs.payments", "Enregistrer les paiements"], ["repairs.cancel", "Annuler une opération"]] },
  { label: "Ventes", items: [["sales.use", "Effectuer une vente"], ["sales.view", "Voir le journal"], ["sales.discount", "Accorder une remise"], ["sales.cancel", "Annuler / corriger une vente"]] },
  { label: "Stock & achats", items: [["stock.view", "Voir le stock"], ["stock.edit", "Modifier le stock"], ["stock.purchase_price", "Voir le prix d’achat"], ["orders.view", "Voir les commandes"], ["orders.manage", "Préparer les commandes"], ["purchases.view", "Voir les achats"], ["purchases.manage", "Ajouter / modifier les achats"]] },
  { label: "Caisse & gestion", items: [["cash.view", "Voir les caisses"], ["cash.manage", "Mouvements et transferts"], ["customers.manage", "Gérer les clients"], ["suppliers.manage", "Gérer les fournisseurs"], ["profits.view", "Voir bénéfices et statistiques"]] },
  { label: "Administration", items: [["global.view", "Accéder à la vue globale"], ["printing.use", "Imprimer les documents"], ["settings.manage", "Modifier les paramètres"], ["users.manage", "Gérer les utilisateurs"]] },
] as const;

export const allPermissionCodes = permissionGroups.flatMap((group) => group.items.map(([code]) => code));
export type PermissionCode = typeof allPermissionCodes[number];

export const rolePresets: Record<string, string[]> = {
  "Administrateur général": [...allPermissionCodes],
  "Responsable magasin": allPermissionCodes.filter((code) => !["users.manage", "settings.manage", "global.view"].includes(code)),
  "Réception / Réparateur": ["repairs.view", "repairs.create", "repairs.edit", "repairs.status", "repairs.payments", "stock.view", "orders.view", "orders.manage", "customers.manage", "printing.use"],
  "Vendeur": ["sales.use", "sales.view", "stock.view", "customers.manage", "cash.view", "printing.use"],
};

export function parseStringList(value: string) {
  try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed.map(String) : []; } catch { return []; }
}
