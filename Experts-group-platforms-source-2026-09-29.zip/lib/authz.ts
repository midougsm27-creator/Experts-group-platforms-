import { and, count, eq, or, sql } from "drizzle-orm";
import { getDb } from "../db";
import { appUsers, auditLogs } from "../db/schema";
import { allPermissionCodes, parseStringList } from "./permissions";

export type CurrentUser = { id: number; email: string; name: string; role: string; shops: string[]; permissions: string[]; active: boolean; protected: boolean };
export class AuthError extends Error { constructor(message: string, public status = 403) { super(message); } }

function identity(request: Request) {
  const externalUserId = request.headers.get("oai-authenticated-user-id")?.trim() ?? "";
  const email = request.headers.get("oai-authenticated-user-email")?.trim().toLowerCase() ?? "";
  let name = email;
  const encodedName = request.headers.get("oai-authenticated-user-full-name");
  if (encodedName && request.headers.get("oai-authenticated-user-full-name-encoding") === "percent-encoded-utf-8") try { name = decodeURIComponent(encodedName); } catch {}
  if (!externalUserId || !email) throw new AuthError("Authentification requise.", 401);
  return { externalUserId, email, name: name || email };
}

function present(row: typeof appUsers.$inferSelect): CurrentUser {
  return { id: row.id, email: row.email, name: row.name, role: row.role, shops: parseStringList(row.shops), permissions: parseStringList(row.permissions), active: row.active, protected: row.protected };
}

export async function getCurrentUser(request: Request, bootstrap = false) {
  const who = identity(request); const db = getDb();
  let row = (await db.select().from(appUsers).where(or(eq(appUsers.externalUserId, who.externalUserId), eq(appUsers.email, who.email))).limit(1))[0];
  if (!row && bootstrap) {
    const [{ total }] = await db.select({ total: count() }).from(appUsers);
    if (total === 0) row = (await db.insert(appUsers).values({ externalUserId: who.externalUserId, email: who.email, name: who.name || "Mohamed", role: "Administrateur général", shops: JSON.stringify(["ProPhone", "MidouGSM"]), permissions: JSON.stringify(allPermissionCodes), protected: true, lastSeenAt: sql`CURRENT_TIMESTAMP` }).returning())[0];
  }
  if (row && !row.externalUserId) { row = (await db.update(appUsers).set({ externalUserId: who.externalUserId, lastSeenAt: sql`CURRENT_TIMESTAMP`, updatedAt: sql`CURRENT_TIMESTAMP` }).where(and(eq(appUsers.id, row.id), eq(appUsers.email, who.email))).returning())[0]; }
  else if (row) await db.update(appUsers).set({ lastSeenAt: sql`CURRENT_TIMESTAMP` }).where(eq(appUsers.id, row.id));
  if (!row) throw new AuthError("Votre compte n’est pas encore autorisé.", 403);
  if (!row.active) throw new AuthError("Ce compte est désactivé.", 403);
  return present(row);
}

export async function requirePermission(request: Request, permission?: string) {
  const user = await getCurrentUser(request, true);
  if (permission && !user.permissions.includes(permission)) throw new AuthError("Vous n’avez pas cette autorisation.", 403);
  return user;
}

export function assertShop(user: CurrentUser, shop: string) {
  if (shop !== "all" && !user.shops.includes(shop)) throw new AuthError("Ce magasin n’est pas autorisé.", 403);
  if (shop === "all" && !user.permissions.includes("global.view")) throw new AuthError("La vue globale n’est pas autorisée.", 403);
}

export async function audit(user: CurrentUser, input: { shop?: string; action: string; entityType: string; entityId?: string | number; details?: unknown }) {
  await getDb().insert(auditLogs).values({ userId: user.id, userEmail: user.email, shop: input.shop ?? "", action: input.action, entityType: input.entityType, entityId: String(input.entityId ?? ""), details: input.details === undefined ? "" : JSON.stringify(input.details) });
}

export function authErrorResponse(error: unknown, fallback: string) {
  if (error instanceof AuthError) return Response.json({ error: error.message }, { status: error.status });
  return Response.json({ error: error instanceof Error ? error.message : fallback }, { status: 500 });
}
