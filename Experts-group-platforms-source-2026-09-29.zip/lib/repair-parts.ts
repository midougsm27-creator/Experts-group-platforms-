import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { getDb } from "../db";
import { products, repairParts, repairs, stockMovements } from "../db/schema";

export const partStatuses = ["Demandée", "Réservée", "À commander", "Reçue", "Utilisée", "Non utilisée"] as const;
export type PartStatus = (typeof partStatuses)[number];

export async function stockForProduct(productId: number, shop: string) {
  const db = getDb();
  const [physicalRow] = await db.select({ value: sql<number>`coalesce(sum(${stockMovements.quantity}), 0)` })
    .from(stockMovements).where(and(eq(stockMovements.productId, productId), eq(stockMovements.shop, shop)));
  const [reservedRow] = await db.select({ value: sql<number>`coalesce(sum(${repairParts.reservedQuantity}), 0)` })
    .from(repairParts).where(and(eq(repairParts.productId, productId), eq(repairParts.shop, shop), inArray(repairParts.status, ["Réservée", "Reçue"])));
  const physical = Number(physicalRow?.value ?? 0);
  const reserved = Number(reservedRow?.value ?? 0);
  return { physical, reserved, available: physical - reserved };
}

export async function addPartToRepair(input: { repairId: number; productId: number; quantity: number; quality?: string }) {
  const db = getDb();
  const [repair] = await db.select().from(repairs).where(eq(repairs.id, input.repairId)).limit(1);
  const [product] = await db.select().from(products).where(eq(products.id, input.productId)).limit(1);
  if (!repair || !product) throw new Error("Réparation ou produit introuvable.");
  const quantity = Math.max(1, Math.round(input.quantity));
  const local = await stockForProduct(product.id, repair.shop);
  let status: PartStatus = "Réservée";
  let reservedQuantity = quantity;
  let flow = "Stock local";
  if (local.available < quantity) {
    status = "À commander";
    reservedQuantity = 0;
    if (repair.shop === "MidouGSM") {
      const proPhone = await stockForProduct(product.id, "ProPhone");
      flow = proPhone.available >= quantity ? "Demande ProPhone" : "Commande fournisseur";
    } else {
      flow = "Commande fournisseur";
    }
  }
  const [priceRow] = await db.select({ salePrice: stockMovements.salePrice }).from(stockMovements)
    .where(and(eq(stockMovements.productId, product.id), eq(stockMovements.shop, repair.shop)))
    .orderBy(desc(stockMovements.id)).limit(1);
  const [created] = await db.insert(repairParts).values({
    repairId: repair.id, productId: product.id, shop: repair.shop, itemName: product.name,
    quality: input.quality?.trim() || product.quality, quantity, reservedQuantity,
    unitPrice: priceRow?.salePrice ?? 0, status, flow,
  }).returning();
  return created;
}

export async function markPartUnused(partId: number) {
  const db = getDb();
  const [part] = await db.select().from(repairParts).where(eq(repairParts.id, partId)).limit(1);
  if (!part) throw new Error("Pièce introuvable.");
  if (part.status === "Utilisée" && part.productId) {
    await db.insert(stockMovements).values({
      productId: part.productId, shop: part.shop, movementType: "Retour réparation",
      quantity: part.quantity, salePrice: part.unitPrice, reference: `REP-${part.repairId}`,
      repairId: part.repairId,
    });
  }
  const [updated] = await db.update(repairParts).set({ status: "Non utilisée", reservedQuantity: 0, updatedAt: sql`CURRENT_TIMESTAMP` })
    .where(eq(repairParts.id, partId)).returning();
  return updated;
}

