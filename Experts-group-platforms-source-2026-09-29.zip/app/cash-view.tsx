"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { ArrowDownLeft, ArrowRightLeft, ArrowUpRight, History, Landmark, Pencil, Plus, ShieldCheck, Store, WalletCards } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type ActiveShop = "all" | "ProPhone" | "MidouGSM";
type Cashbox = { id: number; shop: string; name: string; type: string; openingBalance: number; balance: number; active: boolean };
type Movement = { id: number; cashboxId: number; cashboxName: string; shop: string; direction: string; movementType: string; amount: number; reason: string; reference: string; createdAt: string };

function money(value: number) { return new Intl.NumberFormat("fr-DZ").format(value) + " DA"; }

export function CashView({ activeShop }: { activeShop: ActiveShop }) {
  const [cashboxes, setCashboxes] = useState<Cashbox[]>([]);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [editingBox, setEditingBox] = useState<Cashbox | null>(null);
  const [movementOpen, setMovementOpen] = useState(false);
  const [movementCashboxId, setMovementCashboxId] = useState<number | null>(null);
  const [transferOpen, setTransferOpen] = useState(false);
  const [transferSourceId, setTransferSourceId] = useState<number | null>(null);
  const [transferDestinationId, setTransferDestinationId] = useState<number | null>(null);
  const [transferAmount, setTransferAmount] = useState("");
  const [emptySource, setEmptySource] = useState(false);

  const loadCash = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/cash?shop=all");
      const data = await response.json() as { cashboxes: Cashbox[]; movements: Movement[]; error?: string };
      if (!response.ok) throw new Error(data.error);
      setCashboxes(data.cashboxes); setMovements(data.movements);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Caisses indisponibles."); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void loadCash(); }, [loadCash]);

  const visibleBoxes = useMemo(() => activeShop === "all" ? cashboxes : cashboxes.filter((box) => box.shop === activeShop), [activeShop, cashboxes]);
  const visibleMovements = useMemo(() => activeShop === "all" ? movements : movements.filter((movement) => movement.shop === activeShop), [activeShop, movements]);
  const total = visibleBoxes.reduce((sum, box) => sum + box.balance, 0);
  const todayIn = visibleMovements.filter((item) => item.direction === "in").reduce((sum, item) => sum + item.amount, 0);
  const todayOut = visibleMovements.filter((item) => item.direction === "out").reduce((sum, item) => sum + item.amount, 0);

  function requireShop(next: () => void) {
    if (activeShop === "all") return toast.info("Choisissez ProPhone ou MidouGSM pour créer une caisse ou une opération.");
    next();
  }

  async function send(payload: Record<string, unknown>, onDone: () => void, successMessage = "Mouvement de caisse enregistré") {
    setSaving(true);
    try {
      const response = await fetch("/api/cash", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error);
      onDone(); await loadCash(); toast.success(successMessage);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Opération impossible."); }
    finally { setSaving(false); }
  }

  function createCashbox(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (activeShop === "all") return;
    const form = event.currentTarget; const values = Object.fromEntries(new FormData(form).entries());
    void send({ action: "create", shop: activeShop, ...values }, () => { setCreateOpen(false); form.reset(); });
  }

  function updateCashbox(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!editingBox) return;
    const form = event.currentTarget; const values = Object.fromEntries(new FormData(form).entries());
    void send({ action: "update", id: editingBox.id, ...values }, () => setEditingBox(null), "Caisse modifiée");
  }

  function createMovement(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = event.currentTarget; const values = Object.fromEntries(new FormData(form).entries());
    void send({ action: "movement", ...values }, () => { setMovementOpen(false); form.reset(); });
  }

  function openTransfer(source?: Cashbox, transferAll = false) {
    setTransferSourceId(source?.id ?? null); setTransferDestinationId(null); setEmptySource(transferAll); setTransferAmount(transferAll && source ? String(Math.max(0, source.balance)) : ""); setTransferOpen(true);
  }

  function createTransfer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const transfersFullBalance = Boolean(transferSource && Number(transferAmount) === transferSource.balance);
    void send({ action: "transfer", sourceId: transferSourceId, destinationId: transferDestinationId, amount: transferAmount, reason: transfersFullBalance ? "Vidage de caisse" : "Transfert entre caisses" }, () => { setTransferOpen(false); setTransferSourceId(null); setTransferDestinationId(null); setTransferAmount(""); setEmptySource(false); }, transfersFullBalance ? "Caisse vidée vers la caisse choisie" : "Transfert enregistré");
  }

  const transferSource = cashboxes.find((box) => box.id === transferSourceId) ?? null;
  const transferDestinations = cashboxes.filter((box) => box.id !== transferSourceId && (!transferSource || box.shop === transferSource.shop));

  return <section className="content cash-content">
    <div className="page-heading">
      <div><span className="eyebrow">{activeShop === "all" ? "SUPERVISION FINANCIÈRE" : `CAISSES · ${activeShop.toUpperCase()}`}</span><h2>Caisses</h2><p>{activeShop === "all" ? "Soldes consolidés, caisses toujours séparées par magasin." : `Gérez plusieurs caisses propres à ${activeShop}.`}</p></div>
      <div className="heading-actions"><Button variant="outline" onClick={() => openTransfer()} disabled={visibleBoxes.length < 2}><ArrowRightLeft size={17}/> Transfert</Button><Button className="primary-action" onClick={() => requireShop(() => setCreateOpen(true))}><Plus size={18}/> Nouvelle caisse</Button></div>
    </div>

    <div className="metrics cash-metrics">
      <article><span className="metric-icon blue"><WalletCards/></span><div><small>Solde total affiché</small><strong>{money(total)}</strong></div></article>
      <article><span className="metric-icon green"><ArrowDownLeft/></span><div><small>Entrées récentes</small><strong>{money(todayIn)}</strong></div></article>
      <article><span className="metric-icon orange"><ArrowUpRight/></span><div><small>Sorties récentes</small><strong>{money(todayOut)}</strong></div></article>
    </div>

    {activeShop === "all" && <div className="separation-notice"><ShieldCheck size={20}/><div><b>Contrôle global sans fusion</b><span>Chaque solde reste rattaché à son magasin et à sa caisse d’origine.</span></div></div>}

    <div className="cashbox-grid">
      {loading ? <div className="module-empty">Chargement des caisses…</div> : visibleBoxes.length ? visibleBoxes.map((box) => <article className={`cashbox-card ${box.shop === "MidouGSM" ? "midou" : "prophone"}`} key={box.id}><div className="cashbox-top"><span><Landmark size={19}/></span><div><small>{box.shop}</small><h3>{box.name}</h3></div><em>Active</em></div><strong>{money(box.balance)}</strong><p>{box.type}</p><div className="cashbox-actions"><Button variant="outline" size="sm" onClick={() => { setMovementCashboxId(box.id); setMovementOpen(true); }}>Opération</Button><Button variant="outline" size="sm" onClick={() => setEditingBox(box)}><Pencil size={14}/> Modifier</Button><Button variant="outline" size="sm" disabled={box.balance <= 0 || cashboxes.filter((item) => item.shop === box.shop && item.id !== box.id).length === 0} onClick={() => openTransfer(box, true)}><ArrowRightLeft size={14}/> Transférer…</Button></div></article>) : <div className="module-empty"><WalletCards size={35}/><b>Aucune caisse créée</b><span>Choisissez un magasin puis créez sa première caisse.</span></div>}
    </div>

    <section className="panel cash-history"><div className="panel-toolbar"><div><h3>Historique des mouvements</h3><p>Entrées, sorties et transferts avec leur origine.</p></div><History size={20}/></div><div className="table-wrap"><table><thead><tr><th>Date</th><th>Caisse</th><th>Magasin</th><th>Type</th><th>Motif / référence</th><th>Montant</th></tr></thead><tbody>{visibleMovements.length ? visibleMovements.map((movement) => <tr key={movement.id}><td><b>{new Date(movement.createdAt + "Z").toLocaleString("fr-DZ", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</b></td><td>{movement.cashboxName}</td><td><span className={`shop-badge ${movement.shop === "ProPhone" ? "prophone" : "midou"}`}>{movement.shop}</span></td><td>{movement.movementType}</td><td><b>{movement.reason}</b><small>{movement.reference || "Sans référence"}</small></td><td><strong className={movement.direction === "in" ? "amount-in" : "amount-out"}>{movement.direction === "in" ? "+" : "−"}{money(movement.amount)}</strong></td></tr>) : <tr><td colSpan={6} className="empty-row">Aucun mouvement enregistré.</td></tr>}</tbody></table></div></section>

    <Dialog open={createOpen} onOpenChange={setCreateOpen}><DialogContent className="simple-dialog sm:max-w-[520px]"><DialogHeader><DialogTitle>Nouvelle caisse</DialogTitle><DialogDescription>La caisse sera rattachée uniquement à {activeShop}.</DialogDescription></DialogHeader><form onSubmit={createCashbox} className="simple-form"><div className="dialog-branch-line"><Store size={17}/><b>{activeShop}</b><span>Données séparées</span></div><div><Label htmlFor="cash-name">Nom de la caisse *</Label><Input id="cash-name" name="name" required placeholder="Ex. Caisse réparation"/></div><div><Label htmlFor="cash-type">Type</Label><select id="cash-type" name="type"><option>Caisse principale</option><option>Réparation</option><option>Vente accessoires / pièces</option><option>Dépenses</option><option>Point de vente</option></select></div><div><Label htmlFor="opening-balance">Solde initial (DA)</Label><Input id="opening-balance" name="openingBalance" type="number" min="0" defaultValue="0"/></div><div className="dialog-buttons"><Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Annuler</Button><Button className="primary-action" disabled={saving}>{saving ? "Enregistrement…" : "Créer la caisse"}</Button></div></form></DialogContent></Dialog>

    <Dialog open={Boolean(editingBox)} onOpenChange={(open) => { if (!open) setEditingBox(null); }}><DialogContent className="simple-dialog sm:max-w-[520px]"><DialogHeader><DialogTitle>Modifier la caisse</DialogTitle><DialogDescription>Le magasin et l’historique comptable restent inchangés.</DialogDescription></DialogHeader>{editingBox && <form onSubmit={updateCashbox} className="simple-form"><div className="dialog-branch-line"><Store size={17}/><b>{editingBox.shop}</b><span>{money(editingBox.balance)}</span></div><div><Label>Nom de la caisse *</Label><Input name="name" required defaultValue={editingBox.name}/></div><div><Label>Type</Label><select name="type" defaultValue={editingBox.type}><option>Caisse principale</option><option>Réparation</option><option>Vente accessoires / pièces</option><option>Dépenses</option><option>Point de vente</option></select></div><div className="cash-integrity-note"><ShieldCheck size={17}/><span>Le solde ne se modifie pas ici : utilisez une opération ou un transfert pour garder une trace.</span></div><div className="dialog-buttons"><Button type="button" variant="outline" onClick={() => setEditingBox(null)}>Annuler</Button><Button className="primary-action" disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer"}</Button></div></form>}</DialogContent></Dialog>

    <Dialog open={movementOpen} onOpenChange={(open) => { setMovementOpen(open); if (!open) setMovementCashboxId(null); }}><DialogContent className="simple-dialog sm:max-w-[520px]"><DialogHeader><DialogTitle>Nouvelle opération</DialogTitle><DialogDescription>Enregistrez une entrée ou une sortie avec son motif.</DialogDescription></DialogHeader><form onSubmit={createMovement} className="simple-form"><div><Label>Caisse *</Label><select name="cashboxId" required value={movementCashboxId ?? ""} onChange={(event) => setMovementCashboxId(Number(event.target.value) || null)}><option value="" disabled>Choisir…</option>{visibleBoxes.map((box) => <option value={box.id} key={box.id}>{box.name} · {box.shop}</option>)}</select></div><div><Label>Direction *</Label><select name="direction"><option value="in">Entrée</option><option value="out">Sortie</option></select></div><div><Label>Montant (DA) *</Label><Input name="amount" type="number" min="1" required/></div><div><Label>Motif *</Label><Input name="reason" required placeholder="Paiement, dépense, remboursement…"/></div><div><Label>Référence</Label><Input name="reference" placeholder="Ticket, facture ou note"/></div><div className="dialog-buttons"><Button type="button" variant="outline" onClick={() => setMovementOpen(false)}>Annuler</Button><Button className="primary-action" disabled={saving}>Enregistrer</Button></div></form></DialogContent></Dialog>

    <Dialog open={transferOpen} onOpenChange={(open) => { setTransferOpen(open); if (!open) { setTransferSourceId(null); setTransferDestinationId(null); setTransferAmount(""); setEmptySource(false); } }}><DialogContent className="simple-dialog sm:max-w-[560px]"><DialogHeader><DialogTitle>{emptySource ? "Transfert depuis la caisse" : "Transfert entre caisses"}</DialogTitle><DialogDescription>{emptySource ? "Le solde complet est proposé. Modifiez le montant pour effectuer un transfert partiel." : "Le montant sort de la première caisse et entre dans la seconde avec la même référence."}</DialogDescription></DialogHeader><form onSubmit={createTransfer} className="simple-form"><div className="transfer-fields"><div><Label>Caisse source *</Label><select required value={transferSourceId ?? ""} disabled={emptySource} onChange={(event) => { const id = Number(event.target.value) || null; setTransferSourceId(id); setTransferDestinationId(null); setTransferAmount(""); }}><option value="" disabled>Choisir…</option>{visibleBoxes.map((box) => <option value={box.id} key={box.id}>{box.name} · {box.shop} · {money(box.balance)}</option>)}</select></div><ArrowRightLeft size={20}/><div><Label>Caisse destination *</Label><select required value={transferDestinationId ?? ""} onChange={(event) => setTransferDestinationId(Number(event.target.value) || null)}><option value="" disabled>Choisir…</option>{transferDestinations.map((box) => <option value={box.id} key={box.id}>{box.name} · {box.shop}</option>)}</select></div></div><div><Label>Montant (DA) *</Label><Input type="number" min="1" max={transferSource?.balance ?? undefined} required value={transferAmount} onChange={(event) => setTransferAmount(event.target.value)}/>{transferSource && <small className="transfer-balance">Disponible : {money(transferSource.balance)} · vous pouvez transférer une partie ou la totalité</small>}</div><div className="cash-integrity-note"><ShieldCheck size={17}/><span>Le transfert reste dans {transferSource?.shop ?? "le même magasin"} et crée deux mouvements liés dans l’historique.</span></div><div className="dialog-buttons"><Button type="button" variant="outline" onClick={() => setTransferOpen(false)}>Annuler</Button><Button className="primary-action" disabled={saving || !transferSourceId || !transferDestinationId || Number(transferAmount) <= 0}>{saving ? "Transfert…" : "Confirmer le transfert"}</Button></div></form></DialogContent></Dialog>
  </section>;
}
