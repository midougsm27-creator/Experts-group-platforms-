import { desc, eq, sql } from "drizzle-orm";
import { getDb } from "../../../db";
import { appUsers, auditLogs } from "../../../db/schema";
import { audit, authErrorResponse, requirePermission } from "../../../lib/authz";
import { allPermissionCodes, parseStringList, rolePresets } from "../../../lib/permissions";

const validShops = ["ProPhone", "MidouGSM"];
function present(row: typeof appUsers.$inferSelect) { return { ...row, shops: parseStringList(row.shops), permissions: parseStringList(row.permissions) }; }
function validated(body: Record<string, unknown>) {
  const email = String(body.email ?? "").trim().toLowerCase(); const name = String(body.name ?? "").trim(); const role = String(body.role ?? "Employé").trim();
  const shops = Array.isArray(body.shops) ? Array.from(new Set(body.shops.map(String).filter((shop) => validShops.includes(shop)))) : [];
  const permissions = Array.isArray(body.permissions) ? Array.from(new Set(body.permissions.map(String).filter((permission) => allPermissionCodes.includes(permission as never)))) : rolePresets[role] ?? [];
  if (!name || !email.includes("@") || !shops.length) throw new Error("Nom, e-mail et au moins un magasin sont obligatoires.");
  return { email, name, role, shops, permissions, active: body.active === undefined ? true : Boolean(body.active) };
}

export async function GET(request: Request) {
  try {
    await requirePermission(request, "users.manage"); const db = getDb();
    const users = (await db.select().from(appUsers).orderBy(desc(appUsers.protected), appUsers.name)).map(present);
    const logs = await db.select().from(auditLogs).orderBy(desc(auditLogs.id)).limit(60);
    return Response.json({ users, logs }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) { return authErrorResponse(error, "Chargement impossible."); }
}

export async function POST(request: Request) {
  try {
    const actor = await requirePermission(request, "users.manage"); const values = validated(await request.json() as Record<string, unknown>); const db = getDb();
    const created = (await db.insert(appUsers).values({ ...values, shops: JSON.stringify(values.shops), permissions: JSON.stringify(values.permissions) }).returning())[0];
    await audit(actor, { action: "Création utilisateur", entityType: "Utilisateur", entityId: created.id, details: { email: created.email, role: created.role, shops: values.shops, permissions: values.permissions } });
    return Response.json({ user: present(created) }, { status: 201 });
  } catch (error) { const message = error instanceof Error ? error.message : "Ajout impossible."; if (message.includes("UNIQUE")) return Response.json({ error: "Cet e-mail possède déjà un compte." }, { status: 409 }); return authErrorResponse(error, "Ajout impossible."); }
}

export async function PATCH(request: Request) {
  try {
    const actor = await requirePermission(request, "users.manage"); const body = await request.json() as Record<string, unknown>; const id = Number(body.id); if (!Number.isInteger(id)) return Response.json({ error: "Utilisateur invalide." }, { status: 400 });
    const db = getDb(); const existing = (await db.select().from(appUsers).where(eq(appUsers.id, id)).limit(1))[0]; if (!existing) return Response.json({ error: "Utilisateur introuvable." }, { status: 404 });
    if (existing.protected && actor.id !== existing.id) return Response.json({ error: "Le compte administrateur principal est protégé." }, { status: 403 });
    const values = validated({ ...body, email: existing.protected ? existing.email : body.email, active: existing.protected ? true : body.active });
    if (existing.protected && (!values.permissions.includes("users.manage") || !values.permissions.includes("global.view") || values.shops.length !== 2)) return Response.json({ error: "Les accès essentiels de l’administrateur principal ne peuvent pas être retirés." }, { status: 400 });
    const updated = (await db.update(appUsers).set({ ...values, shops: JSON.stringify(values.shops), permissions: JSON.stringify(values.permissions), updatedAt: sql`CURRENT_TIMESTAMP` }).where(eq(appUsers.id, id)).returning())[0];
    await audit(actor, { action: "Modification permissions", entityType: "Utilisateur", entityId: id, details: { before: present(existing), after: present(updated) } });
    return Response.json({ user: present(updated) });
  } catch (error) { const message = error instanceof Error ? error.message : "Modification impossible."; if (message.includes("UNIQUE")) return Response.json({ error: "Cet e-mail possède déjà un compte." }, { status: 409 }); return authErrorResponse(error, "Modification impossible."); }
}
