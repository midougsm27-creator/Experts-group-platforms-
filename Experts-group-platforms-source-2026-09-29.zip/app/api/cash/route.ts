import { and, desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { cashboxes, cashMovements } from "../../../db/schema";

const shops = ["ProPhone", "MidouGSM"];

function errorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "Erreur inattendue";
  return message.includes("no such table") ? "Le module Caisse n’est pas encore initialisé." : message;
}

export async function GET(request: Request) {
  try {
    const db = getDb();
    const shop = new URL(request.url).searchParams.get("shop")?.trim() ?? "all";
    const boxes = await db.select().from(cashboxes).where(shop !== "all" ? eq(cashboxes.shop, shop) : undefined).orderBy(cashboxes.shop, cashboxes.name);
    const movements = await db.select().from(cashMovements).where(shop !== "all" ? eq(cashMovements.shop, shop) : undefined).orderBy(desc(cashMovements.id)).limit(100);
    const balances = new Map<number, number>();
    for (const box of boxes) balances.set(box.id, box.openingBalance);
    const allMovements = await db.select().from(cashMovements);
    for (const movement of allMovements) {
      balances.set(movement.cashboxId, (balances.get(movement.cashboxId) ?? 0) + (movement.direction === "in" ? movement.amount : -movement.amount));
    }
    return Response.json({
      cashboxes: boxes.map((box) => ({ ...box, balance: balances.get(box.id) ?? box.openingBalance })),
      movements: movements.map((movement) => ({ ...movement, cashboxName: boxes.find((box) => box.id === movement.cashboxId)?.name ?? "Caisse" })),
    });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const action = String(body.action ?? "");
    const db = getDb();

    if (action === "create") {
      const shop = String(body.shop ?? "").trim();
      const name = String(body.name ?? "").trim();
      const type = String(body.type ?? "Caisse principale").trim();
      const openingBalance = Math.round(Number(body.openingBalance ?? 0));
      if (!shops.includes(shop) || !name || !Number.isFinite(openingBalance) || openingBalance < 0) {
        return Response.json({ error: "Informations de caisse invalides." }, { status: 400 });
      }
      const created = await db.insert(cashboxes).values({ shop, name, type, openingBalance }).returning();
      return Response.json({ cashbox: created[0] }, { status: 201 });
    }

    if (action === "update") {
      const id = Number(body.id);
      const name = String(body.name ?? "").trim();
      const type = String(body.type ?? "Caisse principale").trim();
      if (!Number.isInteger(id) || id < 1 || !name || !type) return Response.json({ error: "Informations de caisse invalides." }, { status: 400 });
      const existing = (await db.select().from(cashboxes).where(eq(cashboxes.id, id)).limit(1))[0];
      if (!existing) return Response.json({ error: "Caisse introuvable." }, { status: 404 });
      const updated = (await db.update(cashboxes).set({ name, type }).where(eq(cashboxes.id, id)).returning())[0];
      return Response.json({ cashbox: updated });
    }

    if (action === "movement") {
      const cashboxId = Number(body.cashboxId);
      const direction = String(body.direction ?? "");
      const amount = Math.round(Number(body.amount ?? 0));
      const reason = String(body.reason ?? "").trim();
      const reference = String(body.reference ?? "").trim();
      const box = (await db.select().from(cashboxes).where(eq(cashboxes.id, cashboxId)).limit(1))[0];
      if (!box || !["in", "out"].includes(direction) || !Number.isFinite(amount) || amount <= 0 || !reason) {
        return Response.json({ error: "Mouvement de caisse invalide." }, { status: 400 });
      }
      const created = await db.insert(cashMovements).values({ cashboxId, shop: box.shop, direction, movementType: direction === "in" ? "Encaissement" : "Décaissement", amount, reason, reference }).returning();
      return Response.json({ movement: created[0] }, { status: 201 });
    }

    if (action === "transfer") {
      const sourceId = Number(body.sourceId);
      const destinationId = Number(body.destinationId);
      const amount = Math.round(Number(body.amount ?? 0));
      const reason = String(body.reason ?? "Transfert entre caisses").trim();
      if (!Number.isInteger(sourceId) || !Number.isInteger(destinationId) || sourceId === destinationId || !Number.isFinite(amount) || amount <= 0) {
        return Response.json({ error: "Transfert invalide." }, { status: 400 });
      }
      const boxes = await db.select().from(cashboxes);
      const source = boxes.find((box) => box.id === sourceId);
      const destination = boxes.find((box) => box.id === destinationId);
      if (!source || !destination) return Response.json({ error: "Caisse introuvable." }, { status: 404 });
      if (!source.active || !destination.active) return Response.json({ error: "Choisissez deux caisses actives." }, { status: 400 });
      if (source.shop !== destination.shop) return Response.json({ error: "Le transfert entre ProPhone et MidouGSM est interdit. Choisissez deux caisses du même magasin." }, { status: 400 });
      const sourceMovements = await db.select().from(cashMovements).where(eq(cashMovements.cashboxId, sourceId));
      const sourceBalance = source.openingBalance + sourceMovements.reduce((total, item) => total + (item.direction === "in" ? item.amount : -item.amount), 0);
      if (sourceBalance < amount) return Response.json({ error: "Solde insuffisant dans la caisse source." }, { status: 400 });
      const transferGroup = `TRF-${Date.now()}-${crypto.randomUUID().slice(0, 4).toUpperCase()}`;
      await db.batch([
        db.insert(cashMovements).values({ cashboxId: source.id, shop: source.shop, direction: "out", movementType: "Transfert sortant", amount, reason, reference: transferGroup, transferGroup, relatedCashboxId: destination.id }),
        db.insert(cashMovements).values({ cashboxId: destination.id, shop: destination.shop, direction: "in", movementType: "Transfert entrant", amount, reason, reference: transferGroup, transferGroup, relatedCashboxId: source.id }),
      ]);
      return Response.json({ transfer: { reference: transferGroup } }, { status: 201 });
    }

    return Response.json({ error: "Action non reconnue." }, { status: 400 });
  } catch (error) {
    const message = errorMessage(error);
    const status = message.includes("UNIQUE") ? 409 : 500;
    return Response.json({ error: status === 409 ? "Une caisse porte déjà ce nom dans ce magasin." : message }, { status });
  }
}
