import { desc, eq, inArray, like, or } from "drizzle-orm";
import { getDb } from "../../../db";
import { catalogEntries, products, stockMovements } from "../../../db/schema";

function normalizedCode(value: string, fallback: string) {
  const code = value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 3);
  return code || fallback;
}

export async function GET(request: Request) {
  try {
    const db = getDb();
    const parameters = new URL(request.url).searchParams;
    const query = parameters.get("q")?.trim() ?? "";
    const where = query ? or(like(products.name, `%${query}%`), like(products.sku, `%${query}%`), like(products.barcode, `%${query}%`), like(products.sourceReference, `%${query}%`), like(products.brand, `%${query}%`), like(products.model, `%${query}%`), like(products.manufacturer, `%${query}%`)) : undefined;
    const rows = await db.select().from(products).where(where).orderBy(desc(products.id)).limit(150);
    const movements = rows.length ? await db.select().from(stockMovements).where(inArray(stockMovements.productId, rows.map((item) => item.id))) : [];
    return Response.json({ products: rows.map((product) => ({
      ...product,
      suggestedSalePrice: movements
        .filter((movement) => movement.productId === product.id && movement.salePrice > 0)
        .sort((a, b) => b.id - a.id)[0]?.salePrice ?? product.pv1,
      stock: {
        ProPhone: movements.filter((movement) => movement.productId === product.id && movement.shop === "ProPhone").reduce((sum, movement) => sum + movement.quantity, 0),
        MidouGSM: movements.filter((movement) => movement.productId === product.id && movement.shop === "MidouGSM").reduce((sum, movement) => sum + movement.quantity, 0),
      },
    })) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erreur inattendue";
    return Response.json({ error: message.includes("no such table") ? "Le catalogue produits n’est pas encore initialisé." : message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const family = String(body.family ?? "").trim();
    const brand = String(body.brand ?? "").trim();
    if (!name || !family) return Response.json({ error: "Le nom et la famille sont obligatoires." }, { status: 400 });
    const suffix = crypto.randomUUID().replaceAll("-", "").slice(0, 5).toUpperCase();
    const sku = `EG-${normalizedCode(family, "PRD")}-${normalizedCode(brand, "GEN")}-${suffix}`;
    const barcode = `EG${Date.now().toString().slice(-9)}${Math.floor(100 + Math.random() * 900)}`;
    const db = getDb();
    const created = await db.insert(products).values({
      sku, barcode, name, family,
      subfamily: String(body.subfamily ?? "").trim(), brand,
      model: String(body.model ?? "").trim(), compatibility: "",
      quality: String(body.quality ?? "").trim(), manufacturer: String(body.manufacturer ?? "").trim(), color: String(body.color ?? "").trim(),
      sourceReference: String(body.sourceReference ?? "").trim(),
      purchasePrice: cleanPrice(body.purchasePrice), pv1: cleanPrice(body.pv1), pv2: cleanPrice(body.pv2), pv3: cleanPrice(body.pv3),
      capacity: "", unit: "Pièce",
      warranty: String(body.warranty ?? "").trim(), notes: String(body.notes ?? "").trim(),
    }).returning();
    await db.insert(catalogEntries).values({ category: "part", name }).onConflictDoNothing();
    return Response.json({ product: created[0] }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erreur inattendue";
    return Response.json({ error: message.includes("UNIQUE") ? "Ce code produit existe déjà." : message }, { status: message.includes("UNIQUE") ? 409 : 500 });
  }
}

function cleanPrice(value: unknown) {
  const price = Number(value ?? 0);
  return Number.isFinite(price) ? Math.max(0, Math.round(price)) : 0;
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    const name = String(body.name ?? "").trim();
    const family = String(body.family ?? "").trim();
    if (!Number.isInteger(id) || id < 1) return Response.json({ error: "Produit invalide." }, { status: 400 });
    if (!name || !family) return Response.json({ error: "Le nom et la famille sont obligatoires." }, { status: 400 });
    const db = getDb();
    const updated = await db.update(products).set({
      name, family, subfamily: String(body.subfamily ?? "").trim(), brand: String(body.brand ?? "").trim(),
      model: String(body.model ?? "").trim(), quality: String(body.quality ?? "").trim(),
      manufacturer: String(body.manufacturer ?? "").trim(), color: String(body.color ?? "").trim(),
      sourceReference: String(body.sourceReference ?? "").trim(), purchasePrice: cleanPrice(body.purchasePrice),
      pv1: cleanPrice(body.pv1), pv2: cleanPrice(body.pv2), pv3: cleanPrice(body.pv3),
      warranty: String(body.warranty ?? "").trim(), notes: String(body.notes ?? "").trim(),
    }).where(eq(products.id, id)).returning();
    if (!updated.length) return Response.json({ error: "Produit introuvable." }, { status: 404 });
    await db.insert(catalogEntries).values({ category: "part", name }).onConflictDoNothing();
    return Response.json({ product: updated[0] });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erreur inattendue";
    return Response.json({ error: message.includes("UNIQUE") ? "Cette référence existe déjà." : message }, { status: message.includes("UNIQUE") ? 409 : 500 });
  }
}
