import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { catalogEntries, products } from "../../../../db/schema";

type ImportRow = {
  name?: unknown; family?: unknown; subfamily?: unknown; brand?: unknown; model?: unknown;
  quality?: unknown; manufacturer?: unknown; color?: unknown; sourceReference?: unknown;
  purchasePrice?: unknown; pv1?: unknown; pv2?: unknown; pv3?: unknown; warranty?: unknown; notes?: unknown;
};

function clean(value: unknown) { return String(value ?? "").trim(); }
function price(value: unknown) { const parsed = Number(String(value ?? "0").replace(",", ".")); return Number.isFinite(parsed) ? Math.max(0, Math.round(parsed)) : 0; }
function normalizedCode(value: string, fallback: string) {
  const code = value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 3);
  return code || fallback;
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as { rows?: ImportRow[] };
    const rows = Array.isArray(body.rows) ? body.rows.slice(0, 500) : [];
    if (!rows.length) return Response.json({ error: "Le fichier ne contient aucun produit." }, { status: 400 });
    const db = getDb();
    const result = { created: 0, skipped: 0, errors: [] as { line: number; message: string }[] };

    for (let index = 0; index < rows.length; index += 1) {
      const row = rows[index];
      const name = clean(row.name); const family = clean(row.family); const brand = clean(row.brand); const model = clean(row.model); const quality = clean(row.quality);
      if (!name || !family) { result.errors.push({ line: index + 2, message: "Nom et famille obligatoires" }); continue; }
      const duplicate = await db.select({ id: products.id }).from(products).where(and(
        eq(products.name, name), eq(products.family, family), eq(products.brand, brand), eq(products.model, model), eq(products.quality, quality),
      )).limit(1);
      if (duplicate.length) { result.skipped += 1; continue; }

      const suffix = crypto.randomUUID().replaceAll("-", "").slice(0, 5).toUpperCase();
      const sku = `EG-${normalizedCode(family, "PRD")}-${normalizedCode(brand, "GEN")}-${suffix}`;
      const barcode = `EG${Date.now().toString().slice(-9)}${String(index).padStart(3, "0")}${Math.floor(10 + Math.random() * 90)}`;
      await db.insert(products).values({
        sku, barcode, name, family, subfamily: clean(row.subfamily), brand, model, compatibility: "",
        quality, manufacturer: clean(row.manufacturer), color: clean(row.color), sourceReference: clean(row.sourceReference),
        purchasePrice: price(row.purchasePrice), pv1: price(row.pv1), pv2: price(row.pv2), pv3: price(row.pv3),
        capacity: "", unit: "Pièce", warranty: clean(row.warranty), notes: clean(row.notes),
      });
      await db.insert(catalogEntries).values({ category: "part", name }).onConflictDoNothing();
      result.created += 1;
    }
    return Response.json(result, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Import impossible." }, { status: 500 });
  }
}
