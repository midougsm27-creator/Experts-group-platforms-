import { env } from "cloudflare:workers";
import { and, desc, eq, inArray, like, or } from "drizzle-orm";
import { getDb } from "../../../db";
import { cashboxes, cashMovements, products, purchaseLines, purchases, stockMovements, suppliers } from "../../../db/schema";
import { allocateReceivedQuantity } from "../../../lib/order-requests";

type PurchaseLineInput = { productId: number; quantity: number; purchasePrice: number; salePrice: number };
const validShops = ["ProPhone", "MidouGSM"];
const settlementTypes = ["Payé", "À terme", "Partiel"];

function parseForm(form: FormData) {
  return {
    shop: String(form.get("shop") ?? ""), supplierId: Number(form.get("supplierId") ?? 0), supplierInvoice: String(form.get("supplierInvoice") ?? "").trim(),
    notes: String(form.get("notes") ?? "").trim(), status: String(form.get("status") ?? "Confirmé"), settlementType: String(form.get("settlementType") ?? ""),
    discountAmount: Math.max(0, Math.round(Number(form.get("discountAmount") ?? 0))), paidInput: Math.max(0, Math.round(Number(form.get("paidAmount") ?? 0))),
    cashboxId: form.get("cashboxId") ? Number(form.get("cashboxId")) : null, lines: JSON.parse(String(form.get("lines") ?? "[]")) as PurchaseLineInput[], document: form.get("document"),
  };
}

async function validateInput(input: ReturnType<typeof parseForm>) {
  if (!validShops.includes(input.shop) || !Number.isInteger(input.supplierId) || input.supplierId < 1 || !input.lines.length || input.lines.some((line) => !Number.isInteger(line.productId) || line.quantity <= 0 || line.purchasePrice < 0)) throw new Error("Bon de réception invalide.");
  const db = getDb(); const selectedSupplier = (await db.select().from(suppliers).where(eq(suppliers.id, input.supplierId)).limit(1))[0];
  if (!selectedSupplier || selectedSupplier.shop !== input.shop || !selectedSupplier.active) throw new Error("Choisissez un fournisseur actif de ce magasin.");
  const productRows = await db.select().from(products).where(inArray(products.id, input.lines.map((line) => line.productId)));
  if (productRows.length !== new Set(input.lines.map((line) => line.productId)).size) throw new Error("Un produit du bon est introuvable.");
  const grossAmount = input.lines.reduce((sum, line) => sum + Math.round(line.quantity * line.purchasePrice), 0); const discountAmount = Math.min(grossAmount, input.discountAmount); const netAmount = Math.max(0, grossAmount - discountAmount);
  let paidAmount = input.paidInput;
  if (input.status !== "Brouillon") {
    if (!settlementTypes.includes(input.settlementType)) throw new Error("Choisissez Payé, À terme ou Partiel avant de confirmer.");
    if (input.settlementType === "Payé") paidAmount = netAmount;
    if (input.settlementType === "À terme") paidAmount = 0;
    if (input.settlementType === "Partiel" && (paidAmount <= 0 || paidAmount >= netAmount)) throw new Error("Le paiement partiel doit être supérieur à 0 et inférieur au net.");
  }
  let cashbox = null;
  if (input.status !== "Brouillon" && paidAmount > 0) {
    if (!input.cashboxId) throw new Error("Choisissez la caisse utilisée pour le paiement.");
    cashbox = (await db.select().from(cashboxes).where(eq(cashboxes.id, input.cashboxId)).limit(1))[0];
    if (!cashbox || cashbox.shop !== input.shop) throw new Error("Caisse invalide pour ce magasin.");
  }
  return { db, selectedSupplier, productRows, grossAmount, discountAmount, netAmount, paidAmount, cashbox };
}

async function storeDocument(document: FormDataEntryValue | null, shop: string, receiptNumber: string, previous = { key: "", name: "" }) {
  if (!(document instanceof File) || document.size <= 0) return previous;
  const bucket = (env as unknown as { DOCUMENTS?: R2Bucket }).DOCUMENTS; if (!bucket) throw new Error("Archivage des documents indisponible.");
  const key = `purchases/${shop}/${receiptNumber}/${crypto.randomUUID()}-${document.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  await bucket.put(key, document.stream(), { httpMetadata: { contentType: document.type || "application/octet-stream" }, customMetadata: { originalName: document.name, receiptNumber } });
  return { key, name: document.name };
}

export async function GET(request: Request) {
  try {
    const parameters = new URL(request.url).searchParams; const id = Number(parameters.get("id") ?? 0); const db = getDb();
    if (id) {
      const purchase = (await db.select().from(purchases).where(eq(purchases.id, id)).limit(1))[0]; if (!purchase) return Response.json({ error: "Bon introuvable." }, { status: 404 });
      const lines = await db.select().from(purchaseLines).where(eq(purchaseLines.purchaseId, id));
      const supplier = purchase.supplierId ? (await db.select().from(suppliers).where(eq(suppliers.id, purchase.supplierId)).limit(1))[0] : null;
      return Response.json({ purchase, lines, supplier });
    }
    const shop = parameters.get("shop") ?? "all"; const query = parameters.get("q")?.trim() ?? "";
    const clauses = [shop !== "all" ? eq(purchases.shop, shop) : undefined, query ? or(like(purchases.receiptNumber, `%${query}%`), like(purchases.supplier, `%${query}%`), like(purchases.supplierInvoice, `%${query}%`)) : undefined].filter(Boolean);
    const where = clauses.length === 2 ? and(clauses[0], clauses[1]) : clauses[0]; const rows = await db.select().from(purchases).where(where).orderBy(desc(purchases.id)).limit(150);
    return Response.json({ purchases: rows });
  } catch (error) { const message = error instanceof Error ? error.message : "Erreur inattendue"; return Response.json({ error: message.includes("no such table") ? "Le journal des réceptions n’est pas encore initialisé." : message }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    const input = parseForm(await request.formData()); const valid = await validateInput(input); const receiptNumber = `REC-${input.shop === "ProPhone" ? "PRO" : "MID"}-${new Date().getFullYear()}-${String(Date.now()).slice(-7)}`;
    const stored = await storeDocument(input.document, input.shop, receiptNumber); const confirmed = input.status !== "Brouillon";
    const created = (await valid.db.insert(purchases).values({ receiptNumber, supplierId: input.supplierId, supplier: valid.selectedSupplier.name, supplierInvoice: input.supplierInvoice, shop: input.shop, settlementType: confirmed ? input.settlementType : "À terme", cashboxId: confirmed && valid.paidAmount > 0 ? input.cashboxId : null, grossAmount: valid.grossAmount, discountAmount: valid.discountAmount, netAmount: valid.netAmount, paidAmount: confirmed ? valid.paidAmount : 0, notes: input.notes, status: confirmed ? "Confirmé" : "Brouillon", documentKey: stored.key, documentName: stored.name }).returning())[0];
    const statements: any[] = input.lines.flatMap((line) => { const product = valid.productRows.find((item) => item.id === line.productId)!; const rows = [valid.db.insert(purchaseLines).values({ purchaseId: created.id, productId: line.productId, productName: product.name, sku: product.sku, quantity: line.quantity, purchasePrice: Math.round(line.purchasePrice), salePrice: Math.round(line.salePrice || 0), lineTotal: Math.round(line.quantity * line.purchasePrice) })]; if (confirmed) rows.push(valid.db.insert(stockMovements).values({ productId: line.productId, shop: input.shop, location: "Magasin", movementType: "Réception", quantity: line.quantity, purchasePrice: Math.round(line.purchasePrice), unitCost: Math.round(line.purchasePrice), salePrice: Math.round(line.salePrice || 0), reference: receiptNumber }) as never); return rows; });
    if (confirmed && valid.cashbox && valid.paidAmount > 0) statements.push(valid.db.insert(cashMovements).values({ cashboxId: valid.cashbox.id, shop: input.shop, direction: "out", movementType: "Achat", amount: valid.paidAmount, reason: `Achat ${receiptNumber} · ${valid.selectedSupplier.name}`, reference: receiptNumber }) as never);
    await valid.db.batch(statements as [any, ...any[]]);
    if (confirmed) for (const line of input.lines) await allocateReceivedQuantity({ productId: line.productId, shop: input.shop, quantity: line.quantity });
    return Response.json({ purchase: created }, { status: 201 });
  } catch (error) { const message = error instanceof Error ? error.message : "Erreur inattendue"; return Response.json({ error: message.includes("UNIQUE") ? "Numéro de bon déjà utilisé, recommencez." : message }, { status: message.includes("invalide") || message.startsWith("Choisissez") || message.startsWith("Le paiement") ? 400 : 500 }); }
}

export async function PATCH(request: Request) {
  try {
    const form = await request.formData(); const id = Number(form.get("id") ?? 0); if (!Number.isInteger(id) || id < 1) return Response.json({ error: "Bon invalide." }, { status: 400 });
    const input = parseForm(form); const valid = await validateInput(input); const existing = (await valid.db.select().from(purchases).where(eq(purchases.id, id)).limit(1))[0]; if (!existing) return Response.json({ error: "Bon introuvable." }, { status: 404 });
    if (existing.shop !== input.shop) return Response.json({ error: "Le magasin du bon ne peut pas être modifié." }, { status: 400 });
    const oldLines = await valid.db.select().from(purchaseLines).where(eq(purchaseLines.purchaseId, id)); const confirmed = input.status !== "Brouillon";
    const stored = await storeDocument(input.document, input.shop, existing.receiptNumber, { key: existing.documentKey, name: existing.documentName });
    const statements: any[] = [valid.db.update(purchases).set({ supplierId: input.supplierId, supplier: valid.selectedSupplier.name, supplierInvoice: input.supplierInvoice, settlementType: confirmed ? input.settlementType : "À terme", cashboxId: confirmed && valid.paidAmount > 0 ? input.cashboxId : null, grossAmount: valid.grossAmount, discountAmount: valid.discountAmount, netAmount: valid.netAmount, paidAmount: confirmed ? valid.paidAmount : 0, notes: input.notes, status: confirmed ? "Confirmé" : "Brouillon", documentKey: stored.key, documentName: stored.name }).where(eq(purchases.id, id)), valid.db.delete(purchaseLines).where(eq(purchaseLines.purchaseId, id))];
    for (const line of input.lines) { const product = valid.productRows.find((item) => item.id === line.productId)!; statements.push(valid.db.insert(purchaseLines).values({ purchaseId: id, productId: line.productId, productName: product.name, sku: product.sku, quantity: line.quantity, purchasePrice: Math.round(line.purchasePrice), salePrice: Math.round(line.salePrice || 0), lineTotal: Math.round(line.quantity * line.purchasePrice) })); }
    const productIds = Array.from(new Set([...oldLines.map((line) => line.productId), ...input.lines.map((line) => line.productId)])); const allocationDeltas: { productId: number; quantity: number }[] = [];
    for (const productId of productIds) { const oldLine = oldLines.find((line) => line.productId === productId); const newLine = input.lines.find((line) => line.productId === productId); const oldQuantity = existing.status === "Confirmé" ? oldLine?.quantity ?? 0 : 0; const newQuantity = confirmed ? newLine?.quantity ?? 0 : 0; const delta = newQuantity - oldQuantity; if (delta) statements.push(valid.db.insert(stockMovements).values({ productId, shop: input.shop, location: "Magasin", movementType: "Correction réception", quantity: delta, purchasePrice: Math.round(newLine?.purchasePrice ?? oldLine?.purchasePrice ?? 0), unitCost: Math.round(newLine?.purchasePrice ?? oldLine?.purchasePrice ?? 0), salePrice: Math.round(newLine?.salePrice ?? oldLine?.salePrice ?? 0), reference: existing.receiptNumber })); if (delta > 0) allocationDeltas.push({ productId, quantity: delta }); }
    const priorCashMovement = (await valid.db.select().from(cashMovements).where(eq(cashMovements.reference, existing.receiptNumber)).orderBy(desc(cashMovements.id)).limit(1))[0]; const oldCashboxId = existing.cashboxId ?? priorCashMovement?.cashboxId ?? null; const oldPosted = existing.status === "Confirmé" ? existing.paidAmount : 0; const newPosted = confirmed ? valid.paidAmount : 0; const newCashboxId = confirmed && newPosted > 0 ? input.cashboxId : null;
    if (oldCashboxId && oldPosted > 0 && oldCashboxId !== newCashboxId) statements.push(valid.db.insert(cashMovements).values({ cashboxId: oldCashboxId, shop: input.shop, direction: "in", movementType: "Correction achat", amount: oldPosted, reason: `Annulation paiement ${existing.receiptNumber}`, reference: existing.receiptNumber }));
    if (newCashboxId && newPosted > 0 && oldCashboxId !== newCashboxId) statements.push(valid.db.insert(cashMovements).values({ cashboxId: newCashboxId, shop: input.shop, direction: "out", movementType: "Correction achat", amount: newPosted, reason: `Paiement corrigé ${existing.receiptNumber}`, reference: existing.receiptNumber }));
    if (newCashboxId && newCashboxId === oldCashboxId && newPosted !== oldPosted) statements.push(valid.db.insert(cashMovements).values({ cashboxId: newCashboxId, shop: input.shop, direction: newPosted > oldPosted ? "out" : "in", movementType: "Correction achat", amount: Math.abs(newPosted - oldPosted), reason: `Écart paiement ${existing.receiptNumber}`, reference: existing.receiptNumber }));
    await valid.db.batch(statements as [any, ...any[]]);
    for (const delta of allocationDeltas) await allocateReceivedQuantity({ productId: delta.productId, shop: input.shop, quantity: delta.quantity });
    const updated = (await valid.db.select().from(purchases).where(eq(purchases.id, id)).limit(1))[0]; return Response.json({ purchase: updated });
  } catch (error) { const message = error instanceof Error ? error.message : "Modification impossible."; return Response.json({ error: message }, { status: message.includes("invalide") || message.startsWith("Choisissez") || message.startsWith("Le paiement") ? 400 : 500 }); }
}
