import { asc, and, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { catalogEntries } from "../../../db/schema";

const categories = ["deviceType", "brand", "model", "partQuality", "issue", "part", "storageLocation"] as const;
type Category = (typeof categories)[number];

const baseCatalog: Record<Category, { name: string; parent?: string }[]> = {
  deviceType: ["Smartphone", "Tablette", "Téléphone classique", "Montre connectée"].map((name) => ({ name })),
  brand: ["Samsung", "Apple", "Oppo", "Xiaomi", "Redmi", "Realme", "Huawei", "Honor", "Infinix", "Tecno", "Vivo", "Nokia", "OnePlus", "Google", "Motorola"].map((name) => ({ name })),
  model: [
    ["Samsung", "A10"], ["Samsung", "A11"], ["Samsung", "A12"], ["Samsung", "A13"], ["Samsung", "A14"], ["Samsung", "A15"], ["Samsung", "A16"],
    ["Samsung", "A20"], ["Samsung", "A21s"], ["Samsung", "A22"], ["Samsung", "A23"], ["Samsung", "A24"], ["Samsung", "A25"],
    ["Samsung", "A30"], ["Samsung", "A31"], ["Samsung", "A32"], ["Samsung", "A33"], ["Samsung", "A34"], ["Samsung", "A35"],
    ["Samsung", "A50"], ["Samsung", "A51"], ["Samsung", "A52"], ["Samsung", "A53"], ["Samsung", "A54"], ["Samsung", "A55"],
    ["Samsung", "S20"], ["Samsung", "S21"], ["Samsung", "S22"], ["Samsung", "S23"], ["Samsung", "S24"], ["Samsung", "S25"],
    ["Apple", "iPhone 8"], ["Apple", "iPhone X"], ["Apple", "iPhone XR"], ["Apple", "iPhone 11"], ["Apple", "iPhone 12"],
    ["Apple", "iPhone 13"], ["Apple", "iPhone 14"], ["Apple", "iPhone 15"], ["Apple", "iPhone 16"], ["Apple", "iPhone 17"],
    ["Oppo", "A15"], ["Oppo", "A16"], ["Oppo", "A17"], ["Oppo", "A18"], ["Oppo", "A54"], ["Oppo", "A57"], ["Oppo", "A74"],
    ["Xiaomi", "Mi 11"], ["Xiaomi", "Mi 12"], ["Xiaomi", "Mi 13"], ["Redmi", "Note 10"], ["Redmi", "Note 11"], ["Redmi", "Note 12"], ["Redmi", "Note 13"], ["Redmi", "Note 14"],
  ].map(([parent, name]) => ({ parent, name })),
  partQuality: ["Original", "Service Pack", "Original démonté", "OLED", "Soft OLED", "Hard OLED", "INCELL", "TFT", "AAA"].map((name) => ({ name })),
  issue: ["Écran cassé", "Problème de charge", "Ne s’allume pas", "Batterie se décharge", "Problème réseau", "Microphone", "Haut-parleur", "Écouteur interne", "Caméra", "Tactile", "Oxydation"].map((name) => ({ name })),
  part: ["Écran", "Connecteur de charge", "Nappe de charge complète", "Batterie", "Vitre arrière", "Nappe power / volume", "Caméra", "Microphone", "Haut-parleur", "Écouteur interne", "Châssis", "Carte mère"].map((name) => ({ name })),
  storageLocation: ["Comptoir réception", "Tiroir Samsung 1", "Tiroir Samsung 2", "Tiroir Apple", "Tiroir Oppo / Xiaomi", "En attente de pièce", "Chez technicien Mohamed", "Appareils prêts"].map((name) => ({ name })),
};

function normalize(value: unknown) {
  return String(value ?? "").trim().replace(/\s+/g, " ");
}

export async function GET() {
  try {
    const custom = await getDb().select().from(catalogEntries).orderBy(asc(catalogEntries.name));
    const catalog = Object.fromEntries(categories.map((category) => {
      const merged = [...baseCatalog[category], ...custom.filter((entry) => entry.category === category)];
      const unique = Array.from(new Map(merged.map((entry) => [`${(entry.parent ?? "").toLocaleLowerCase()}::${entry.name.toLocaleLowerCase()}`, entry])).values());
      return [category, unique];
    }));
    return Response.json({ catalog });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Catalogue indisponible." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const category = normalize(body.category) as Category;
    const name = normalize(body.name);
    const parent = normalize(body.parent);
    if (!categories.includes(category) || !name || (category === "model" && !parent)) {
      return Response.json({ error: "Informations du catalogue incomplètes." }, { status: 400 });
    }
    const db = getDb();
    const existing = await db.select().from(catalogEntries).where(and(eq(catalogEntries.category, category), eq(catalogEntries.name, name), eq(catalogEntries.parent, parent))).limit(1);
    if (existing.length) return Response.json({ entry: existing[0] });
    const inserted = await db.insert(catalogEntries).values({ category, name, parent }).returning();
    return Response.json({ entry: inserted[0] }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Ajout impossible." }, { status: 500 });
  }
}
