import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { getDb } from "../../../db";
import { products, repairParts, repairs, stockRequests } from "../../../db/schema";

const validShops = ["ProPhone", "MidouGSM"];
const supplierStatuses = ["En attente", "Disponible", "Partiellement disponible", "Indisponible", "Alternative proposée"];
const orderStatuses = ["À commander", "Commandée", "Disponible fournisseur", "Partiellement reçue", "Reçue / Clôturée", "Annulée"];

export async function GET(request: Request) {
  try {
    const shop = new URL(request.url).searchParams.get("shop")?.trim() ?? "all";
    const db = getDb();
    const repairRows = await db.select({
      id: repairParts.id, productId: repairParts.productId, shop: repairParts.shop, itemName: repairParts.itemName,
      quality: repairParts.quality, quantity: repairParts.quantity, receivedQuantity: repairParts.receivedQuantity,
      flow: repairParts.flow, supplierStatus: repairParts.supplierStatus, orderStatus: repairParts.orderStatus,
      ticketNumber: repairs.ticketNumber, family: products.family,
    }).from(repairParts).innerJoin(repairs, eq(repairParts.repairId, repairs.id))
      .leftJoin(products, eq(repairParts.productId, products.id))
      .where(and(shop !== "all" ? eq(repairParts.shop, shop) : undefined, inArray(repairParts.status, ["À commander", "Demandée"])))
      .orderBy(asc(repairParts.id));
    const repairGroups = Array.from(new Set(repairRows.map((row) => `${row.shop}|${row.flow}|${row.productId ?? row.itemName}|${row.supplierStatus}|${row.orderStatus}`))).map((key) => {
      const rows = repairRows.filter((row) => `${row.shop}|${row.flow}|${row.productId ?? row.itemName}|${row.supplierStatus}|${row.orderStatus}` === key);
      return { key: `repair|${key}`, sourceType: "Réparation", ids: rows.map((row) => row.id), shop: rows[0].shop, flow: rows[0].flow, productId: rows[0].productId, itemName: rows[0].itemName, quality: rows[0].quality, family: rows[0].family || "Non classé", quantity: rows.reduce((sum, row) => sum + row.quantity, 0), receivedQuantity: rows.reduce((sum, row) => sum + row.receivedQuantity, 0), supplierStatus: rows[0].supplierStatus, orderStatus: rows[0].orderStatus, tickets: rows.map((row) => row.ticketNumber) };
    });
    const stockRows = await db.select({
      id: stockRequests.id, productId: stockRequests.productId, shop: stockRequests.shop, quantity: stockRequests.quantity,
      receivedQuantity: stockRequests.receivedQuantity, supplierStatus: stockRequests.supplierStatus, orderStatus: stockRequests.orderStatus,
      notes: stockRequests.notes, itemName: products.name, quality: products.quality, family: products.family,
    }).from(stockRequests).innerJoin(products, eq(stockRequests.productId, products.id))
      .where(and(shop !== "all" ? eq(stockRequests.shop, shop) : undefined, inArray(stockRequests.orderStatus, orderStatuses.filter((status) => !["Reçue / Clôturée", "Annulée"].includes(status)))))
      .orderBy(asc(stockRequests.id));
    const stockGroups = Array.from(new Set(stockRows.map((row) => `${row.shop}|${row.productId}|${row.supplierStatus}|${row.orderStatus}`))).map((key) => {
      const rows = stockRows.filter((row) => `${row.shop}|${row.productId}|${row.supplierStatus}|${row.orderStatus}` === key);
      return { key: `stock|${key}`, sourceType: "Stock", ids: rows.map((row) => row.id), shop: rows[0].shop, flow: "Réapprovisionnement magasin", productId: rows[0].productId, itemName: rows[0].itemName, quality: rows[0].quality, family: rows[0].family || "Non classé", quantity: rows.reduce((sum, row) => sum + row.quantity, 0), receivedQuantity: rows.reduce((sum, row) => sum + row.receivedQuantity, 0), supplierStatus: rows[0].supplierStatus, orderStatus: rows[0].orderStatus, tickets: [], notes: rows.map((row) => row.notes).filter(Boolean).join(" · ") };
    });
    return Response.json({ requests: [...repairGroups, ...stockGroups] }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Chargement impossible." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const shop = String(body.shop ?? "");
    const rawLines = Array.isArray(body.lines) ? body.lines : [{ productId: body.productId, quantity: body.quantity, notes: body.notes }];
    const lines = rawLines.map((line) => {
      const value = line as Record<string, unknown>;
      return { productId: Number(value.productId), quantity: Math.round(Number(value.quantity ?? 1)), notes: String(value.notes ?? "").trim() };
    });
    if (!validShops.includes(shop) || !lines.length || lines.some((line) => !Number.isInteger(line.productId) || line.productId < 1 || !Number.isFinite(line.quantity) || line.quantity < 1)) return Response.json({ error: "Produit, magasin ou quantité invalide." }, { status: 400 });
    const db = getDb(); const productIds = Array.from(new Set(lines.map((line) => line.productId)));
    const productRows = await db.select({ id: products.id }).from(products).where(inArray(products.id, productIds));
    if (productRows.length !== productIds.length) return Response.json({ error: "Un produit du bon est introuvable." }, { status: 404 });
    const created = [];
    for (const line of lines) created.push((await db.insert(stockRequests).values({ productId: line.productId, shop, quantity: line.quantity, notes: line.notes }).returning())[0]);
    return Response.json({ requests: created }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Ajout impossible." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>; const sourceType = String(body.sourceType ?? "");
    const ids = Array.isArray(body.ids) ? body.ids.map(Number).filter(Number.isInteger) : [];
    if (!ids.length || !["Réparation", "Stock"].includes(sourceType)) return Response.json({ error: "Demande invalide." }, { status: 400 });
    const changes: { supplierStatus?: string; orderStatus?: string; updatedAt: ReturnType<typeof sql> } = { updatedAt: sql`CURRENT_TIMESTAMP` };
    if (body.supplierStatus !== undefined) { const value = String(body.supplierStatus); if (!supplierStatuses.includes(value)) return Response.json({ error: "État fournisseur invalide." }, { status: 400 }); changes.supplierStatus = value; }
    if (body.orderStatus !== undefined) { const value = String(body.orderStatus); if (!orderStatuses.includes(value)) return Response.json({ error: "État commande invalide." }, { status: 400 }); changes.orderStatus = value; }
    if (!changes.supplierStatus && !changes.orderStatus) return Response.json({ error: "Aucune modification reçue." }, { status: 400 });
    if (sourceType === "Réparation") await getDb().update(repairParts).set(changes).where(inArray(repairParts.id, ids));
    else await getDb().update(stockRequests).set(changes).where(inArray(stockRequests.id, ids));
    return Response.json({ updated: ids.length });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Modification impossible." }, { status: 500 });
  }
}
