import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { cashboxes, cashMovements, customerPayments, customers } from "../../../../../db/schema";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const id = Number((await context.params).id); const body = await request.json() as Record<string, unknown>;
    const amount = Math.round(Number(body.amount ?? 0)); const cashboxId = body.cashboxId ? Number(body.cashboxId) : null;
    if (!Number.isInteger(id) || !Number.isFinite(amount) || amount <= 0) return Response.json({ error: "Montant invalide." }, { status: 400 });
    const db = getDb(); const customer = (await db.select().from(customers).where(eq(customers.id, id)).limit(1))[0];
    if (!customer) return Response.json({ error: "Client introuvable." }, { status: 404 });
    let cashbox = null;
    if (cashboxId) { cashbox = (await db.select().from(cashboxes).where(eq(cashboxes.id, cashboxId)).limit(1))[0]; if (!cashbox || cashbox.shop !== customer.shop) return Response.json({ error: "Caisse invalide pour ce magasin." }, { status: 400 }); }
    const created = (await db.insert(customerPayments).values({ customerId: id, shop: customer.shop, amount, cashboxId, method: String(body.method ?? "Espèces"), notes: String(body.notes ?? "").trim() }).returning())[0];
    if (cashbox) await db.insert(cashMovements).values({ cashboxId: cashbox.id, shop: customer.shop, direction: "in", movementType: "Versement client", amount, reason: `Versement client · ${customer.name}`, reference: `CLI-${customer.id}-${created.id}` });
    return Response.json({ payment: created }, { status: 201 });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Versement impossible." }, { status: 500 }); }
}
