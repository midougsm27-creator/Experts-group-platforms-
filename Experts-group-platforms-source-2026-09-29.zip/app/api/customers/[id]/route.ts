import { and, eq, ne } from "drizzle-orm";
import { getDb } from "../../../../db";
import { customerPayments, customers, repairs } from "../../../../db/schema";

const shops = ["ProPhone", "MidouGSM"];
const customerTypes = ["Détail", "Gros", "Réparateur"];
const sources = ["Magasin", "Plateforme"];

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const id = Number((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    const name = String(body.name ?? "").trim(); const phone = String(body.phone ?? "").trim(); const shop = String(body.shop ?? "");
    const customerType = String(body.customerType ?? "Détail"); const source = String(body.source ?? "Magasin");
    if (!Number.isInteger(id) || !name || !phone || !shops.includes(shop) || !customerTypes.includes(customerType) || !sources.includes(source)) return Response.json({ error: "Informations client invalides." }, { status: 400 });
    const db = getDb();
    const duplicate = await db.select({ id: customers.id }).from(customers).where(and(eq(customers.shop, shop), eq(customers.phone, phone), ne(customers.id, id))).limit(1);
    if (duplicate.length) return Response.json({ error: "Ce numéro existe déjà dans ce magasin." }, { status: 409 });
    const updated = (await db.update(customers).set({ name, phone, shop, customerType, source, email: String(body.email ?? "").trim(), address: String(body.address ?? "").trim(), notes: String(body.notes ?? "").trim(), updatedAt: new Date().toISOString() }).where(eq(customers.id, id)).returning())[0];
    if (!updated) return Response.json({ error: "Client introuvable." }, { status: 404 });
    return Response.json({ customer: updated });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Modification impossible." }, { status: 500 }); }
}

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const id = Number((await context.params).id); const db = getDb();
    const linked = await db.select({ id: repairs.id }).from(repairs).where(eq(repairs.customerId, id)).limit(1);
    if (linked.length) return Response.json({ error: "Ce client possède des réparations. Désactivez-le au lieu de le supprimer." }, { status: 409 });
    await db.delete(customerPayments).where(eq(customerPayments.customerId, id));
    const deleted = await db.delete(customers).where(eq(customers.id, id)).returning({ id: customers.id });
    if (!deleted.length) return Response.json({ error: "Client introuvable." }, { status: 404 });
    return Response.json({ ok: true });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Suppression impossible." }, { status: 500 }); }
}
