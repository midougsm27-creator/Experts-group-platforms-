import { and, asc, eq, like, or, sql } from "drizzle-orm";
import { getDb } from "../../../db";
import { customerPayments, customers, repairs, sales } from "../../../db/schema";

const shops = ["ProPhone", "MidouGSM"];
const customerTypes = ["Détail", "Gros", "Réparateur"];
const sources = ["Magasin", "Plateforme"];

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const shop = params.get("shop") ?? "all";
    const query = params.get("q")?.trim() ?? "";
    const type = params.get("type") ?? "all";
    const source = params.get("source") ?? "all";
    const balanceFilter = params.get("balance") ?? "all";
    const db = getDb();
    const clauses = [
      shop !== "all" ? eq(customers.shop, shop) : undefined,
      type !== "all" ? eq(customers.customerType, type) : undefined,
      source !== "all" ? eq(customers.source, source) : undefined,
      query ? or(like(customers.name, `%${query}%`), like(customers.phone, `%${query}%`), like(customers.email, `%${query}%`)) : undefined,
    ].filter(Boolean);
    const where = clauses.length ? and(...(clauses as any)) : undefined;
    const customerRows = await db.select().from(customers).where(where).orderBy(asc(customers.name)).limit(300);
    if (!customerRows.length) return Response.json({ customers: [] });

    const repairStats = await db.select({ customerId: repairs.customerId, transactions: sql<number>`count(*)`, total: sql<number>`coalesce(sum(${repairs.price}), 0)`, paid: sql<number>`coalesce(sum(${repairs.deposit}), 0)` }).from(repairs).groupBy(repairs.customerId);
    const paymentStats = await db.select({ customerId: customerPayments.customerId, paid: sql<number>`coalesce(sum(${customerPayments.amount}), 0)` }).from(customerPayments).groupBy(customerPayments.customerId);
    const saleRows = await db.select({ shop: sales.shop, customerName: sales.customerName, total: sales.netAmount, paid: sales.paidAmount }).from(sales);
    const rows = customerRows.map((customer) => {
      const repair = repairStats.find((item) => item.customerId === customer.id);
      const namedSales = saleRows.filter((sale) => sale.shop === customer.shop && sale.customerName.trim().toLocaleLowerCase() === customer.name.trim().toLocaleLowerCase());
      const saleTotal = namedSales.reduce((sum, sale) => sum + sale.total, 0);
      const salePaid = namedSales.reduce((sum, sale) => sum + sale.paid, 0);
      const extraPaid = paymentStats.find((item) => item.customerId === customer.id)?.paid ?? 0;
      const totalPurchases = Number(repair?.total ?? 0) + saleTotal;
      const totalPaid = Number(repair?.paid ?? 0) + salePaid + Number(extraPaid);
      return { ...customer, transactions: Number(repair?.transactions ?? 0) + namedSales.length, totalPurchases, totalPaid, balance: totalPaid - totalPurchases };
    }).filter((customer) => balanceFilter === "debt" ? customer.balance < 0 : balanceFilter === "credit" ? customer.balance > 0 : balanceFilter === "purchases" ? customer.totalPurchases > 0 : balanceFilter === "inactive" ? customer.totalPurchases === 0 : true);
    return Response.json({ customers: rows });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erreur inattendue";
    return Response.json({ error: message.includes("no such") ? "Le module clients n’est pas encore initialisé." : message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const phone = String(body.phone ?? "").trim();
    const shop = String(body.shop ?? "");
    const customerType = String(body.customerType ?? "Détail");
    const source = String(body.source ?? "Magasin");
    if (!name || !phone || !shops.includes(shop) || !customerTypes.includes(customerType) || !sources.includes(source)) return Response.json({ error: "Informations client invalides." }, { status: 400 });
    const db = getDb();
    const existing = await db.select({ id: customers.id }).from(customers).where(and(eq(customers.shop, shop), eq(customers.phone, phone))).limit(1);
    if (existing.length) return Response.json({ error: "Ce numéro existe déjà dans ce magasin." }, { status: 409 });
    const created = (await db.insert(customers).values({ name, phone, shop, customerType, source, email: String(body.email ?? "").trim(), address: String(body.address ?? "").trim(), notes: String(body.notes ?? "").trim() }).returning())[0];
    return Response.json({ customer: created }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Ajout impossible." }, { status: 500 });
  }
}
