import { and, desc, eq, inArray, like, or } from "drizzle-orm";
import { getDb } from "../../../db";
import { cashboxes, cashMovements, products, saleLines, sales, stockMovements } from "../../../db/schema";

type LineInput = { productId: number; quantity: number; unitPrice: number };
const validShops = ["ProPhone", "MidouGSM"];

export async function GET(request: Request) {
  try {
    const parameters = new URL(request.url).searchParams;
    const id = Number(parameters.get("id") ?? 0);
    const shop = parameters.get("shop") ?? "all";
    const query = parameters.get("q")?.trim() ?? "";
    const db = getDb();
    if (id) {
      const sale = (await db.select().from(sales).where(eq(sales.id, id)).limit(1))[0];
      if (!sale) return Response.json({ error: "Bon de vente introuvable." }, { status: 404 });
      const lines = await db.select().from(saleLines).where(eq(saleLines.saleId, id));
      return Response.json({ sale, lines }, { headers: { "Cache-Control": "no-store" } });
    }
    const clauses = [shop !== "all" ? eq(sales.shop, shop) : undefined, query ? or(like(sales.receiptNumber, `%${query}%`), like(sales.customerName, `%${query}%`)) : undefined].filter(Boolean);
    const where = clauses.length === 2 ? and(clauses[0], clauses[1]) : clauses[0];
    const rows = await db.select().from(sales).where(where).orderBy(desc(sales.id)).limit(150);
    return Response.json({ sales: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erreur inattendue";
    return Response.json({ error: message.includes("no such table") ? "Le journal des ventes n’est pas encore initialisé." : message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const shop = String(body.shop ?? "");
    const customerName = String(body.customerName ?? "VENTE-COMPTOIR").trim() || "VENTE-COMPTOIR";
    const lines = Array.isArray(body.lines) ? body.lines as LineInput[] : [];
    const discountAmount = Math.max(0, Math.round(Number(body.discountAmount ?? 0)));
    const requestedPaidAmount = Math.max(0, Math.round(Number(body.paidAmount ?? 0)));
    const cashboxId = body.cashboxId ? Number(body.cashboxId) : null;
    if (!validShops.includes(shop) || !lines.length || lines.some((line) => !Number.isInteger(line.productId) || line.quantity <= 0 || line.unitPrice <= 0)) {
      return Response.json({ error: "Bon de vente invalide." }, { status: 400 });
    }

    const db = getDb();
    const productRows = await db.select().from(products).where(inArray(products.id, lines.map((line) => line.productId)));
    if (productRows.length !== new Set(lines.map((line) => line.productId)).size) return Response.json({ error: "Un produit du bon est introuvable." }, { status: 404 });
    const movements = await db.select().from(stockMovements).where(inArray(stockMovements.productId, lines.map((line) => line.productId)));
    for (const line of lines) {
      const available = movements.filter((movement) => movement.productId === line.productId && movement.shop === shop).reduce((sum, movement) => sum + movement.quantity, 0);
      if (available < line.quantity) {
        const product = productRows.find((item) => item.id === line.productId);
        return Response.json({ error: `Stock insuffisant pour ${product?.name ?? "ce produit"} (${available} disponible).` }, { status: 409 });
      }
    }
    let cashbox = null;
    if (cashboxId) {
      cashbox = (await db.select().from(cashboxes).where(eq(cashboxes.id, cashboxId)).limit(1))[0];
      if (!cashbox || cashbox.shop !== shop) return Response.json({ error: "Caisse invalide pour ce magasin." }, { status: 400 });
    }
    const grossAmount = lines.reduce((sum, line) => sum + Math.round(line.quantity * line.unitPrice), 0);
    const netAmount = Math.max(0, grossAmount - Math.min(grossAmount, discountAmount));
    const paidAmount = customerName.toLocaleUpperCase() === "VENTE-COMPTOIR" ? netAmount : requestedPaidAmount;
    const receiptNumber = `VTE-${shop === "ProPhone" ? "PRO" : "MID"}-${new Date().getFullYear()}-${String(Date.now()).slice(-7)}`;
    const created = (await db.insert(sales).values({ receiptNumber, shop, customerName, grossAmount, discountAmount: Math.min(grossAmount, discountAmount), netAmount, paidAmount, cashboxId }).returning())[0];
    const statements: any[] = lines.flatMap((line) => {
      const product = productRows.find((item) => item.id === line.productId)!;
      return [
        db.insert(saleLines).values({ saleId: created.id, productId: line.productId, productName: product.name, sku: product.sku, quantity: line.quantity, unitPrice: Math.round(line.unitPrice), lineTotal: Math.round(line.quantity * line.unitPrice) }),
        db.insert(stockMovements).values({ productId: line.productId, shop, location: "Magasin", movementType: "Vente", quantity: -line.quantity, salePrice: Math.round(line.unitPrice), reference: receiptNumber }),
      ];
    });
    if (cashbox && paidAmount > 0) statements.push(db.insert(cashMovements).values({ cashboxId: cashbox.id, shop, direction: "in", movementType: "Vente", amount: paidAmount, reason: `Vente ${receiptNumber}`, reference: receiptNumber }));
    await db.batch(statements as [any, ...any[]]);
    return Response.json({ sale: { ...created, lines: lines.map((line) => ({ ...line, ...productRows.find((item) => item.id === line.productId) })) } }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erreur inattendue";
    return Response.json({ error: message.includes("UNIQUE") ? "Numéro de bon déjà utilisé, recommencez." : message }, { status: 500 });
  }
}
