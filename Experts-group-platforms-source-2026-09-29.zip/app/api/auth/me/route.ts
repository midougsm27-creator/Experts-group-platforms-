import { authErrorResponse, getCurrentUser } from "../../../../lib/authz";

export async function GET(request: Request) {
  try { return Response.json({ user: await getCurrentUser(request, true) }, { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { return authErrorResponse(error, "Compte indisponible."); }
}
