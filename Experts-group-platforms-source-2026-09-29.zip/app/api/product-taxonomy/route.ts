import { and, asc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { productTaxonomy } from "../../../db/schema";

const categories = ["family", "subfamily", "brand", "model", "quality", "manufacturer", "color"] as const;
type Category = (typeof categories)[number];
type Entry = { name: string; abbreviation: string; parent?: string };

const entry = (name: string, abbreviation: string, parent = ""): Entry => ({ name, abbreviation, parent });

const defaults: Record<Category, Entry[]> = {
  family: [
    entry("Pièces détachées", "PD"), entry("Accessoires", "ACC"),
    entry("Consommables atelier", "CONS"), entry("Téléphones", "TEL"), entry("Autres", "AUT"),
  ],
  subfamily: [
    entry("Afficheur / Écran", "AF", "Pièces détachées"), entry("Batterie", "BAT", "Pièces détachées"),
    entry("Cache arrière", "CAR", "Pièces détachées"), entry("Châssis / Frame", "FRM", "Pièces détachées"),
    entry("Connecteur de charge", "CCH", "Pièces détachées"), entry("Flex de charge", "FCH", "Pièces détachées"),
    entry("Flex Power", "FPW", "Pièces détachées"), entry("Flex Volume", "FVL", "Pièces détachées"),
    entry("Caméra avant", "CAV", "Pièces détachées"), entry("Caméra arrière", "CAM", "Pièces détachées"),
    entry("Écouteur interne", "ECO", "Pièces détachées"), entry("Haut-parleur", "HP", "Pièces détachées"),
    entry("Microphone", "MIC", "Pièces détachées"), entry("Vibreur", "VIB", "Pièces détachées"),
    entry("Lecteur d’empreinte", "EMP", "Pièces détachées"), entry("Tiroir SIM", "SIM", "Pièces détachées"),
    entry("Vitre caméra", "VCM", "Pièces détachées"), entry("Bouton", "BTN", "Pièces détachées"),
    entry("Antenne / Réseau", "ANT", "Pièces détachées"), entry("Carte mère", "CM", "Pièces détachées"),
    entry("Chargeur", "CHR", "Accessoires"), entry("Câble", "CBL", "Accessoires"),
    entry("Écouteurs", "EAR", "Accessoires"), entry("Coque", "COQ", "Accessoires"),
    entry("Protection écran", "PRO", "Accessoires"), entry("Support", "SUP", "Accessoires"),
    entry("Colle", "COL", "Consommables atelier"), entry("Soudure", "SOU", "Consommables atelier"),
  ],
  brand: [
    entry("Samsung", "SAM"), entry("Apple", "APP"), entry("Xiaomi", "XIA"), entry("Redmi", "RED"),
    entry("Oppo", "OPP"), entry("Realme", "REA"), entry("Huawei", "HUA"), entry("Honor", "HON"),
    entry("Infinix", "INF"), entry("Tecno", "TEC"), entry("Vivo", "VIV"), entry("Nokia", "NOK"),
    entry("OnePlus", "ONE"), entry("Google", "GOO"), entry("Motorola", "MOT"), entry("Générique", "GEN"),
  ],
  model: [
    ...["A10","A11","A12","A13","A14","A15","A16","A20","A21S","A22","A23","A24","A25","A30","A31","A32","A33","A34","A35","A50","A51","A52","A53","A54","A55","S20","S21","S22","S23","S24","S25"].map((name) => entry(name, name, "Samsung")),
    entry("iPhone 8", "IPH 8", "Apple"), entry("iPhone X", "IPH X", "Apple"), entry("iPhone XR", "IPH XR", "Apple"),
    ...[11,12,13,14,15,16,17].flatMap((number) => [entry(`iPhone ${number}`, `IPH ${number}`, "Apple"), entry(`iPhone ${number} Pro`, `IPH ${number} P`, "Apple"), entry(`iPhone ${number} Pro Max`, `IPH ${number} PM`, "Apple")]),
    ...["Note 10","Note 11","Note 12","Note 13","Note 14"].map((name) => entry(name, `RN ${name.replace("Note ", "")}`, "Redmi")),
    ...["A15","A16","A17","A18","A54","A57","A74"].map((name) => entry(name, name, "Oppo")),
    ...["C11","C21","C25","C35","C53","C55","C67"].map((name) => entry(name, name, "Realme")),
    ...["Hot 10","Hot 11","Hot 12","Hot 20","Hot 30","Hot 40","Smart 8"].map((name) => entry(name, name.toUpperCase(), "Infinix")),
    ...["Spark 8","Spark 9","Spark 10","Spark 20","Camon 18","Camon 20"].map((name) => entry(name, name.toUpperCase(), "Tecno")),
  ],
  quality: [
    entry("Original", "ORG"), entry("OEM", "OEM"), entry("Compatible", "COMP"),
    entry("Service Pack", "SP", "Afficheur / Écran"), entry("Original démonté", "DEM", "Afficheur / Écran"),
    entry("OLED", "OLED", "Afficheur / Écran"), entry("Soft OLED", "SOFT", "Afficheur / Écran"),
    entry("Hard OLED", "HARD", "Afficheur / Écran"), entry("AMOLED", "AMOLED", "Afficheur / Écran"),
    entry("INCELL", "INC", "Afficheur / Écran"), entry("TFT", "TFT", "Afficheur / Écran"),
    entry("AAA", "AAA", "Afficheur / Écran"), entry("AAA", "AAA", "Batterie"),
  ],
  manufacturer: [
    entry("Générique", "GEN"), entry("Samsung", "SAM"), entry("Apple", "APP"),
    entry("GX", "GX"), entry("Bosonni", "BOS"), entry("ACE", "ACE"), entry("Axon", "AXN"),
  ],
  color: [
    entry("Black", "BLK"), entry("White", "WHT"), entry("Blue", "BLU"), entry("Red", "RED"),
    entry("Green", "GRN"), entry("Gold", "GLD"), entry("Silver", "SLV"), entry("Gray", "GRY"),
    entry("Pink", "PNK"), entry("Purple", "PPL"), entry("Orange", "ORA"), entry("Brown", "BRN"),
    entry("Yellow", "YLW"), entry("Transparent", "CLR"),
  ],
};

function clean(value: unknown) {
  return String(value ?? "").trim().replace(/\s+/g, " ");
}

function cleanAbbreviation(value: unknown) {
  return clean(value).toUpperCase();
}

export async function GET() {
  try {
    const custom = await getDb().select().from(productTaxonomy).orderBy(asc(productTaxonomy.name));
    const taxonomy = Object.fromEntries(categories.map((category) => {
      const merged = [...defaults[category], ...custom.filter((item) => item.category === category)];
      const unique = new Map<string, Entry>();
      for (const item of merged) unique.set(`${item.parent ?? ""}::${item.name}`.toLocaleLowerCase(), { name: item.name, abbreviation: item.abbreviation, parent: item.parent ?? "" });
      return [category, Array.from(unique.values())];
    }));
    return Response.json({ taxonomy });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Nomenclature indisponible." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const category = clean(body.category) as Category;
    const name = clean(body.name);
    const abbreviation = cleanAbbreviation(body.abbreviation);
    const parent = clean(body.parent);
    if (!categories.includes(category) || !name || !abbreviation) return Response.json({ error: "Nom et abréviation obligatoires." }, { status: 400 });
    const db = getDb();
    const found = await db.select().from(productTaxonomy).where(and(eq(productTaxonomy.category, category), eq(productTaxonomy.name, name), eq(productTaxonomy.parent, parent))).limit(1);
    if (found.length) {
      const updated = await db.update(productTaxonomy).set({ abbreviation, updatedAt: new Date().toISOString() }).where(eq(productTaxonomy.id, found[0].id)).returning();
      return Response.json({ entry: updated[0] });
    }
    const inserted = await db.insert(productTaxonomy).values({ category, name, abbreviation, parent }).returning();
    return Response.json({ entry: inserted[0] }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Enregistrement impossible.";
    return Response.json({ error: message.includes("UNIQUE") ? "Cette valeur existe déjà." : message }, { status: message.includes("UNIQUE") ? 409 : 500 });
  }
}
