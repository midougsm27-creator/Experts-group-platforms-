import { and, asc, eq, like, or, sql } from "drizzle-orm";
import { getDb } from "../../../db";
import { purchases, supplierPayments, suppliers } from "../../../db/schema";

const shops = ["ProPhone", "MidouGSM"];
const supplierTypes = ["Accessoires", "Pièces détachées", "Mixte"];
const origins = ["Algérien", "Chinois", "Autre"];

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams; const shop = params.get("shop") ?? "all"; const query = params.get("q")?.trim() ?? "";
    const type = params.get("type") ?? "all"; const origin = params.get("origin") ?? "all"; const balance = params.get("balance") ?? "all";
    const db = getDb();
    const clauses = [shop !== "all" ? eq(suppliers.shop, shop) : undefined, type !== "all" ? eq(suppliers.supplierType, type) : undefined, origin !== "all" ? eq(suppliers.origin, origin) : undefined, query ? or(like(suppliers.name, `%${query}%`), like(suppliers.phone, `%${query}%`), like(suppliers.city, `%${query}%`)) : undefined].filter(Boolean);
    const supplierRows = await db.select().from(suppliers).where(clauses.length ? and(...(clauses as any)) : undefined).orderBy(asc(suppliers.name)).limit(300);
    const purchaseRows = await db.select({ shop: purchases.shop, supplierId: purchases.supplierId, supplier: purchases.supplier, total: purchases.netAmount, paid: purchases.paidAmount }).from(purchases);
    const payments = await db.select({ supplierId: supplierPayments.supplierId, paid: sql<number>`coalesce(sum(${supplierPayments.amount}), 0)` }).from(supplierPayments).groupBy(supplierPayments.supplierId);
    const rows = supplierRows.map((supplier) => {
      const linked = purchaseRows.filter((purchase) => purchase.supplierId === supplier.id || (!purchase.supplierId && purchase.shop === supplier.shop && purchase.supplier.trim().toLocaleLowerCase() === supplier.name.trim().toLocaleLowerCase()));
      const totalPurchases = linked.reduce((sum, purchase) => sum + purchase.total, 0); const invoicePaid = linked.reduce((sum, purchase) => sum + purchase.paid, 0); const extraPaid = Number(payments.find((item) => item.supplierId === supplier.id)?.paid ?? 0);
      return { ...supplier, transactions: linked.length, totalPurchases, totalPaid: invoicePaid + extraPaid, balance: invoicePaid + extraPaid - totalPurchases };
    }).filter((supplier) => balance === "debt" ? supplier.balance < 0 : balance === "settled" ? supplier.totalPurchases > 0 && supplier.balance >= 0 : balance === "purchases" ? supplier.totalPurchases > 0 : balance === "inactive" ? supplier.totalPurchases === 0 : true);
    return Response.json({ suppliers: rows });
  } catch (error) { const message = error instanceof Error ? error.message : "Erreur inattendue"; return Response.json({ error: message.includes("no such") ? "Le module fournisseurs n’est pas encore initialisé." : message }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>; const name = String(body.name ?? "").trim(); const shop = String(body.shop ?? ""); const supplierType = String(body.supplierType ?? "Accessoires"); const origin = String(body.origin ?? "Algérien");
    if (!name || !shops.includes(shop) || !supplierTypes.includes(supplierType) || !origins.includes(origin)) return Response.json({ error: "Informations fournisseur invalides." }, { status: 400 });
    const db = getDb(); const existing = await db.select({ id: suppliers.id }).from(suppliers).where(and(eq(suppliers.shop, shop), eq(suppliers.name, name))).limit(1);
    if (existing.length) return Response.json({ error: "Ce fournisseur existe déjà dans ce magasin." }, { status: 409 });
    const created = (await db.insert(suppliers).values({ name, shop, supplierType, origin, phone: String(body.phone ?? "").trim(), email: String(body.email ?? "").trim(), city: String(body.city ?? "").trim(), currency: String(body.currency ?? (origin === "Chinois" ? "USD" : "DZD")), notes: String(body.notes ?? "").trim() }).returning())[0];
    return Response.json({ supplier: created }, { status: 201 });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Ajout impossible." }, { status: 500 }); }
}
