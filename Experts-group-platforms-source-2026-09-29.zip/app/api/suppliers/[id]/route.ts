import { and, eq, ne } from "drizzle-orm";
import { getDb } from "../../../../db";
import { cashboxes, cashMovements, supplierPayments, suppliers } from "../../../../db/schema";

const shops = ["ProPhone", "MidouGSM"]; const supplierTypes = ["Accessoires", "Pièces détachées", "Mixte"]; const origins = ["Algérien", "Chinois", "Autre"];
export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const id = Number((await context.params).id); const body = await request.json() as Record<string, unknown>;
    const db = getDb();
    if (body.action === "payment") {
      const amount = Math.round(Number(body.amount ?? 0)); const cashboxId = body.cashboxId ? Number(body.cashboxId) : null;
      if (!Number.isFinite(amount) || amount <= 0) return Response.json({ error: "Montant invalide." }, { status: 400 });
      const supplier = (await db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1))[0]; if (!supplier) return Response.json({ error: "Fournisseur introuvable." }, { status: 404 });
      let cashbox = null; if (cashboxId) { cashbox = (await db.select().from(cashboxes).where(eq(cashboxes.id, cashboxId)).limit(1))[0]; if (!cashbox || cashbox.shop !== supplier.shop) return Response.json({ error: "Caisse invalide pour ce magasin." }, { status: 400 }); }
      const created = (await db.insert(supplierPayments).values({ supplierId: id, shop: supplier.shop, amount, cashboxId, method: String(body.method ?? "Espèces"), notes: String(body.notes ?? "").trim() }).returning())[0];
      if (cashbox) await db.insert(cashMovements).values({ cashboxId: cashbox.id, shop: supplier.shop, direction: "out", movementType: "Versement fournisseur", amount, reason: `Versement fournisseur · ${supplier.name}`, reference: `FOU-${supplier.id}-${created.id}` });
      return Response.json({ payment: created }, { status: 201 });
    }
    const name = String(body.name ?? "").trim(); const shop = String(body.shop ?? ""); const supplierType = String(body.supplierType ?? "Accessoires"); const origin = String(body.origin ?? "Algérien");
    if (!Number.isInteger(id) || !name || !shops.includes(shop) || !supplierTypes.includes(supplierType) || !origins.includes(origin)) return Response.json({ error: "Informations fournisseur invalides." }, { status: 400 });
    const duplicate = await db.select({ id: suppliers.id }).from(suppliers).where(and(eq(suppliers.shop, shop), eq(suppliers.name, name), ne(suppliers.id, id))).limit(1);
    if (duplicate.length) return Response.json({ error: "Ce fournisseur existe déjà dans ce magasin." }, { status: 409 });
    const updated = (await db.update(suppliers).set({ name, shop, supplierType, origin, phone: String(body.phone ?? "").trim(), email: String(body.email ?? "").trim(), city: String(body.city ?? "").trim(), currency: String(body.currency ?? "DZD"), notes: String(body.notes ?? "").trim(), updatedAt: new Date().toISOString() }).where(eq(suppliers.id, id)).returning())[0];
    if (!updated) return Response.json({ error: "Fournisseur introuvable." }, { status: 404 }); return Response.json({ supplier: updated });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Modification impossible." }, { status: 500 }); }
}
export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  try { const id = Number((await context.params).id); const db = getDb(); await db.delete(supplierPayments).where(eq(supplierPayments.supplierId, id)); const deleted = await db.delete(suppliers).where(eq(suppliers.id, id)).returning({ id: suppliers.id }); if (!deleted.length) return Response.json({ error: "Fournisseur introuvable." }, { status: 404 }); return Response.json({ ok: true }); }
  catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Suppression impossible." }, { status: 500 }); }
}
