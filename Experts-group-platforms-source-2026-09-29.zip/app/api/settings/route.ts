import { eq, sql } from "drizzle-orm";
import { getDb } from "../../../db";
import { shopSettings } from "../../../db/schema";

const shops = ["ProPhone", "MidouGSM"];

export async function GET() {
  try {
    const db = getDb();
    const existing = await db.select().from(shopSettings);
    for (const shop of shops) if (!existing.some((row) => row.shop === shop)) await db.insert(shopSettings).values({ shop }).onConflictDoNothing();
    return Response.json({ settings: await db.select().from(shopSettings) });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Paramètres indisponibles." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const shop = String(body.shop ?? "");
    if (!shops.includes(shop)) return Response.json({ error: "Magasin invalide." }, { status: 400 });
    const values = {
      negativeStockPolicy: String(body.negativeStockPolicy ?? "manager_reason"),
      reserveRepairParts: Boolean(body.reserveRepairParts),
      lowStockThreshold: Math.max(0, Math.round(Number(body.lowStockThreshold ?? 3))),
      receiptPaper: String(body.receiptPaper ?? "A4"), showSku: Boolean(body.showSku), showBarcode: Boolean(body.showBarcode),
      invoiceFooter: String(body.invoiceFooter ?? "").trim(), updatedAt: sql`CURRENT_TIMESTAMP`,
    };
    const db = getDb();
    await db.insert(shopSettings).values({ shop, ...values }).onConflictDoUpdate({ target: shopSettings.shop, set: values });
    const [settings] = await db.select().from(shopSettings).where(eq(shopSettings.shop, shop));
    return Response.json({ settings });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Enregistrement impossible." }, { status: 500 });
  }
}
