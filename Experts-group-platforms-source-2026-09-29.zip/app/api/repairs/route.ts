import { and, desc, eq, inArray, like, or } from "drizzle-orm";
import { getDb } from "../../../db";
import { customers, repairParts, repairs } from "../../../db/schema";
import { addPartToRepair } from "../../../lib/repair-parts";

function errorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "Erreur inattendue";
  return message.includes("no such table")
    ? "La base de données n’est pas encore initialisée."
    : message;
}

export async function GET(request: Request) {
  try {
    const db = getDb();
    const parameters = new URL(request.url).searchParams;
    const query = parameters.get("q")?.trim() ?? "";
    const shop = parameters.get("shop")?.trim() ?? "";
    const searchWhere = query
      ? or(
          like(customers.name, `%${query}%`),
          like(customers.phone, `%${query}%`),
          like(repairs.ticketNumber, `%${query}%`),
          like(repairs.model, `%${query}%`)
        )
      : undefined;
    const shopWhere = shop && shop !== "all" ? eq(repairs.shop, shop) : undefined;
    const where = searchWhere && shopWhere ? and(shopWhere, searchWhere) : shopWhere ?? searchWhere;

    const rows = await db
      .select({
        id: repairs.id,
        ticketNumber: repairs.ticketNumber,
        customerName: customers.name,
        customerPhone: customers.phone,
        shop: repairs.shop,
        deviceType: repairs.deviceType,
        brand: repairs.brand,
        model: repairs.model,
        storageLocation: repairs.storageLocation,
        partQuality: repairs.partQuality,
        issue: repairs.issue,
        price: repairs.price,
        deposit: repairs.deposit,
        technician: repairs.technician,
        status: repairs.status,
        notes: repairs.notes,
        createdAt: repairs.createdAt,
      })
      .from(repairs)
      .innerJoin(customers, eq(repairs.customerId, customers.id))
      .where(where)
      .orderBy(desc(repairs.id))
      .limit(100);

    const partRows = rows.length ? await db.select().from(repairParts).where(inArray(repairParts.repairId, rows.map((row) => row.id))) : [];
    const repairsWithParts = rows.map((row) => ({ ...row, usedParts: partRows.filter((part) => part.repairId === row.id) }));
    return Response.json({ repairs: repairsWithParts });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.customerName ?? "").trim();
    const phone = String(body.customerPhone ?? "").trim();
    const brand = String(body.brand ?? "").trim();
    const model = String(body.model ?? "").trim();
    const deviceType = String(body.deviceType ?? "Smartphone").trim();
    const storageLocation = String(body.storageLocation ?? "Comptoir réception").trim();
    const partQuality = String(body.partQuality ?? "").trim();
    const issue = String(body.issue ?? "").trim();
    const shop = String(body.shop ?? "").trim();
    const price = Number(body.price ?? 0);
    const deposit = Number(body.deposit ?? 0);
    const usedParts = Array.isArray(body.usedParts) ? body.usedParts.map((part) => part as Record<string, unknown>).map((part) => {
      const requestedQuantity = Number(part.quantity ?? 1);
      return {
        productId: Number(part.productId),
        itemName: String(part.itemName ?? "").trim(),
        quality: String(part.quality ?? "").trim(),
        quantity: Number.isFinite(requestedQuantity) ? Math.max(1, Math.round(requestedQuantity)) : 1,
      };
    }).filter((part) => Number.isInteger(part.productId)) : [];

    if (!name || !phone || !deviceType || !brand || !model || !storageLocation || !issue || !["ProPhone", "MidouGSM"].includes(shop)) {
      return Response.json({ error: "Veuillez compléter les champs obligatoires." }, { status: 400 });
    }
    if (!Number.isFinite(price) || price < 0 || !Number.isFinite(deposit) || deposit < 0) {
      return Response.json({ error: "Les montants saisis sont invalides." }, { status: 400 });
    }
    if (deposit > price && price > 0) {
      return Response.json({ error: "Le versement ne peut pas dépasser le prix." }, { status: 400 });
    }

    const db = getDb();
    const existing = await db.select().from(customers).where(and(eq(customers.phone, phone), eq(customers.shop, shop))).limit(1);
    let customerId = existing[0]?.id;
    if (customerId) {
      await db.update(customers).set({ name }).where(eq(customers.id, customerId));
    } else {
      const inserted = await db.insert(customers).values({ name, phone, shop }).returning({ id: customers.id });
      customerId = inserted[0].id;
    }

    const ticketNumber = `MS-${new Date().toISOString().slice(2, 10).replaceAll("-", "")}-${crypto.randomUUID().slice(0, 5).toUpperCase()}`;
    const inserted = await db.insert(repairs).values({
      ticketNumber,
      customerId,
      shop,
      deviceType,
      brand,
      model,
      storageLocation,
      partQuality,
      issue,
      price: Math.round(price),
      deposit: Math.round(deposit),
      technician: String(body.technician ?? "Non assigné"),
      status: String(body.status ?? "En attente"),
      notes: String(body.notes ?? "").trim(),
    }).returning({ id: repairs.id, ticketNumber: repairs.ticketNumber });

    if (usedParts.length) {
      for (const part of usedParts) await addPartToRepair({ repairId: inserted[0].id, productId: part.productId, quantity: part.quantity, quality: part.quality });
    }

    return Response.json({ repair: inserted[0] }, { status: 201 });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}
