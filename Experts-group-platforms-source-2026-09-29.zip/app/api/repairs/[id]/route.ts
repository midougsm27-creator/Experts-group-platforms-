import { and, eq, sql } from "drizzle-orm";
import { getDb } from "../../../../db";
import { repairs } from "../../../../db/schema";

const allowedStatuses = ["En attente", "Diagnostic", "En réparation", "Pièce manquante", "Prêt", "Livré", "Non réparé"];

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    const repairId = Number(id);
    const body = (await request.json()) as { status?: string; storageLocation?: string; shop?: string };
    const status = body.status?.trim();
    const storageLocation = body.storageLocation?.trim();
    const shop = body.shop?.trim();
    if (!Number.isInteger(repairId) || !shop || !["ProPhone", "MidouGSM"].includes(shop) || (!status && !storageLocation) || (status && !allowedStatuses.includes(status))) {
      return Response.json({ error: "Mise à jour invalide." }, { status: 400 });
    }
    const db = getDb();
    const updated = await db.update(repairs)
      .set({ ...(status ? { status } : {}), ...(storageLocation ? { storageLocation } : {}), updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(and(eq(repairs.id, repairId), eq(repairs.shop, shop)))
      .returning({ id: repairs.id, status: repairs.status, storageLocation: repairs.storageLocation });
    if (!updated.length) return Response.json({ error: "Réparation introuvable." }, { status: 404 });
    return Response.json({ repair: updated[0] });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Erreur inattendue" }, { status: 500 });
  }
}
