import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { getDb } from "../../../db";
import { products, repairParts, repairs, stockMovements } from "../../../db/schema";
import { addPartToRepair, markPartUnused, partStatuses, stockForProduct } from "../../../lib/repair-parts";

export async function GET(request: Request) {
  try {
    const parameters = new URL(request.url).searchParams;
    const repairId = Number(parameters.get("repairId") ?? 0);
    const shop = parameters.get("shop")?.trim() ?? "";
    const db = getDb();
    if (repairId) {
      const parts = await db.select().from(repairParts).where(eq(repairParts.repairId, repairId)).orderBy(asc(repairParts.id));
      return Response.json({ parts });
    }
    const pending = await db.select({
      id: repairParts.id, productId: repairParts.productId, shop: repairParts.shop, itemName: repairParts.itemName,
      quality: repairParts.quality, quantity: repairParts.quantity, flow: repairParts.flow, status: repairParts.status,
      supplierStatus: repairParts.supplierStatus, orderStatus: repairParts.orderStatus,
      ticketNumber: repairs.ticketNumber, family: products.family,
    }).from(repairParts).innerJoin(repairs, eq(repairParts.repairId, repairs.id))
      .leftJoin(products, eq(repairParts.productId, products.id))
      .where(and(shop && shop !== "all" ? eq(repairParts.shop, shop) : undefined, inArray(repairParts.status, ["À commander", "Demandée"])));
    const groups = Array.from(new Map<string, typeof pending>(pending.map((row) => [`${row.shop}|${row.flow}|${row.productId ?? row.itemName}`, []])).entries())
      .map(([key]) => {
        const rows = pending.filter((row) => `${row.shop}|${row.flow}|${row.productId ?? row.itemName}` === key);
        return { key, ids: rows.map((row) => row.id), shop: rows[0].shop, flow: rows[0].flow, productId: rows[0].productId, itemName: rows[0].itemName, quality: rows[0].quality, family: rows[0].family || "Non classé", quantity: rows.reduce((sum, row) => sum + row.quantity, 0), supplierStatus: rows[0].supplierStatus, orderStatus: rows[0].orderStatus, tickets: rows.map((row) => row.ticketNumber) };
      });
    return Response.json({ requests: groups });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Chargement impossible." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const repairId = Number(body.repairId);
    const productId = Number(body.productId);
    const quantity = Number(body.quantity ?? 1);
    if (!Number.isInteger(repairId) || !Number.isInteger(productId) || !Number.isFinite(quantity) || quantity < 1) {
      return Response.json({ error: "Pièce ou quantité invalide." }, { status: 400 });
    }
    const part = await addPartToRepair({ repairId, productId, quantity, quality: String(body.quality ?? "") });
    return Response.json({ part }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Ajout impossible." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const ids = Array.isArray(body.ids) ? body.ids.map(Number).filter(Number.isInteger) : [];
    const supplierStatuses = ["En attente", "Disponible", "Partiellement disponible", "Indisponible", "Alternative proposée"];
    const orderStatuses = ["À commander", "Commandée", "Disponible fournisseur", "Partiellement reçue", "Reçue / Clôturée", "Annulée"];
    if (ids.length) {
      const changes: { supplierStatus?: string; orderStatus?: string; updatedAt: ReturnType<typeof sql> } = { updatedAt: sql`CURRENT_TIMESTAMP` };
      if (body.supplierStatus !== undefined) {
        const value = String(body.supplierStatus); if (!supplierStatuses.includes(value)) return Response.json({ error: "État fournisseur invalide." }, { status: 400 }); changes.supplierStatus = value;
      }
      if (body.orderStatus !== undefined) {
        const value = String(body.orderStatus); if (!orderStatuses.includes(value)) return Response.json({ error: "État commande invalide." }, { status: 400 }); changes.orderStatus = value;
      }
      if (!changes.supplierStatus && !changes.orderStatus) return Response.json({ error: "Aucune modification reçue." }, { status: 400 });
      await getDb().update(repairParts).set(changes).where(inArray(repairParts.id, ids));
      return Response.json({ updated: ids.length });
    }
    const id = Number(body.id);
    const status = String(body.status ?? "");
    if (!Number.isInteger(id) || !partStatuses.includes(status as never)) return Response.json({ error: "Action invalide." }, { status: 400 });
    const db = getDb();
    const [part] = await db.select().from(repairParts).where(eq(repairParts.id, id)).limit(1);
    if (!part) return Response.json({ error: "Pièce introuvable." }, { status: 404 });
    if (status === "Non utilisée") return Response.json({ part: await markPartUnused(id) });
    if (status === "Utilisée") {
      if (!part.productId || !["Réservée", "Reçue"].includes(part.status)) return Response.json({ error: "La pièce doit être réservée ou reçue avant utilisation." }, { status: 409 });
      const stock = await stockForProduct(part.productId, part.shop);
      if (stock.physical < part.quantity) return Response.json({ error: "Stock physique insuffisant." }, { status: 409 });
      await db.insert(stockMovements).values({ productId: part.productId, shop: part.shop, movementType: "Sortie réparation", quantity: -part.quantity, salePrice: part.unitPrice, reference: `REP-${part.repairId}`, repairId: part.repairId });
      const [updated] = await db.update(repairParts).set({ status, reservedQuantity: 0, updatedAt: sql`CURRENT_TIMESTAMP` }).where(eq(repairParts.id, id)).returning();
      return Response.json({ part: updated });
    }
    if (status === "Reçue" && part.productId) {
      const stock = await stockForProduct(part.productId, part.shop);
      if (stock.available < part.quantity) return Response.json({ error: "La réception d’achat ou de transfert doit d’abord alimenter le stock du magasin." }, { status: 409 });
      const [updated] = await db.update(repairParts).set({ status, reservedQuantity: part.quantity, flow: "Stock local", updatedAt: sql`CURRENT_TIMESTAMP` }).where(eq(repairParts.id, id)).returning();
      return Response.json({ part: updated });
    }
    const [updated] = await db.update(repairParts).set({ status, updatedAt: sql`CURRENT_TIMESTAMP` }).where(eq(repairParts.id, id)).returning();
    return Response.json({ part: updated });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Mise à jour impossible." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = Number(new URL(request.url).searchParams.get("id") ?? 0);
    if (!Number.isInteger(id)) return Response.json({ error: "Pièce invalide." }, { status: 400 });
    return Response.json({ part: await markPartUnused(id) });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Suppression impossible." }, { status: 500 });
  }
}
