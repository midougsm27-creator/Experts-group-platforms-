"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { Barcode, Boxes, Check, ChevronDown, Download, FileSpreadsheet, PackagePlus, Pencil, Plus, Save, Search, ShieldCheck, ShoppingBag, ShoppingCart, Tag, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type ActiveShop = "all" | "ProPhone" | "MidouGSM";
type Product = { id: number; sku: string; barcode: string; name: string; family: string; subfamily: string; brand: string; model: string; quality: string; manufacturer: string; color: string; sourceReference: string; purchasePrice: number; pv1: number; pv2: number; pv3: number; warranty: string; notes: string; stock: { ProPhone: number; MidouGSM: number } };
type TaxonomyCategory = "family" | "subfamily" | "brand" | "model" | "quality" | "manufacturer" | "color";
type TaxonomyEntry = { name: string; abbreviation: string; parent?: string };
type Taxonomy = Record<TaxonomyCategory, TaxonomyEntry[]>;
type ImportRow = { name: string; family: string; subfamily: string; brand: string; model: string; quality: string; manufacturer: string; color: string; sourceReference: string; purchasePrice: string; pv1: string; pv2: string; pv3: string; warranty: string; notes: string };
const emptyTaxonomy: Taxonomy = { family: [], subfamily: [], brand: [], model: [], quality: [], manufacturer: [], color: [] };
const importColumns: (keyof ImportRow)[] = ["name", "family", "subfamily", "brand", "model", "quality", "manufacturer", "color", "sourceReference", "purchasePrice", "pv1", "pv2", "pv3", "warranty", "notes"];
const sampleRows: ImportRow[] = [
  { name: "AF SAM A14 OLED GX BLK", family: "Pièces détachées", subfamily: "Afficheur / Écran", brand: "Samsung", model: "A14", quality: "OLED", manufacturer: "GX", color: "Black", sourceReference: "AF-A14-GX", purchasePrice: "3500", pv1: "5000", pv2: "4700", pv3: "4400", warranty: "30 jours", notes: "TEST · pilote import" },
  { name: "BAT APP IPH 11 GEN", family: "Pièces détachées", subfamily: "Batterie", brand: "Apple", model: "iPhone 11", quality: "AAA", manufacturer: "Générique", color: "", sourceReference: "BAT-IP11", purchasePrice: "1800", pv1: "2800", pv2: "2500", pv3: "2300", warranty: "30 jours", notes: "TEST · pilote import" },
];

function parseCsvLine(line: string, separator: string) {
  const cells: string[] = []; let value = ""; let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"' && quoted && line[index + 1] === '"') { value += '"'; index += 1; }
    else if (character === '"') quoted = !quoted;
    else if (character === separator && !quoted) { cells.push(value.trim()); value = ""; }
    else value += character;
  }
  cells.push(value.trim()); return cells;
}

function parseProductCsv(text: string) {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((line) => line.trim());
  if (lines.length < 2) throw new Error("Le fichier doit contenir un en-tête et au moins une ligne.");
  const separator = (lines[0].match(/;/g)?.length ?? 0) > (lines[0].match(/,/g)?.length ?? 0) ? ";" : ",";
  const aliases: Record<string, keyof ImportRow> = { name: "name", nom: "name", designation: "name", family: "family", famille: "family", subfamily: "subfamily", sous_famille: "subfamily", brand: "brand", marque: "brand", model: "model", modele: "model", quality: "quality", qualite: "quality", type: "quality", manufacturer: "manufacturer", fabricant: "manufacturer", usine: "manufacturer", color: "color", couleur: "color", sourcereference: "sourceReference", source_reference: "sourceReference", reference: "sourceReference", ref: "sourceReference", purchaseprice: "purchasePrice", purchase_price: "purchasePrice", pa: "purchasePrice", prix_achat: "purchasePrice", pv1: "pv1", pv2: "pv2", pv3: "pv3", warranty: "warranty", garantie: "warranty", notes: "notes" };
  const headers = parseCsvLine(lines[0].toLocaleLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""), separator).map((header) => aliases[header.replace(/[\s-]+/g, "_")]);
  if (!headers.includes("name") || !headers.includes("family")) throw new Error("Colonnes obligatoires manquantes : name et family.");
  return lines.slice(1).map((line) => {
    const cells = parseCsvLine(line, separator); const row = Object.fromEntries(importColumns.map((column) => [column, ""])) as ImportRow;
    headers.forEach((header, index) => { if (header) row[header] = cells[index] ?? ""; }); return row;
  }).filter((row) => row.name || row.family);
}

function csvEscape(value: string) { return `"${value.replaceAll('"', '""')}"`; }
function downloadCsv(filename: string, rows: ImportRow[]) {
  const content = [importColumns.join(";"), ...rows.map((row) => importColumns.map((column) => csvEscape(row[column])).join(";"))].join("\n");
  const link = document.createElement("a"); link.href = URL.createObjectURL(new Blob(["\uFEFF" + content], { type: "text/csv;charset=utf-8" })); link.download = filename; link.click(); URL.revokeObjectURL(link.href);
}

function TaxonomyField({ category, label, value, abbreviation, entries, parent = "", required, placeholder, onSelect, onSaved }: {
  category: TaxonomyCategory; label: string; value: string; abbreviation: string; entries: TaxonomyEntry[]; parent?: string; required?: boolean; placeholder: string;
  onSelect: (name: string, abbreviation: string) => void; onSaved: () => Promise<void>;
}) {
  const [expanded, setExpanded] = useState(false);
  const [saving, setSaving] = useState(false);
  const applicable = entries.filter((item) => (!parent || !item.parent || item.parent.toLocaleLowerCase() === parent.toLocaleLowerCase()));
  const filtered = applicable.filter((item) => item.name.toLocaleLowerCase().includes(value.toLocaleLowerCase())).slice(0, 12);
  const selected = applicable.find((item) => item.name.toLocaleLowerCase() === value.trim().toLocaleLowerCase());
  const changed = Boolean(value.trim() && abbreviation.trim() && (!selected || selected.abbreviation !== abbreviation.trim().toUpperCase()));

  async function saveEntry() {
    if (!value.trim() || !abbreviation.trim()) return toast.info("Saisissez le nom et son abréviation.");
    setSaving(true);
    try {
      const response = await fetch("/api/product-taxonomy", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ category, name: value.trim(), abbreviation: abbreviation.trim().toUpperCase(), parent }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error);
      await onSaved(); setExpanded(false); toast.success(selected ? "Abréviation mise à jour" : `${value.trim()} ajouté`);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Enregistrement impossible."); }
    finally { setSaving(false); }
  }

  return <div className="taxonomy-control">
    <Label>{label}{required ? " *" : ""}</Label>
    <div className="taxonomy-row">
      <div className="taxonomy-name">
        <Input value={value} required={required} placeholder={placeholder} autoComplete="off" onFocus={() => setExpanded(true)} onBlur={() => window.setTimeout(() => setExpanded(false), 180)} onChange={(event) => { const match = applicable.find((item) => item.name.toLocaleLowerCase() === event.target.value.toLocaleLowerCase()); onSelect(event.target.value, match?.abbreviation ?? ""); setExpanded(true); }}/>
        <button type="button" className="taxonomy-arrow" aria-label={`Afficher ${label}`} onMouseDown={(event) => event.preventDefault()} onClick={() => setExpanded((current) => !current)}><ChevronDown size={16}/></button>
        {expanded && <div className="taxonomy-menu">{filtered.length ? filtered.map((item) => <button type="button" key={`${item.parent}-${item.name}`} onMouseDown={(event) => event.preventDefault()} onClick={() => { onSelect(item.name, item.abbreviation); setExpanded(false); }}><span>{item.name}</span><b>{item.abbreviation}</b>{item.name === selected?.name && <Check size={14}/>}</button>) : <p>Aucune suggestion — ajoutez-la avec +</p>}</div>}
      </div>
      <div className="taxonomy-abbr"><Input aria-label={`Abréviation ${label}`} value={abbreviation} placeholder="Abr." onChange={(event) => onSelect(value, event.target.value.toUpperCase().replace(/\s+/g, " "))}/><Pencil size={13}/></div>
      <button type="button" className={`taxonomy-save ${changed ? "ready" : ""}`} disabled={!changed || saving} onClick={saveEntry} aria-label={selected ? "Enregistrer l’abréviation" : "Ajouter la valeur"}>{selected ? <Save size={17}/> : <Plus size={18}/>}</button>
    </div>
  </div>;
}

export function StockView({ activeShop, onOpenPurchases, onOpenSales }: { activeShop: ActiveShop; onOpenPurchases: () => void; onOpenSales: () => void }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [taxonomy, setTaxonomy] = useState<Taxonomy>(emptyTaxonomy);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [importRows, setImportRows] = useState<ImportRow[]>([]);
  const [importName, setImportName] = useState("");
  const [importing, setImporting] = useState(false);
  const [family, setFamily] = useState({ name: "", abbreviation: "" });
  const [subfamily, setSubfamily] = useState({ name: "", abbreviation: "" });
  const [brand, setBrand] = useState({ name: "", abbreviation: "" });
  const [model, setModel] = useState({ name: "", abbreviation: "" });
  const [quality, setQuality] = useState({ name: "", abbreviation: "" });
  const [manufacturer, setManufacturer] = useState({ name: "", abbreviation: "" });
  const [color, setColor] = useState({ name: "", abbreviation: "" });

  const loadProducts = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/products?q=${encodeURIComponent(query)}`, { cache: "no-store" });
      const data = await response.json() as { products: Product[]; error?: string };
      if (!response.ok) throw new Error(data.error); setProducts(data.products);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Catalogue indisponible."); }
    finally { setLoading(false); }
  }, [query]);

  const loadTaxonomy = useCallback(async () => {
    try {
      const response = await fetch("/api/product-taxonomy");
      const data = await response.json() as { taxonomy: Taxonomy; error?: string };
      if (!response.ok) throw new Error(data.error); setTaxonomy(data.taxonomy);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Nomenclature indisponible."); }
  }, []);

  useEffect(() => { const timer = window.setTimeout(loadProducts, 220); return () => window.clearTimeout(timer); }, [loadProducts]);
  useEffect(() => { const timer = window.setTimeout(loadTaxonomy, 0); return () => window.clearTimeout(timer); }, [loadTaxonomy]);

  const generatedName = useMemo(() => [subfamily.abbreviation, brand.abbreviation, model.abbreviation, quality.abbreviation, manufacturer.abbreviation, color.abbreviation].map((item) => item.trim().toUpperCase()).filter(Boolean).join(" "), [subfamily, brand, model, quality, manufacturer, color]);
  const totalUnits = useMemo(() => products.reduce((sum, product) => sum + (activeShop === "all" ? product.stock.ProPhone + product.stock.MidouGSM : product.stock[activeShop]), 0), [activeShop, products]);
  const stockedReferences = useMemo(() => products.filter((product) => activeShop === "all" ? product.stock.ProPhone + product.stock.MidouGSM > 0 : product.stock[activeShop] > 0).length, [activeShop, products]);

  function resetForm() {
    setFamily({ name: "", abbreviation: "" }); setSubfamily({ name: "", abbreviation: "" }); setBrand({ name: "", abbreviation: "" });
    setModel({ name: "", abbreviation: "" }); setQuality({ name: "", abbreviation: "" }); setManufacturer({ name: "", abbreviation: "" }); setColor({ name: "", abbreviation: "" });
    setEditingProduct(null);
  }

  function abbreviationFor(category: TaxonomyCategory, name: string, parent = "") {
    return taxonomy[category].find((item) => item.name.toLocaleLowerCase() === name.toLocaleLowerCase() && (!parent || !item.parent || item.parent.toLocaleLowerCase() === parent.toLocaleLowerCase()))?.abbreviation ?? name.toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim().slice(0, 8);
  }

  function editProduct(product: Product) {
    setEditingProduct(product);
    setFamily({ name: product.family, abbreviation: abbreviationFor("family", product.family) });
    setSubfamily({ name: product.subfamily, abbreviation: abbreviationFor("subfamily", product.subfamily, product.family) });
    setBrand({ name: product.brand, abbreviation: abbreviationFor("brand", product.brand) });
    setModel({ name: product.model, abbreviation: abbreviationFor("model", product.model, product.brand) });
    setQuality({ name: product.quality, abbreviation: abbreviationFor("quality", product.quality, product.subfamily) });
    setManufacturer({ name: product.manufacturer, abbreviation: abbreviationFor("manufacturer", product.manufacturer) });
    setColor({ name: product.color, abbreviation: abbreviationFor("color", product.color) });
    setOpen(true);
  }

  async function createProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = event.currentTarget;
    if (!generatedName) return toast.error("Complétez les abréviations pour générer le nom du produit.");
    setSaving(true);
    try {
      const payload = { ...Object.fromEntries(new FormData(form).entries()), id: editingProduct?.id, name: generatedName, family: family.name, subfamily: subfamily.name, brand: brand.name, model: model.name, quality: quality.name, manufacturer: manufacturer.name, color: color.name };
      const response = await fetch("/api/products", { method: editingProduct ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json() as { product?: Product; error?: string };
      if (!response.ok) throw new Error(data.error); toast.success(editingProduct ? `Produit modifié · ${generatedName}` : `Produit créé · ${generatedName}`); setOpen(false); form.reset(); resetForm(); await loadProducts();
    } catch (error) { toast.error(error instanceof Error ? error.message : "Création impossible."); }
    finally { setSaving(false); }
  }

  async function readImportFile(file: File | null) {
    if (!file) return;
    if (!file.name.toLocaleLowerCase().endsWith(".csv")) return toast.error("Choisissez un fichier CSV exporté depuis Excel.");
    try { const rows = parseProductCsv(await file.text()); setImportRows(rows); setImportName(file.name); toast.success(`${rows.length} ligne(s) prête(s) à vérifier.`); }
    catch (error) { setImportRows([]); toast.error(error instanceof Error ? error.message : "Lecture du fichier impossible."); }
  }

  async function importProducts() {
    if (!importRows.length) return toast.info("Ajoutez d’abord un fichier ou l’échantillon TEST.");
    setImporting(true);
    try {
      const response = await fetch("/api/products/import", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rows: importRows }) });
      const data = await response.json() as { created?: number; skipped?: number; errors?: { line: number; message: string }[]; error?: string };
      if (!response.ok) throw new Error(data.error);
      toast.success(`${data.created ?? 0} produit(s) importé(s) · ${data.skipped ?? 0} doublon(s) ignoré(s)${data.errors?.length ? ` · ${data.errors.length} erreur(s)` : ""}`);
      setImportOpen(false); setImportRows([]); setImportName(""); await loadProducts();
    } catch (error) { toast.error(error instanceof Error ? error.message : "Import impossible."); }
    finally { setImporting(false); }
  }

  return <section className="content stock-content">
    <div className="page-heading"><div><span className="eyebrow">CATALOGUE PARTAGÉ · STOCKS SÉPARÉS</span><h2>Stock & produits</h2><p>Identité complète, fabricant et quatre niveaux de prix. Le stock reste séparé entre les deux magasins.</p></div><div className="heading-actions"><Button variant="outline" onClick={onOpenPurchases}><ShoppingCart size={17}/> Bon d’achat</Button><Button variant="outline" onClick={onOpenSales}><ShoppingBag size={17}/> Bon de vente</Button><Button variant="outline" onClick={() => setImportOpen(true)}><Upload size={17}/> Importer fichier</Button><Button className="primary-action" onClick={() => { resetForm(); setOpen(true); }}><PackagePlus size={18}/> Nouveau produit</Button></div></div>
    <div className="metrics stock-metrics"><article><span className="metric-icon blue"><Tag/></span><div><small>Produits référencés</small><strong>{products.length}</strong></div></article><article><span className="metric-icon green"><Boxes/></span><div><small>Unités en stock</small><strong>{totalUnits}</strong></div></article><article><span className="metric-icon orange"><Barcode/></span><div><small>Références disponibles</small><strong>{stockedReferences}</strong></div></article></div>
    <div className="stock-rule"><ShieldCheck size={20}/><div><b>Chaque nouveau produit démarre avec une quantité de 0 dans ProPhone et MidouGSM</b><span>Les quantités seront saisies lors du stock initial ou d’un bon d’achat. PA, PV1, PV2 et PV3 restent modifiables sur la fiche.</span></div></div>
    <section className="panel"><div className="panel-toolbar"><div><h3>Catalogue produits</h3><p>SKU et code-barres automatiques · recherche aussi par référence et fabricant.</p></div><div className="search-box"><Search size={18}/><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Produit, référence, fabricant, marque…"/></div></div><div className="table-wrap"><table className="stock-table"><thead><tr><th>Produit</th><th>Classification</th><th>Marque / modèle</th><th>Qualité / fabricant</th><th>PA / prix de vente</th><th>Stock</th><th></th></tr></thead><tbody>{loading ? <tr><td colSpan={7} className="empty-row">Chargement…</td></tr> : products.length ? products.map((product) => <tr key={product.id}><td><b className="generated-product-name">{product.name}</b><small>{product.sourceReference || product.barcode}</small></td><td><b>{product.family}</b><small>{product.subfamily || "Sans sous-famille"}</small></td><td><b>{product.brand || "—"}</b><small>{product.model || "Tous modèles"}</small></td><td><b>{product.quality || "Standard"}</b><small>{product.manufacturer || "Fabricant non défini"}{product.color ? ` · ${product.color}` : ""}</small></td><td><b>PA {product.purchasePrice.toLocaleString("fr-DZ")} DA</b><small>PV1 {product.pv1.toLocaleString("fr-DZ")} · PV2 {product.pv2.toLocaleString("fr-DZ")} · PV3 {product.pv3.toLocaleString("fr-DZ")}</small></td><td>{activeShop === "all" ? <div className="dual-stock"><span className="prophone">P <b>{product.stock.ProPhone}</b></span><span className="midou">M <b>{product.stock.MidouGSM}</b></span></div> : <strong>{product.stock[activeShop]}</strong>}</td><td><Button variant="outline" size="sm" aria-label={`Modifier ${product.name}`} onClick={() => editProduct(product)}><Pencil size={15}/></Button></td></tr>) : <tr><td colSpan={7} className="empty-row"><PackagePlus size={34}/><b>Aucun produit</b><span>Créez les fiches produits avec une nomenclature uniforme.</span><Button onClick={() => { resetForm(); setOpen(true); }}>Nouveau produit</Button></td></tr>}</tbody></table></div></section>

    <Dialog open={open} onOpenChange={(next) => { setOpen(next); if (!next) resetForm(); }}><DialogContent className="product-dialog sm:max-w-[960px]"><DialogHeader><DialogTitle>{editingProduct ? "Modifier le produit" : "Nouveau produit"}</DialogTitle><DialogDescription>Identité normalisée, fabricant et prix. La quantité initiale reste à 0 jusqu’au premier inventaire ou achat.</DialogDescription></DialogHeader><form key={editingProduct?.id ?? "new"} onSubmit={createProduct} className="product-form">
      <div className="product-name-preview"><div><small>NOM PRODUIT GÉNÉRÉ</small><strong>{generatedName || "AF IPH 11 PM APP ORG BLK"}</strong></div><span><Barcode size={18}/> SKU + Barcode automatiques</span></div>
      <fieldset><legend>Classification liée</legend><div className="form-grid two"><TaxonomyField category="family" label="Famille" value={family.name} abbreviation={family.abbreviation} entries={taxonomy.family} required placeholder="Choisir ou écrire…" onSelect={(name, abbreviation) => { setFamily({ name, abbreviation }); setSubfamily({ name: "", abbreviation: "" }); }} onSaved={loadTaxonomy}/><TaxonomyField category="subfamily" label="Sous-famille" value={subfamily.name} abbreviation={subfamily.abbreviation} entries={taxonomy.subfamily} parent={family.name} required placeholder={family.name ? "Choisir selon la famille…" : "Choisir la famille d’abord"} onSelect={(name, abbreviation) => { setSubfamily({ name, abbreviation }); setQuality({ name: "", abbreviation: "" }); }} onSaved={loadTaxonomy}/></div></fieldset>
      <fieldset><legend>Appareil</legend><div className="form-grid two"><TaxonomyField category="brand" label="Marque" value={brand.name} abbreviation={brand.abbreviation} entries={taxonomy.brand} required placeholder="Samsung, Apple…" onSelect={(name, abbreviation) => { setBrand({ name, abbreviation }); setModel({ name: "", abbreviation: "" }); }} onSaved={loadTaxonomy}/><TaxonomyField category="model" label="Modèle" value={model.name} abbreviation={model.abbreviation} entries={taxonomy.model} parent={brand.name} required placeholder={brand.name ? "A14, iPhone 11 Pro Max…" : "Choisir la marque d’abord"} onSelect={(name, abbreviation) => setModel({ name, abbreviation })} onSaved={loadTaxonomy}/></div></fieldset>
      <fieldset><legend>Caractéristiques</legend><div className="form-grid three"><TaxonomyField category="quality" label="Type / qualité" value={quality.name} abbreviation={quality.abbreviation} entries={taxonomy.quality} parent={subfamily.name} required placeholder="Original, OLED, INCELL…" onSelect={(name, abbreviation) => setQuality({ name, abbreviation })} onSaved={loadTaxonomy}/><TaxonomyField category="manufacturer" label="Fabricant" value={manufacturer.name} abbreviation={manufacturer.abbreviation} entries={taxonomy.manufacturer} placeholder="GX, Bosonni, ACE…" onSelect={(name, abbreviation) => setManufacturer({ name, abbreviation })} onSaved={loadTaxonomy}/><TaxonomyField category="color" label="Couleur" value={color.name} abbreviation={color.abbreviation} entries={taxonomy.color} placeholder="Black, White, Blue…" onSelect={(name, abbreviation) => setColor({ name, abbreviation })} onSaved={loadTaxonomy}/></div><div className="form-grid three product-row"><div><Label>Référence PME / fournisseur</Label><Input name="sourceReference" defaultValue={editingProduct?.sourceReference} placeholder="Référence d’origine…"/></div><div><Label>Garantie</Label><Input name="warranty" defaultValue={editingProduct?.warranty} placeholder="30 jours…"/></div><div><Label>Notes</Label><Textarea name="notes" defaultValue={editingProduct?.notes} placeholder="Détails techniques…"/></div></div></fieldset>
      <fieldset><legend>Prix</legend><div className="form-grid four product-prices"><div><Label>PA · Prix d’achat</Label><Input name="purchasePrice" type="number" min="0" step="1" defaultValue={editingProduct?.purchasePrice ?? 0}/></div><div><Label>PV1 · Détail</Label><Input name="pv1" type="number" min="0" step="1" defaultValue={editingProduct?.pv1 ?? 0}/></div><div><Label>PV2</Label><Input name="pv2" type="number" min="0" step="1" defaultValue={editingProduct?.pv2 ?? 0}/></div><div><Label>PV3</Label><Input name="pv3" type="number" min="0" step="1" defaultValue={editingProduct?.pv3 ?? 0}/></div></div><small className="price-hint">Montants en DA · les quatre prix pourront être corrigés à tout moment.</small></fieldset>
      <input type="hidden" name="name" value={generatedName}/><div className="dialog-buttons"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Annuler</Button><Button className="primary-action" disabled={saving || !generatedName}>{saving ? "Enregistrement…" : editingProduct ? "Enregistrer les modifications" : "Créer le produit"}</Button></div>
    </form></DialogContent></Dialog>
    <Dialog open={importOpen} onOpenChange={(next) => { setImportOpen(next); if (!next) { setImportRows([]); setImportName(""); } }}><DialogContent className="product-import-dialog sm:max-w-[940px]"><DialogHeader><DialogTitle>Importer des produits</DialogTitle><DialogDescription>CSV compatible Excel · aperçu avant enregistrement · les doublons sont ignorés.</DialogDescription></DialogHeader>
      <div className="import-actions"><label className="product-file-picker"><Upload size={20}/><span><b>{importName || "Choisir un fichier CSV"}</b><small>Obligatoires : name, family · compatibles : PA, PV1, PV2, PV3</small></span><input type="file" accept=".csv,text/csv" onChange={(event) => void readImportFile(event.target.files?.[0] ?? null)}/></label><Button variant="outline" onClick={() => downloadCsv("modele-import-produits.csv", [])}><Download size={16}/> Modèle vide</Button><Button variant="outline" onClick={() => { setImportRows(sampleRows); setImportName("echantillon-produits-TEST.csv"); }}><FileSpreadsheet size={16}/> Charger l’échantillon TEST</Button></div>
      <div className="import-rule"><ShieldCheck size={18}/><span><b>Les identités et les prix sont importés, mais jamais les quantités.</b> Chaque produit démarre à 0 dans les deux magasins ; le stock sera renseigné au moment du comptage ou de la réception.</span></div>
      <div className="import-preview"><div className="import-preview-head"><b>Aperçu</b><span>{importRows.length} ligne(s) · maximum 500</span></div><div className="table-wrap"><table><thead><tr><th>Produit</th><th>Famille</th><th>Marque / modèle</th><th>Qualité / fabricant</th><th>PA / PV1 / PV2 / PV3</th></tr></thead><tbody>{importRows.length ? importRows.slice(0, 20).map((row, index) => <tr key={`${row.name}-${index}`}><td><b>{row.name || "Nom manquant"}</b><small>{row.sourceReference || row.subfamily || "—"}</small></td><td>{row.family || <em className="import-error">Obligatoire</em>}</td><td><b>{row.brand || "—"}</b><small>{row.model || "—"}</small></td><td><b>{row.quality || "Standard"}</b><small>{row.manufacturer || "—"}</small></td><td><b>{row.purchasePrice || "0"}</b><small>{row.pv1 || "0"} · {row.pv2 || "0"} · {row.pv3 || "0"}</small></td></tr>) : <tr><td colSpan={5} className="empty-row"><FileSpreadsheet size={34}/><b>Aucun fichier chargé</b><span>Téléchargez le modèle ou utilisez l’échantillon TEST.</span></td></tr>}</tbody></table></div>{importRows.length > 20 && <small className="import-more">+ {importRows.length - 20} autres lignes seront importées</small>}</div>
      <div className="dialog-buttons"><Button variant="outline" onClick={() => setImportOpen(false)}>Annuler</Button><Button className="primary-action" onClick={() => void importProducts()} disabled={importing || !importRows.length}>{importing ? "Import…" : `Importer ${importRows.length || ""} produit(s)`}</Button></div>
    </DialogContent></Dialog>
  </section>;
}
