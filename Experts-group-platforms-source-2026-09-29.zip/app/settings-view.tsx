"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Printer, Save, Settings, ShieldCheck, Users, WalletCards } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type ActiveShop = "all" | "ProPhone" | "MidouGSM";
type ShopSettings = { id: number; shop: string; negativeStockPolicy: string; reserveRepairParts: boolean; lowStockThreshold: number; receiptPaper: string; showSku: boolean; showBarcode: boolean; invoiceFooter: string };

export function SettingsView({ activeShop, onOpenUsers, onOpenCash }: { activeShop: ActiveShop; onOpenUsers: () => void; onOpenCash: () => void }) {
  const [rows, setRows] = useState<ShopSettings[]>([]);
  const [selectedShop, setSelectedShop] = useState(activeShop === "all" ? "ProPhone" : activeShop);
  const [saving, setSaving] = useState(false);
  const load = useCallback(async () => {
    try { const response = await fetch("/api/settings"); const data = await response.json() as { settings?: ShopSettings[]; error?: string }; if (!response.ok) throw new Error(data.error); setRows(data.settings ?? []); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Paramètres indisponibles."); }
  }, []);
  useEffect(() => { const timer = window.setTimeout(() => void load(), 0); return () => window.clearTimeout(timer); }, [load]);
  useEffect(() => { const timer = window.setTimeout(() => { if (activeShop !== "all") setSelectedShop(activeShop); }, 0); return () => window.clearTimeout(timer); }, [activeShop]);
  const current = useMemo(() => rows.find((row) => row.shop === selectedShop), [rows, selectedShop]);
  function update(changes: Partial<ShopSettings>) { setRows((items) => items.map((item) => item.shop === selectedShop ? { ...item, ...changes } : item)); }
  async function save() {
    if (!current) return; setSaving(true);
    try { const response = await fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(current) }); const data = await response.json() as { settings?: ShopSettings; error?: string }; if (!response.ok) throw new Error(data.error); toast.success(`Paramètres ${selectedShop} enregistrés`); await load(); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Enregistrement impossible."); }
    finally { setSaving(false); }
  }
  return <section className="content settings-content">
    <div className="page-heading"><div><span className="eyebrow">RÈGLES MÉTIER · PAR MAGASIN</span><h2>Paramètres</h2><p>Configurez stock, réparations et impression. Les utilisateurs et les caisses restent des modules indépendants.</p></div><Button className="primary-action" onClick={save} disabled={!current || saving}><Save size={17}/>{saving ? "Enregistrement…" : "Enregistrer"}</Button></div>
    <div className="settings-scope"><span>Configurer</span>{["ProPhone", "MidouGSM"].map((shop) => <button key={shop} className={selectedShop === shop ? "active" : ""} onClick={() => setSelectedShop(shop)}>{shop}</button>)}</div>
    {current && <div className="settings-grid">
      <section className="settings-card"><div className="settings-card-title"><Settings/><div><h3>Stock & réparations</h3><p>Comportement opérationnel du magasin.</p></div></div><Label>Vente si stock insuffisant</Label><select value={current.negativeStockPolicy} onChange={(event) => update({ negativeStockPolicy: event.target.value })}><option value="block">Bloquer la vente</option><option value="manager_reason">Directeur avec motif</option><option value="allow">Autoriser</option></select><Label>Seuil d’alerte stock bas</Label><Input type="number" min="0" value={current.lowStockThreshold} onChange={(event) => update({ lowStockThreshold: Number(event.target.value) })}/><label className="toggle-line"><input type="checkbox" checked={current.reserveRepairParts} onChange={(event) => update({ reserveRepairParts: event.target.checked })}/><span><b>Réserver avant consommation</b><small>Le stock physique ne baisse qu’après « Utilisée ».</small></span></label></section>
      <section className="settings-card"><div className="settings-card-title"><Printer/><div><h3>Tickets & factures</h3><p>Présentation des documents imprimés.</p></div></div><Label>Format par défaut</Label><select value={current.receiptPaper} onChange={(event) => update({ receiptPaper: event.target.value })}><option>A4</option><option>A5</option><option>Ticket 80 mm</option></select><div className="check-grid"><label><input type="checkbox" checked={current.showSku} onChange={(event) => update({ showSku: event.target.checked })}/> Afficher SKU</label><label><input type="checkbox" checked={current.showBarcode} onChange={(event) => update({ showBarcode: event.target.checked })}/> Afficher code-barres</label></div><Label>Pied de facture</Label><Textarea value={current.invoiceFooter} onChange={(event) => update({ invoiceFooter: event.target.value })}/></section>
      <section className="settings-card settings-separation"><div className="settings-card-title"><ShieldCheck/><div><h3>Modules séparés</h3><p>Pas de mélange avec les paramètres généraux.</p></div></div><button type="button" onClick={onOpenUsers}><Users/><span><b>Utilisateurs & permissions</b><small>Module dédié pour les accès par magasin.</small></span><em>Ouvrir</em></button><button type="button" onClick={onOpenCash}><WalletCards/><span><b>Caisses</b><small>Soldes, mouvements et transferts.</small></span><em>Ouvrir</em></button></section>
    </div>}
  </section>;
}
