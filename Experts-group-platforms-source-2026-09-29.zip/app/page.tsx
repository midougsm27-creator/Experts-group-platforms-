"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { Archive, Bell, Building2, Camera, Check, ChevronDown, ClipboardList, ClipboardPlus, Eye, FileClock, FileText, MapPin, Menu, PackageSearch, Phone, Plus, ScanLine, Search, Settings2, ShieldCheck, ShoppingBag, ShoppingBasket, ShoppingCart, Smartphone, Store, Trash2, Truck, Upload, Users, WalletCards, Wrench, X } from "lucide-react";
import { toast, Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CashView } from "./cash-view";
import { StockView } from "./stock-view";
import { SalesView } from "./sales-view";
import { PurchaseView } from "./purchase-view";
import { CustomerView } from "./customer-view";
import { SupplierView } from "./supplier-view";
import { PartsRequestsView } from "./parts-requests-view";
import { OrderRequestsView } from "./order-requests-view";
import { SettingsView } from "./settings-view";
import { UsersView } from "./users-view";

type Repair = {
  id: number; ticketNumber: string; customerName: string; customerPhone: string;
  shop: string; deviceType: string; brand: string; model: string; storageLocation: string; partQuality: string; issue: string; price: number;
  deposit: number; technician: string; status: string; createdAt: string;
  usedParts: RepairPart[];
};

type CatalogCategory = "deviceType" | "brand" | "model" | "partQuality" | "issue" | "part" | "storageLocation";
type CatalogEntry = { name: string; parent?: string };
type Catalog = Record<CatalogCategory, CatalogEntry[]>;
type RepairPart = { id: number; productId: number | null; itemName: string; quality: string; quantity: number; reservedQuantity: number; unitPrice: number; status: string; flow: string };
type UsedPart = { key: string; productId: number | null; itemName: string; quality: string; quantity: number };
type Product = { id: number; sku: string; name: string; quality: string; stock: { ProPhone: number; MidouGSM: number } };
type PurchaseLine = { id: number; item: string; quantity: number; purchasePrice: number; salePrice: number; confidence: "high" | "medium" | "low" };
type Purchase = { id: string; supplier: string; shop: string; date: string; total: number; source: string; status: string };
type ActiveShop = "all" | "ProPhone" | "MidouGSM";
type AppUser = { id: number; email: string; name: string; role: string; shops: string[]; permissions: string[]; active: boolean; protected: boolean };

const emptyCatalog: Catalog = { deviceType: [], brand: [], model: [], partQuality: [], issue: [], part: [], storageLocation: [] };

const statuses = ["En attente", "Diagnostic", "En réparation", "Pièce manquante", "Prêt", "Livré", "Non réparé"];
const statusClass: Record<string, string> = {
  "En attente": "status-waiting", Diagnostic: "status-diagnostic",
  "En réparation": "status-progress", "Pièce manquante": "status-part",
  Prêt: "status-ready", Livré: "status-delivered", "Non réparé": "status-closed",
};
const nav = [
  { key: "dashboard", label: "Tableau de bord", icon: Smartphone, disabled: true, permission: "global.view" },
  { key: "repairs", label: "Réparations", icon: Wrench, disabled: false, permission: "repairs.view" },
  { key: "users", label: "Utilisateurs", icon: Users, disabled: false, permission: "users.manage" },
  { key: "orders", label: "Bons de commande", icon: ClipboardList, disabled: false, permission: "orders.view" },
  { key: "purchases", label: "Bons d’achat", icon: ShoppingCart, disabled: false, permission: "purchases.view" },
  { key: "sales", label: "Vente comptoir", icon: ShoppingBag, disabled: false, permission: "sales.use" },
  { key: "salesJournal", label: "Journal des ventes", icon: FileClock, disabled: false, permission: "sales.view" },
  { key: "cash", label: "Caisses", icon: WalletCards, disabled: false, permission: "cash.view" },
  { key: "clients", label: "Clients", icon: Phone, disabled: false, permission: "customers.manage" },
  { key: "suppliers", label: "Fournisseurs", icon: Truck, disabled: false, permission: "suppliers.manage" },
  { key: "stock", label: "Stock & pièces", icon: PackageSearch, disabled: false, permission: "stock.view" },
  { key: "settings", label: "Paramètres", icon: Settings2, disabled: false, permission: "settings.manage" },
];

const initialPurchases: Purchase[] = [
  { id: "ACH-PRO-2026-00124", supplier: "Mobile Parts Distribution", shop: "ProPhone", date: "14 sept. 2026", total: 86500, source: "PDF", status: "Confirmée" },
  { id: "ACH-MID-2026-00038", supplier: "ProPhone", shop: "MidouGSM", date: "13 sept. 2026", total: 32400, source: "Transfert interne", status: "Reçue" },
];

function money(value: number) {
  return new Intl.NumberFormat("fr-DZ").format(value) + " DA";
}

function todayLabel() {
  return new Intl.DateTimeFormat("fr-DZ", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
}

function CatalogField({ id, name, label, value, entries, placeholder, required, parent, onChange, onAdd }: {
  id: string; name: string; label: string; value: string; entries: CatalogEntry[]; placeholder: string;
  required?: boolean; parent?: string; onChange: (value: string) => void; onAdd: (name: string) => Promise<void>;
}) {
  const [expanded, setExpanded] = useState(false);
  const [adding, setAdding] = useState(false);
  const [searchText, setSearchText] = useState("");
  const applicable = entries.filter((entry) => !parent || entry.parent?.toLocaleLowerCase() === parent.toLocaleLowerCase());
  const filtered = applicable.filter((entry) => !searchText || entry.name.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()));
  const exactMatch = entries.some((entry) => (!parent || entry.parent?.toLocaleLowerCase() === parent.toLocaleLowerCase()) && entry.name.toLocaleLowerCase() === value.trim().toLocaleLowerCase());

  async function addCurrent() {
    const candidate = value.trim() || window.prompt(`Nouvelle valeur — ${label}`)?.trim() || "";
    if (!candidate) return;
    if (entries.some((entry) => (!parent || entry.parent?.toLocaleLowerCase() === parent.toLocaleLowerCase()) && entry.name.toLocaleLowerCase() === candidate.toLocaleLowerCase())) {
      onChange(candidate); setExpanded(false); return toast.info("Cette valeur existe déjà.");
    }
    setAdding(true);
    try { await onAdd(candidate); onChange(candidate); setExpanded(false); } finally { setAdding(false); }
  }

  return <div className="catalog-control">
    <Label htmlFor={id}>{label}{required ? " *" : ""}</Label>
    <div className="catalog-input-wrap">
      <Input id={id} name={name} value={value} required={required} autoComplete="off" placeholder={placeholder}
        onFocus={(event) => { setSearchText(""); setExpanded(true); event.currentTarget.select(); }} onBlur={() => window.setTimeout(() => { setExpanded(false); setSearchText(""); }, 160)}
        onChange={(event) => { onChange(event.target.value); setSearchText(event.target.value); setExpanded(true); }}/>
      <button type="button" className="catalog-arrow" aria-label={`Afficher ${label}`} onMouseDown={(event) => event.preventDefault()} onClick={() => { if (expanded) setExpanded(false); else { setSearchText(""); setExpanded(true); } }}><ChevronDown size={16}/></button>
      <button type="button" className="catalog-plus" aria-label={`Ajouter ${label}`} disabled={adding} onMouseDown={(event) => event.preventDefault()} onClick={addCurrent}><Plus size={17}/></button>
    </div>
    {expanded && <div className="catalog-menu">
      {filtered.length ? filtered.map((entry) => <button type="button" key={`${entry.parent ?? ""}-${entry.name}`} onMouseDown={(event) => event.preventDefault()} onClick={() => { onChange(entry.name); setSearchText(""); setExpanded(false); }}><span>{entry.name}</span>{entry.name.toLocaleLowerCase() === value.toLocaleLowerCase() && <Check size={15}/>}</button>) : <p>Aucune suggestion</p>}
      {value.trim() && !exactMatch && <button type="button" className="catalog-add-row" onMouseDown={(event) => event.preventDefault()} onClick={addCurrent}><Plus size={16}/> Ajouter « {value.trim()} »</button>}
    </div>}
  </div>;
}

export default function MobileService() {
  const [repairs, setRepairs] = useState<Repair[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeView, setActiveView] = useState<"repairs" | "orders" | "purchases" | "purchasesLegacy" | "sales" | "salesJournal" | "cash" | "stock" | "clients" | "suppliers" | "users" | "settings">("repairs");
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [accountLoading, setAccountLoading] = useState(true);
  const [accountError, setAccountError] = useState("");
  const [repairSection, setRepairSection] = useState<"list" | "needs">("list");
  const [purchaseOpen, setPurchaseOpen] = useState(false);
  const [purchaseStep, setPurchaseStep] = useState<"upload" | "review">("upload");
  const [invoiceFile, setInvoiceFile] = useState<{ name: string; type: string; url: string } | null>(null);
  const [purchaseShop, setPurchaseShop] = useState("ProPhone");
  const [supplier, setSupplier] = useState("");
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [purchaseLines, setPurchaseLines] = useState<PurchaseLine[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [purchases, setPurchases] = useState<Purchase[]>(initialPurchases);
  const [activeShop, setActiveShop] = useState<ActiveShop>("all");
  const [catalog, setCatalog] = useState<Catalog>(emptyCatalog);
  const [deviceType, setDeviceType] = useState("");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [storageLocation, setStorageLocation] = useState("Comptoir réception");
  const [issue, setIssue] = useState("");
  const [usedParts, setUsedParts] = useState<UsedPart[]>([{ key: "part-1", productId: null, itemName: "", quality: "", quantity: 1 }]);
  const [products, setProducts] = useState<Product[]>([]);
  const [basketRepair, setBasketRepair] = useState<Repair | null>(null);
  const [basketProductId, setBasketProductId] = useState<number | null>(null);
  const [basketQuantity, setBasketQuantity] = useState(1);
  const [basketSaving, setBasketSaving] = useState(false);

  useEffect(() => { const timer = window.setTimeout(async () => { try { const response = await fetch("/api/auth/me", { cache: "no-store" }); const data = await response.json() as { user?: AppUser; error?: string }; if (!response.ok || !data.user) throw new Error(data.error || "Compte indisponible."); setCurrentUser(data.user); setActiveShop(data.user.permissions.includes("global.view") ? "all" : (data.user.shops[0] as ActiveShop) || "ProPhone"); const first = nav.find((item) => !item.disabled && data.user!.permissions.includes(item.permission)); if (!data.user.permissions.includes("repairs.view") && first) setActiveView(first.key as typeof activeView); } catch (error) { setAccountError(error instanceof Error ? error.message : "Compte indisponible."); } finally { setAccountLoading(false); } }, 0); return () => window.clearTimeout(timer); }, []);
  const can = useCallback((permission: string) => Boolean(currentUser?.permissions.includes(permission)), [currentUser]);
  const visibleNav = useMemo(() => nav.filter((item) => item.disabled || can(item.permission)), [can]);

  const loadRepairs = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/repairs?q=${encodeURIComponent(query)}&shop=${encodeURIComponent(activeShop)}`);
      const data = await response.json() as { repairs: Repair[]; error?: string };
      if (!response.ok) throw new Error(data.error);
      setRepairs(data.repairs);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Impossible de charger les réparations.");
    } finally {
      setLoading(false);
    }
  }, [query, activeShop]);

  useEffect(() => {
    const timer = setTimeout(loadRepairs, 250);
    return () => clearTimeout(timer);
  }, [loadRepairs]);

  const loadCatalog = useCallback(async () => {
    try {
      const response = await fetch("/api/catalog");
      const data = await response.json() as { catalog: Catalog; error?: string };
      if (!response.ok) throw new Error(data.error);
      setCatalog(data.catalog);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Catalogue indisponible.");
    }
  }, []);

  useEffect(() => { const timer = window.setTimeout(() => void loadCatalog(), 0); return () => window.clearTimeout(timer); }, [loadCatalog]);

  const loadProducts = useCallback(async () => {
    try {
      const response = await fetch("/api/products", { cache: "no-store" });
      const data = await response.json() as { products?: Product[]; error?: string };
      if (!response.ok) throw new Error(data.error);
      setProducts(data.products ?? []);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Produits indisponibles."); }
  }, []);

  useEffect(() => { const timer = window.setTimeout(() => void loadProducts(), 0); return () => window.clearTimeout(timer); }, [loadProducts]);

  async function addCatalogEntry(category: CatalogCategory, entryName: string, parent = "") {
    const response = await fetch("/api/catalog", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ category, name: entryName, parent }) });
    const data = await response.json() as { error?: string };
    if (!response.ok) { toast.error(data.error ?? "Ajout impossible."); throw new Error(data.error); }
    await loadCatalog();
    toast.success(`${entryName} ajouté au catalogue`);
  }

  function resetDeviceFields() {
    setDeviceType(""); setBrand(""); setModel(""); setStorageLocation("Comptoir réception"); setIssue("");
    setUsedParts([{ key: `part-${Date.now()}`, productId: null, itemName: "", quality: "", quantity: 1 }]);
  }

  function updateUsedPart(key: string, changes: Partial<UsedPart>) {
    setUsedParts((items) => items.map((item) => item.key === key ? { ...item, ...changes } : item));
  }

  function addPartRow() {
    setUsedParts((items) => [...items, { key: `part-${Date.now()}-${items.length}`, productId: null, itemName: "", quality: "", quantity: 1 }]);
  }

  function openNewRepair() {
    if (activeShop === "all") return toast.info("Choisissez ProPhone ou MidouGSM avant d’ajouter une réparation.");
    setOpen(true);
  }

  function openNewPurchase() {
    if (activeShop === "all") return toast.info("Choisissez le magasin qui reçoit l’achat.");
    setPurchaseShop(activeShop);
    setPurchaseOpen(true);
  }

  function resetPurchase() {
    if (invoiceFile?.url) URL.revokeObjectURL(invoiceFile.url);
    setInvoiceFile(null); setPurchaseStep("upload"); setPurchaseShop("ProPhone"); setSupplier("");
    setInvoiceNumber(""); setPurchaseLines([]); setAnalyzing(false);
  }

  function selectInvoice(file?: File) {
    if (!file) return;
    if (invoiceFile?.url) URL.revokeObjectURL(invoiceFile.url);
    setInvoiceFile({ name: file.name, type: file.type, url: URL.createObjectURL(file) });
    setPurchaseStep("upload");
  }

  function analyzeInvoice() {
    if (!invoiceFile) return;
    setAnalyzing(true);
    window.setTimeout(() => {
      setSupplier("Mobile Parts Distribution");
      setInvoiceNumber("FAC-2026-0914");
      setPurchaseLines([
        { id: 1, item: "Écran Samsung A14 OLED", quantity: 5, purchasePrice: 6800, salePrice: 0, confidence: "high" },
        { id: 2, item: "Batterie iPhone 11", quantity: 10, purchasePrice: 2150, salePrice: 0, confidence: "medium" },
        { id: 3, item: "Nappe de charge Redmi Note 12", quantity: 4, purchasePrice: 1250, salePrice: 0, confidence: "low" },
      ]);
      setPurchaseStep("review"); setAnalyzing(false);
      toast.success("Facture analysée — vérifiez les lignes signalées");
    }, 850);
  }

  function updatePurchaseLine(id: number, changes: Partial<PurchaseLine>) {
    setPurchaseLines((lines) => lines.map((line) => line.id === id ? { ...line, ...changes } : line));
  }

  function confirmPurchase() {
    const total = purchaseLines.reduce((sum, line) => sum + line.quantity * line.purchasePrice, 0);
    const prefix = purchaseShop === "ProPhone" ? "PRO" : "MID";
    setPurchases((items) => [{ id: `ACH-${prefix}-2026-${String(items.length + 125).padStart(5, "0")}`, supplier: supplier || "Fournisseur à confirmer", shop: purchaseShop, date: "Aujourd’hui", total, source: invoiceFile?.type.includes("pdf") ? "PDF" : "Photo / manuscrite", status: "Brouillon vérifié" }, ...items]);
    setPurchaseOpen(false); resetPurchase();
    toast.success("Achat enregistré avec sa facture originale");
  }

  const counts = useMemo(() => ({
    total: repairs.length,
    progress: repairs.filter((item) => item.status === "En réparation" || item.status === "Diagnostic").length,
    ready: repairs.filter((item) => item.status === "Prêt").length,
  }), [repairs]);
  const filteredPurchases = useMemo(() => activeShop === "all" ? purchases : purchases.filter((item) => item.shop === activeShop), [activeShop, purchases]);
  const branchSummaries = useMemo(() => (["ProPhone", "MidouGSM"] as const).map((branch) => ({
    branch,
    repairs: repairs.filter((item) => item.shop === branch).length,
    purchases: purchases.filter((item) => item.shop === branch).length,
    ready: repairs.filter((item) => item.shop === branch && item.status === "Prêt").length,
  })), [repairs, purchases]);

  async function createRepair(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    const formElement = event.currentTarget;
    if (activeShop === "all") return;
    const payload = { ...Object.fromEntries(new FormData(formElement).entries()), shop: activeShop, issue, usedParts: usedParts.filter((part) => part.productId) };
    try {
      const response = await fetch("/api/repairs", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
      const data = await response.json() as { repair: { ticketNumber: string }; error?: string };
      if (!response.ok) throw new Error(data.error);
      toast.success(`Fiche ${data.repair.ticketNumber} enregistrée`);
      setOpen(false);
      formElement.reset();
      resetDeviceFields();
      await loadRepairs();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Enregistrement impossible.");
    } finally {
      setSaving(false);
    }
  }

  async function refreshBasket() {
    if (!basketRepair) return;
    const response = await fetch(`/api/repair-parts?repairId=${basketRepair.id}`);
    const data = await response.json() as { parts?: RepairPart[]; error?: string };
    if (!response.ok) throw new Error(data.error);
    setBasketRepair((current) => current ? { ...current, usedParts: data.parts ?? [] } : current);
  }

  async function addBasketPart() {
    if (!basketRepair || !basketProductId) return toast.info("Choisissez un produit.");
    setBasketSaving(true);
    try {
      const response = await fetch("/api/repair-parts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ repairId: basketRepair.id, productId: basketProductId, quantity: basketQuantity }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error);
      toast.success("Pièce ajoutée au panier"); setBasketProductId(null); setBasketQuantity(1); await loadRepairs(); await refreshBasket();
    } catch (error) { toast.error(error instanceof Error ? error.message : "Ajout impossible."); }
    finally { setBasketSaving(false); }
  }

  async function changePartStatus(part: RepairPart, status: string) {
    setBasketSaving(true);
    try {
      const response = await fetch("/api/repair-parts", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: part.id, status }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error);
      toast.success(status === "Utilisée" ? "Pièce consommée du stock" : status === "Non utilisée" ? "Pièce libérée / retournée au stock" : "État mis à jour");
      await loadRepairs(); await refreshBasket();
    } catch (error) { toast.error(error instanceof Error ? error.message : "Mise à jour impossible."); }
    finally { setBasketSaving(false); }
  }

  async function updateStatus(id: number, status: string) {
    const previous = repairs;
    setRepairs((items) => items.map((item) => item.id === id ? { ...item, status } : item));
    const response = await fetch(`/api/repairs/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status, shop: repairs.find((item) => item.id === id)?.shop }),
    });
    if (!response.ok) {
      setRepairs(previous);
      toast.error("Le statut n’a pas été modifié.");
    } else {
      toast.success("Statut mis à jour");
    }
  }

  async function updateLocation(id: number, nextLocation: string) {
    const previous = repairs;
    setRepairs((items) => items.map((item) => item.id === id ? { ...item, storageLocation: nextLocation } : item));
    const response = await fetch(`/api/repairs/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storageLocation: nextLocation, shop: repairs.find((item) => item.id === id)?.shop }),
    });
    if (!response.ok) {
      setRepairs(previous);
      toast.error("L’emplacement n’a pas été modifié.");
    } else {
      toast.success("Emplacement mis à jour");
    }
  }

  function printTicket(repair: Repair) {
    const popup = window.open("", "_blank", "width=430,height=650");
    if (!popup) return toast.error("Autorisez les fenêtres pour imprimer le ticket.");
    popup.document.write(`<!doctype html><html><head><title>${repair.ticketNumber}</title><style>body{font-family:Arial;padding:24px;color:#111}h1{color:#225ad6;margin:0}.line{border-top:1px dashed #777;margin:16px 0}.row{margin:9px 0}small{color:#666}@media print{button{display:none}}</style></head><body><h1>Mobile Service</h1><small>Experts Group · Sérieux • Qualité • Savoir-faire</small><div class="line"></div><div class="row"><b>Ticket:</b> ${repair.ticketNumber}</div><div class="row"><b>Client:</b> ${repair.customerName}</div><div class="row"><b>Téléphone:</b> ${repair.customerPhone}</div><div class="row"><b>Appareil:</b> ${repair.brand} ${repair.model}</div><div class="row"><b>Panne:</b> ${repair.issue}</div><div class="row"><b>Prix:</b> ${money(repair.price)}</div><div class="row"><b>Versement:</b> ${money(repair.deposit)}</div><div class="line"></div><small>Conservez ce ticket jusqu’à la récupération de l’appareil.</small><br/><br/><button onclick="window.print()">Imprimer</button></body></html>`);
    popup.document.close();
  }

  if (accountLoading) return <div className="account-gate"><div className="brand-mark">EG</div><b>Vérification du compte…</b><span>Experts Group · Mobile Service</span></div>;
  if (accountError || !currentUser) return <div className="account-gate denied"><ShieldCheck/><b>Accès non autorisé</b><span>{accountError || "Ce compte n’est pas actif."}</span><small>Demandez à l’administrateur d’ajouter votre e-mail aux utilisateurs.</small></div>;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="brand-block">
          <div className="brand-mark">EG</div>
          <div><strong>Experts Group</strong><span>Mobile Service</span></div>
          <button className="mobile-close" onClick={() => setMenuOpen(false)} aria-label="Fermer"><X size={20}/></button>
        </div>
        <nav>
          <p className="nav-caption">ESPACE DE TRAVAIL</p>
          {visibleNav.map(({ key, label, icon: Icon, disabled }) => (
            <button key={label} className={`nav-item ${activeView === key ? "active" : ""}`} disabled={disabled} onClick={() => { if (!disabled) { setActiveView(key as typeof activeView); setMenuOpen(false); } }}>
              <Icon size={19}/><span>{label}</span>{disabled && <small>Bientôt</small>}
            </button>
          ))}
        </nav>
        <div className="sidebar-scope"><small>ESPACE ACTIF</small><b>{activeShop === "all" ? "Vue globale" : activeShop}</b><span><ShieldCheck size={13}/> Données isolées</span></div>
        <div className="sidebar-footer"><span className="online-dot"/> Système opérationnel</div>
      </aside>

      <main className="workspace">
        <header className="topbar">
          <button className="menu-button" onClick={() => setMenuOpen(true)} aria-label="Menu"><Menu size={22}/></button>
          <div><p>{todayLabel()}</p><h1>{activeView === "repairs" ? "Atelier de réparation" : activeView === "orders" ? "Bons de commande" : activeView === "purchases" ? "Gestion des achats" : activeView === "sales" ? (activeShop === "all" ? "Ventes · vue globale" : "Vente comptoir") : activeView === "salesJournal" ? "Journal des ventes" : activeView === "cash" ? "Gestion des caisses" : activeView === "clients" ? "Gestion des clients" : activeView === "suppliers" ? "Gestion des fournisseurs" : activeView === "users" ? "Utilisateurs & permissions" : activeView === "settings" ? "Paramètres" : "Catalogue & stock"}</h1></div>
          <div className="shop-switcher" aria-label="Choisir l’espace de travail">
            {can("global.view") && <button className={activeShop === "all" ? "active" : ""} onClick={() => setActiveShop("all")}><Building2 size={15}/><span>Vue globale</span></button>}
            {currentUser?.shops.includes("ProPhone") && <button className={activeShop === "ProPhone" ? "active prophone" : ""} onClick={() => setActiveShop("ProPhone")}><Store size={15}/><span>ProPhone</span></button>}
            {currentUser?.shops.includes("MidouGSM") && <button className={activeShop === "MidouGSM" ? "active midou" : ""} onClick={() => setActiveShop("MidouGSM")}><Store size={15}/><span>MidouGSM</span></button>}
          </div>
          <div className="top-actions">
            <button className="icon-button" aria-label="Notifications"><Bell size={20}/></button>
            <div className="user-chip"><span>{currentUser?.name.split(" ").map((item) => item[0]).join("").slice(0, 2).toUpperCase() || "…"}</span><div><b>{currentUser?.name || "Chargement"}</b><small>{currentUser?.role || "Compte"}</small></div><ChevronDown size={16}/></div>
          </div>
        </header>

        {activeView === "repairs" ? repairSection === "needs" ? <PartsRequestsView activeShop={activeShop} onBack={() => setRepairSection("list")}/> : <section className="content">
          <div className="repair-subnav"><button className="active"><Wrench size={16}/> Réparations</button><button onClick={() => setRepairSection("needs")}><ClipboardList size={16}/> Besoins réparation</button></div>
          <div className="page-heading">
            <div><span className="eyebrow">{activeShop === "all" ? "SUPERVISION · 2 MAGASINS" : `ESPACE · ${activeShop.toUpperCase()}`}</span><h2>Réparations</h2><p>{activeShop === "all" ? "Surveillez les deux magasins sans mélanger leurs fiches." : `Réception, suivi et livraison propres à ${activeShop}.`}</p></div>
            {can("repairs.create") && <Button className="primary-action" onClick={openNewRepair}><ClipboardPlus size={19}/> Nouvelle réparation</Button>}
          </div>

          {activeShop === "all" && <div className="global-branches">{branchSummaries.map(({ branch, repairs: repairCount, purchases: purchaseCount, ready }) => <article key={branch} className={branch === "ProPhone" ? "prophone" : "midou"}><div className="branch-heading"><span className="branch-logo">{branch === "ProPhone" ? "P" : "M"}</span><div><small>ESPACE INDÉPENDANT</small><h3>{branch}</h3></div><span className="isolated"><ShieldCheck size={14}/> Isolé</span></div><div className="branch-stats"><span><b>{repairCount}</b> réparations</span><span><b>{ready}</b> prêtes</span><span><b>{purchaseCount}</b> achats</span></div><button onClick={() => setActiveShop(branch)}>Ouvrir l’espace <ChevronDown size={14}/></button></article>)}</div>}

          <div className="metrics">
            <article><span className="metric-icon blue"><Smartphone/></span><div><small>Fiches affichées</small><strong>{counts.total}</strong></div></article>
            <article><span className="metric-icon orange"><Wrench/></span><div><small>En cours</small><strong>{counts.progress}</strong></div></article>
            <article><span className="metric-icon green"><Phone/></span><div><small>Prêtes</small><strong>{counts.ready}</strong></div></article>
          </div>

          <section className="panel">
            <div className="panel-toolbar">
              <div><h3>Liste des réparations</h3><p>Les fiches les plus récentes apparaissent en premier.</p></div>
              <div className="search-box"><Search size={18}/><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Client, téléphone, ticket ou modèle…"/></div>
            </div>
            <div className="table-wrap">
              <table>
                <thead><tr><th>Ticket / date</th><th>Client</th><th>Appareil & panne</th><th>Emplacement</th><th>Technicien</th><th>Prix / reste</th><th>Statut</th><th/></tr></thead>
                <tbody>
                  {loading ? <tr><td colSpan={8} className="empty-row">Chargement…</td></tr> : repairs.length === 0 ? (
                    <tr><td colSpan={8} className="empty-row"><div className="empty-icon"><Wrench/></div><b>Aucune réparation enregistrée</b><span>{activeShop === "all" ? "Aucune fiche dans les deux espaces." : `Ajoutez la première fiche de ${activeShop}.`}</span>{activeShop !== "all" && <Button onClick={openNewRepair}>Nouvelle réparation</Button>}</td></tr>
                  ) : repairs.map((repair) => (
                    <tr key={repair.id}>
                      <td><b>{repair.ticketNumber}</b><small>{new Date(repair.createdAt + "Z").toLocaleString("fr-DZ", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</small></td>
                      <td><b>{repair.customerName}</b><small>{repair.customerPhone} · {repair.shop}</small></td>
                      <td><b>{repair.brand} {repair.model}</b><small>{repair.deviceType} · {repair.issue}</small>{repair.usedParts?.length ? <span className="repair-parts-summary">{repair.usedParts.filter((part) => part.status !== "Non utilisée").length} pièce(s) prévue(s)</span> : null}</td>
                      <td><div className="location-select"><MapPin size={15}/><select value={repair.storageLocation} onChange={(event) => updateLocation(repair.id, event.target.value)}>{catalog.storageLocation.map((location) => <option key={location.name}>{location.name}</option>)}{repair.storageLocation && !catalog.storageLocation.some((location) => location.name === repair.storageLocation) && <option>{repair.storageLocation}</option>}</select></div></td>
                      <td>{repair.technician}</td>
                      <td><b>{money(repair.price)}</b><small>Reste: {money(Math.max(0, repair.price - repair.deposit))}</small></td>
                      <td><select className={`status-select ${statusClass[repair.status] ?? ""}`} value={repair.status} disabled={!can("repairs.status")} onChange={(e) => updateStatus(repair.id, e.target.value)}>{statuses.map((status) => <option key={status}>{status}</option>)}</select></td>
                      <td><div className="repair-row-actions">{can("repairs.edit") && <button type="button" className="basket-button" title="Panier des pièces" onClick={() => setBasketRepair(repair)}><ShoppingBasket size={17}/>{repair.usedParts?.filter((part) => part.status !== "Non utilisée").length ? <em>{repair.usedParts.filter((part) => part.status !== "Non utilisée").length}</em> : null}</button>}{can("printing.use") && <Button variant="outline" size="sm" onClick={() => printTicket(repair)}>Ticket</Button>}</div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </section> : activeView === "orders" ? <OrderRequestsView key={activeShop} activeShop={activeShop}/> : activeView === "purchases" ? <PurchaseView activeShop={activeShop}/> : activeView === "purchasesLegacy" ? <section className="content purchases-content">
          <div className="page-heading">
            <div><span className="eyebrow">ENTRÉES DE STOCK · MODULE INDÉPENDANT</span><h2>Bons d’achat</h2><p>{activeShop === "all" ? "Vue consolidée avec origine de chaque facture clairement identifiée." : `Bons d’achat et factures propres à ${activeShop}.`}</p></div>
            <Button className="primary-action" onClick={openNewPurchase}><Plus size={19}/> Nouveau bon d’achat</Button>
          </div>

          {activeShop === "all" && <div className="separation-notice"><ShieldCheck size={20}/><div><b>Vue de supervision</b><span>Les factures sont visibles ensemble uniquement pour l’administrateur. Chaque magasin conserve ses propres achats.</span></div></div>}

          <div className="metrics purchase-metrics">
            <article><span className="metric-icon blue"><FileText/></span><div><small>Factures archivées</small><strong>{filteredPurchases.length}</strong></div></article>
            <article><span className="metric-icon orange"><ScanLine/></span><div><small>À vérifier</small><strong>1</strong></div></article>
            <article><span className="metric-icon green"><Archive/></span><div><small>Documents liés</small><strong>{filteredPurchases.length}</strong></div></article>
          </div>

          <section className="invoice-feature">
            <div className="invoice-feature-icon"><ScanLine size={26}/></div>
            <div><span>NOUVEAU</span><h3>Importer et analyser une facture</h3><p>PDF, photo ou facture manuscrite : l’original reste archivé avec la fiche d’achat numérique.</p></div>
            <Button variant="outline" onClick={openNewPurchase}><Upload size={17}/> Importer</Button>
          </section>

          <section className="panel">
            <div className="panel-toolbar"><div><h3>Derniers achats</h3><p>Les données de ProPhone et MidouGSM restent séparées.</p></div><div className="search-box"><Search size={18}/><Input placeholder="Fournisseur, facture ou produit…"/></div></div>
            <div className="table-wrap"><table className="purchases-table"><thead><tr><th>Référence</th><th>Fournisseur</th><th>Magasin</th><th>Document source</th><th>Total</th><th>Statut</th><th/></tr></thead><tbody>{filteredPurchases.map((purchase) => <tr key={purchase.id}><td><b>{purchase.id}</b><small>{purchase.date}</small></td><td><b>{purchase.supplier}</b><small>Facture fournisseur liée</small></td><td><span className={`shop-badge ${purchase.shop === "ProPhone" ? "prophone" : "midou"}`}>{purchase.shop}</span></td><td><span className="source-cell"><FileText size={16}/>{purchase.source}</span></td><td><b>{money(purchase.total)}</b></td><td><span className="purchase-status">{purchase.status}</span></td><td><Button variant="outline" size="sm"><Eye size={15}/> Voir</Button></td></tr>)}</tbody></table></div>
          </section>
        </section> : activeView === "sales" ? <SalesView activeShop={activeShop} startMode={activeShop === "all" ? "journal" : "sale"} onOpenJournal={() => setActiveView("salesJournal")} onNewSale={() => setActiveView("sales")}/>
          : activeView === "salesJournal" ? <SalesView activeShop={activeShop} startMode="journal" onNewSale={() => setActiveView("sales")}/>
          : activeView === "cash" ? <CashView activeShop={activeShop}/>
          : activeView === "clients" ? <CustomerView activeShop={activeShop}/>
          : activeView === "suppliers" ? <SupplierView activeShop={activeShop}/>
          : activeView === "users" ? <UsersView/>
          : activeView === "settings" ? <SettingsView activeShop={activeShop} onOpenUsers={() => setActiveView("users")} onOpenCash={() => setActiveView("cash")}/>
          : <StockView activeShop={activeShop} onOpenPurchases={() => setActiveView("purchases")} onOpenSales={() => setActiveView("sales")}/>}
      </main>

      <Dialog open={open} onOpenChange={(nextOpen) => { setOpen(nextOpen); if (!nextOpen) resetDeviceFields(); }}>
        <DialogContent className="repair-dialog sm:max-w-[820px]">
          <DialogHeader><DialogTitle>Nouvelle réparation</DialogTitle><DialogDescription>Créez la fiche de réception du client et de son appareil.</DialogDescription></DialogHeader>
          <form onSubmit={createRepair} className="repair-form">
            <div className={`dialog-shop-context ${activeShop === "MidouGSM" ? "midou" : "prophone"}`}><Store size={18}/><div><small>ENREGISTREMENT DANS</small><b>{activeShop === "all" ? "Sélection requise" : activeShop}</b></div><span><ShieldCheck size={14}/> Données séparées</span></div>
            <fieldset><legend>Client</legend><div className="form-grid"><div><Label htmlFor="customerName">Nom complet *</Label><Input id="customerName" name="customerName" required placeholder="Ex. Ahmed Benali"/></div><div><Label htmlFor="customerPhone">Téléphone *</Label><Input id="customerPhone" name="customerPhone" required inputMode="tel" placeholder="05 / 06 / 07…"/></div></div></fieldset>
            <fieldset><legend>Appareil</legend><div className="form-grid two"><CatalogField id="deviceType" name="deviceType" label="Type d’appareil" value={deviceType} entries={catalog.deviceType} placeholder="Écrire ou choisir…" required onChange={setDeviceType} onAdd={(value) => addCatalogEntry("deviceType", value)}/><CatalogField id="brand" name="brand" label="Marque" value={brand} entries={catalog.brand} placeholder="Samsung, Apple…" required onChange={(value) => { setBrand(value); setModel(""); }} onAdd={(value) => addCatalogEntry("brand", value)}/></div><div className="form-grid three device-details"><CatalogField id="model" name="model" label="Modèle" value={model} entries={catalog.model} parent={brand} placeholder={brand ? "A15, iPhone 13…" : "Choisir la marque d’abord"} required onChange={setModel} onAdd={(value) => addCatalogEntry("model", value, brand)}/><CatalogField id="issue" name="issue" label="Panne signalée" value={issue} entries={catalog.issue} placeholder="Charge, écran cassé…" required onChange={setIssue} onAdd={(value) => addCatalogEntry("issue", value)}/><CatalogField id="storageLocation" name="storageLocation" label="Emplacement de l’appareil" value={storageLocation} entries={catalog.storageLocation} placeholder="Tiroir, technicien…" required onChange={setStorageLocation} onAdd={(value) => addCatalogEntry("storageLocation", value)}/></div></fieldset>
            <fieldset><legend>Pièces prévues / besoins</legend><div className={`part-flow ${activeShop === "MidouGSM" ? "order" : "stock"}`}><PackageSearch size={18}/><span>Choisissez uniquement depuis le catalogue produits. Disponible = réservation ; manque = commande automatique.</span></div><div className="parts-list">{usedParts.map((part, index) => <div className="part-row product-part-row" key={part.key}><div><Label htmlFor={`part-${part.key}`}>{index === 0 ? "Produit" : `Produit ${index + 1}`}</Label><select id={`part-${part.key}`} value={part.productId ?? ""} onChange={(event) => { const product = products.find((item) => item.id === Number(event.target.value)); updateUsedPart(part.key, { productId: product?.id ?? null, itemName: product?.name ?? "", quality: product?.quality ?? "" }); }}><option value="">Choisir dans le catalogue…</option>{products.map((product) => <option key={product.id} value={product.id}>{product.sku} · {product.name} · Stock {activeShop === "all" ? product.stock.ProPhone + product.stock.MidouGSM : product.stock[activeShop]}</option>)}</select></div><div className="selected-part-info"><Label>Qualité / disponibilité</Label><span><b>{part.quality || "Selon fiche produit"}</b><small>{part.productId ? `${activeShop}: ${products.find((item) => item.id === part.productId)?.stock[activeShop === "all" ? "ProPhone" : activeShop] ?? 0} en stock` : "Sélection requise"}</small></span></div><div><Label htmlFor={`quantity-${part.key}`}>Qté</Label><Input id={`quantity-${part.key}`} type="number" min="1" value={part.quantity} onChange={(event) => updateUsedPart(part.key, { quantity: Math.max(1, Number(event.target.value)) })}/></div><button type="button" className="remove-part" aria-label="Supprimer la pièce" disabled={usedParts.length === 1} onClick={() => setUsedParts((items) => items.filter((item) => item.key !== part.key))}><Trash2 size={17}/></button></div>)}</div><Button type="button" variant="outline" className="add-part-button" onClick={addPartRow}><Plus size={17}/> Ajouter une autre pièce</Button></fieldset>
            <fieldset><legend>Prise en charge</legend><div className="form-grid three"><div><Label htmlFor="price">Prix convenu (DA) *</Label><Input id="price" name="price" required min="0" type="number" placeholder="0"/></div><div><Label htmlFor="deposit">Versement (DA)</Label><Input id="deposit" name="deposit" min="0" type="number" defaultValue="0"/></div><div><Label htmlFor="technician">Technicien</Label><select id="technician" name="technician"><option>Non assigné</option><option>Mohamed</option><option>Technicien 1</option></select></div></div><div><Label htmlFor="notes">Paroles du client / notes</Label><Textarea id="notes" name="notes" placeholder="Détails donnés par le client, état extérieur, code ou accessoires reçus…"/></div></fieldset>
            <div className="form-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Annuler</Button><Button className="primary-action" type="submit" disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer la fiche"}</Button></div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(basketRepair)} onOpenChange={(next) => { if (!next) { setBasketRepair(null); setBasketProductId(null); setBasketQuantity(1); } }}>
        <DialogContent className="parts-basket-dialog sm:max-w-[860px]">
          <DialogHeader><DialogTitle>Panier pièces · {basketRepair?.ticketNumber}</DialogTitle><DialogDescription>Réservez, consommez ou libérez les pièces liées à cet appareil.</DialogDescription></DialogHeader>
          {basketRepair && <div className="basket-body">
            <div className={`basket-context ${basketRepair.shop === "MidouGSM" ? "midou" : "prophone"}`}><ShoppingBasket size={19}/><div><small>APPAREIL</small><b>{basketRepair.brand} {basketRepair.model}</b></div><span><ShieldCheck size={14}/> Stock {basketRepair.shop}</span></div>
            <div className="basket-add"><div><Label>Produit</Label><select value={basketProductId ?? ""} onChange={(event) => setBasketProductId(Number(event.target.value) || null)}><option value="">Rechercher / choisir un produit…</option>{products.map((product) => <option key={product.id} value={product.id}>{product.sku} · {product.name} · disponible {product.stock[basketRepair.shop as "ProPhone" | "MidouGSM"]}</option>)}</select></div><div><Label>Qté</Label><Input type="number" min="1" value={basketQuantity} onChange={(event) => setBasketQuantity(Math.max(1, Number(event.target.value)))}/></div><Button onClick={addBasketPart} disabled={basketSaving || !basketProductId}><Plus size={17}/> Ajouter</Button></div>
            <div className="basket-list">{basketRepair.usedParts?.length ? basketRepair.usedParts.map((part) => <article key={part.id} className={part.status === "Non utilisée" ? "unused" : ""}><div className="basket-product"><b>{part.itemName}</b><small>{part.quality || "Qualité produit"} · Qté {part.quantity} · {part.flow}</small></div><span className={`part-status ${part.status === "Réservée" || part.status === "Reçue" ? "reserved" : part.status === "Utilisée" ? "used" : part.status === "À commander" ? "order" : part.status === "Non utilisée" ? "unused" : "requested"}`}>{part.status}</span><div className="basket-actions">{["Réservée", "Reçue"].includes(part.status) && <Button size="sm" onClick={() => changePartStatus(part, "Utilisée")} disabled={basketSaving}><Check size={15}/> Utilisée</Button>}{part.status === "À commander" && <Button size="sm" variant="outline" onClick={() => changePartStatus(part, "Reçue")} disabled={basketSaving}>Marquer reçue</Button>}{part.status !== "Non utilisée" && <Button size="sm" variant="outline" className="unused-button" onClick={() => changePartStatus(part, "Non utilisée")} disabled={basketSaving}><X size={15}/> Non utilisée</Button>}</div></article>) : <div className="basket-empty"><ShoppingBasket/><b>Aucune pièce prévue</b><span>Ajoutez une pièce depuis le catalogue produits.</span></div>}</div>
            <div className="basket-note"><ShieldCheck size={17}/><span><b>Traçabilité automatique :</b> Réservée ne diminue pas le stock physique. Utilisée crée une sortie réparation. Non utilisée libère la réservation ou crée un retour si elle avait déjà été consommée.</span></div>
          </div>}
        </DialogContent>
      </Dialog>

      <Dialog open={purchaseOpen} onOpenChange={(next) => { setPurchaseOpen(next); if (!next) resetPurchase(); }}>
        <DialogContent className="invoice-dialog sm:max-w-[1080px]">
          <DialogHeader><DialogTitle>Nouvel achat depuis une facture</DialogTitle><DialogDescription>Importez l’original, vérifiez les données reconnues puis ajoutez le prix de vente.</DialogDescription></DialogHeader>
          <div className={`invoice-shop-context ${purchaseShop === "MidouGSM" ? "midou" : "prophone"}`}><Store size={17}/><span>Achat destiné à <b>{purchaseShop}</b></span><em><ShieldCheck size={13}/> Stock indépendant</em></div>
          <div className="invoice-steps"><span className="done"><b>1</b>Document original</span><i/><span className={purchaseStep === "review" ? "done" : ""}><b>2</b>Analyse & vérification</span><i/><span><b>3</b>Entrée en stock</span></div>
          <div className="invoice-workspace">
            <section className="original-pane">
              <div className="pane-title"><div><small>DOCUMENT ORIGINAL</small><h3>Facture du fournisseur</h3></div>{invoiceFile && <span className="original-saved"><Archive size={14}/> Original conservé</span>}</div>
              {!invoiceFile ? <div className="upload-zone"><div className="upload-icon"><Upload/></div><h4>Ajouter une facture</h4><p>PDF, JPG, PNG — imprimée ou écrite à la main</p><div className="upload-actions"><label className="upload-button"><Upload size={17}/> Choisir un fichier<input type="file" accept="application/pdf,image/*" onChange={(e) => selectInvoice(e.target.files?.[0])}/></label><label className="camera-button"><Camera size={17}/> Prendre une photo<input type="file" accept="image/*" capture="environment" onChange={(e) => selectInvoice(e.target.files?.[0])}/></label></div></div> : <div className="document-preview">{invoiceFile.type.startsWith("image/") ? <img src={invoiceFile.url} alt="Facture importée"/> : <div className="pdf-preview"><FileText size={50}/><b>{invoiceFile.name}</b><small>Document PDF prêt pour l’analyse</small></div>}<div className="preview-footer"><span><FileText size={15}/>{invoiceFile.name}</span><label>Remplacer<input type="file" accept="application/pdf,image/*" onChange={(e) => selectInvoice(e.target.files?.[0])}/></label></div></div>}
              {invoiceFile && purchaseStep === "upload" && <Button className="analyze-button" onClick={analyzeInvoice} disabled={analyzing}><ScanLine size={18}/>{analyzing ? "Analyse en cours…" : "Analyser la facture"}</Button>}
            </section>

            <section className="digital-pane">
              <div className="pane-title"><div><small>FICHE NUMÉRIQUE LIÉE</small><h3>Données de l’achat</h3></div>{purchaseStep === "review" && <span className="review-needed">3 lignes détectées</span>}</div>
              {purchaseStep === "upload" ? <div className="waiting-analysis"><ScanLine/><h4>En attente d’analyse</h4><p>Les produits, quantités et prix d’achat apparaîtront ici pour comparaison avec l’original.</p></div> : <div className="review-form">
                <div className="form-grid two"><div><Label>Fournisseur *</Label><Input value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="Écrire ou ajouter…"/></div><div><Label>N° facture</Label><Input value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)}/></div></div>
                <div className="confidence-legend"><span><i className="high"/>Lecture claire</span><span><i className="medium"/>À vérifier</span><span><i className="low"/>Lecture incertaine</span></div>
                <div className="lines-table"><div className="line-head"><span>Produit</span><span>Qté</span><span>Achat</span><span>Prix de vente</span></div>{purchaseLines.map((line) => <div className={`purchase-line confidence-${line.confidence}`} key={line.id}><Input value={line.item} onChange={(e) => updatePurchaseLine(line.id, { item: e.target.value })}/><Input type="number" min="1" value={line.quantity} onChange={(e) => updatePurchaseLine(line.id, { quantity: Number(e.target.value) })}/><div className="money-input"><Input type="number" value={line.purchasePrice} onChange={(e) => updatePurchaseLine(line.id, { purchasePrice: Number(e.target.value) })}/><span>DA</span></div><div className="money-input sale"><Input type="number" min="0" placeholder="À saisir" value={line.salePrice || ""} onChange={(e) => updatePurchaseLine(line.id, { salePrice: Number(e.target.value) })}/><span>DA</span></div></div>)}</div>
                <div className="purchase-total"><span>Total d’achat détecté</span><strong>{money(purchaseLines.reduce((sum, line) => sum + line.quantity * line.purchasePrice, 0))}</strong></div>
              </div>}
            </section>
          </div>
          <div className="invoice-actions"><Button variant="outline" onClick={() => setPurchaseOpen(false)}>Annuler</Button><Button className="primary-action" disabled={purchaseStep !== "review" || !purchaseLines.length} onClick={confirmPurchase}><Check size={17}/> Confirmer et préparer le stock</Button></div>
        </DialogContent>
      </Dialog>
      <Toaster richColors position="top-center"/>
    </div>
  );
}
