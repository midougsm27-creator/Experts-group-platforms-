CREATE TABLE `repair_parts` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`repair_id` integer NOT NULL,
	`item_name` text NOT NULL,
	`quality` text DEFAULT '' NOT NULL,
	`quantity` integer DEFAULT 1 NOT NULL,
	`flow` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`repair_id`) REFERENCES `repairs`(`id`) ON UPDATE no action ON DELETE no action
);
