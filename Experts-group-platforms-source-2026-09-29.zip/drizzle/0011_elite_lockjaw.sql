CREATE TABLE `shop_settings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`shop` text NOT NULL,
	`negative_stock_policy` text DEFAULT 'manager_reason' NOT NULL,
	`reserve_repair_parts` integer DEFAULT true NOT NULL,
	`low_stock_threshold` integer DEFAULT 3 NOT NULL,
	`receipt_paper` text DEFAULT 'A4' NOT NULL,
	`show_sku` integer DEFAULT true NOT NULL,
	`show_barcode` integer DEFAULT true NOT NULL,
	`invoice_footer` text DEFAULT 'Merci pour votre confiance' NOT NULL,
	`updated_at` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `shop_settings_shop_unique` ON `shop_settings` (`shop`);--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `product_id` integer;--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `shop` text DEFAULT 'ProPhone' NOT NULL;--> statement-breakpoint
UPDATE `repair_parts` SET `shop` = (SELECT `shop` FROM `repairs` WHERE `repairs`.`id` = `repair_parts`.`repair_id`);--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `reserved_quantity` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `unit_price` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `status` text DEFAULT 'Demandée' NOT NULL;--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `updated_at` text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_repair_parts_product_shop` ON `repair_parts` (`product_id`,`shop`);--> statement-breakpoint
CREATE INDEX `idx_repair_parts_status_shop` ON `repair_parts` (`status`,`shop`);
