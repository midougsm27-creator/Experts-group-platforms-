ALTER TABLE `purchases` ADD `supplier_id` integer REFERENCES suppliers(id);--> statement-breakpoint
CREATE INDEX `idx_purchases_supplier_id` ON `purchases` (`supplier_id`);