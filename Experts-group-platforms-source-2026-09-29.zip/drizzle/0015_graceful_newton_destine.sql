CREATE TABLE `stock_requests` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`product_id` integer NOT NULL,
	`shop` text NOT NULL,
	`quantity` integer DEFAULT 1 NOT NULL,
	`received_quantity` integer DEFAULT 0 NOT NULL,
	`supplier_status` text DEFAULT 'En attente' NOT NULL,
	`order_status` text DEFAULT 'À commander' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_stock_requests_shop_status` ON `stock_requests` (`shop`,`order_status`);--> statement-breakpoint
CREATE INDEX `idx_stock_requests_product_shop` ON `stock_requests` (`product_id`,`shop`);--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `received_quantity` integer DEFAULT 0 NOT NULL;