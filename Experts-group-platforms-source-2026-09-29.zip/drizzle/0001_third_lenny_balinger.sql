CREATE TABLE `catalog_entries` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`category` text NOT NULL,
	`name` text NOT NULL,
	`parent` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
ALTER TABLE `repairs` ADD `device_type` text DEFAULT 'Smartphone' NOT NULL;--> statement-breakpoint
ALTER TABLE `repairs` ADD `part_quality` text DEFAULT '' NOT NULL;