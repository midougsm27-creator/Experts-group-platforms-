CREATE TABLE `purchase_lines` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`purchase_id` integer NOT NULL,
	`product_id` integer NOT NULL,
	`product_name` text NOT NULL,
	`sku` text NOT NULL,
	`quantity` integer NOT NULL,
	`purchase_price` integer NOT NULL,
	`sale_price` integer DEFAULT 0 NOT NULL,
	`line_total` integer NOT NULL,
	FOREIGN KEY (`purchase_id`) REFERENCES `purchases`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_purchase_lines_purchase` ON `purchase_lines` (`purchase_id`);--> statement-breakpoint
CREATE TABLE `purchases` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`receipt_number` text NOT NULL,
	`supplier` text NOT NULL,
	`supplier_invoice` text DEFAULT '' NOT NULL,
	`shop` text NOT NULL,
	`gross_amount` integer NOT NULL,
	`discount_amount` integer DEFAULT 0 NOT NULL,
	`net_amount` integer NOT NULL,
	`paid_amount` integer DEFAULT 0 NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'Confirmé' NOT NULL,
	`document_key` text DEFAULT '' NOT NULL,
	`document_name` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `purchases_receipt_number_unique` ON `purchases` (`receipt_number`);--> statement-breakpoint
CREATE INDEX `idx_purchases_shop_created` ON `purchases` (`shop`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_purchases_supplier` ON `purchases` (`supplier`);--> statement-breakpoint
CREATE TABLE `sale_lines` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`sale_id` integer NOT NULL,
	`product_id` integer NOT NULL,
	`product_name` text NOT NULL,
	`sku` text NOT NULL,
	`quantity` integer NOT NULL,
	`unit_price` integer NOT NULL,
	`line_total` integer NOT NULL,
	FOREIGN KEY (`sale_id`) REFERENCES `sales`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_sale_lines_sale` ON `sale_lines` (`sale_id`);--> statement-breakpoint
CREATE TABLE `sales` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`receipt_number` text NOT NULL,
	`shop` text NOT NULL,
	`customer_name` text DEFAULT 'VENTE-COMPTOIR' NOT NULL,
	`gross_amount` integer NOT NULL,
	`discount_amount` integer DEFAULT 0 NOT NULL,
	`net_amount` integer NOT NULL,
	`paid_amount` integer DEFAULT 0 NOT NULL,
	`cashbox_id` integer,
	`status` text DEFAULT 'Validée' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`cashbox_id`) REFERENCES `cashboxes`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `sales_receipt_number_unique` ON `sales` (`receipt_number`);--> statement-breakpoint
CREATE INDEX `idx_sales_shop_created` ON `sales` (`shop`,`created_at`);