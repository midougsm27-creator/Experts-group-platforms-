CREATE TABLE `product_taxonomy` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`category` text NOT NULL,
	`name` text NOT NULL,
	`abbreviation` text NOT NULL,
	`parent` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `product_taxonomy_category_parent_name_unique` ON `product_taxonomy` (`category`,`parent`,`name`);--> statement-breakpoint
CREATE INDEX `idx_product_taxonomy_category_parent` ON `product_taxonomy` (`category`,`parent`);--> statement-breakpoint
PRAGMA optimize;
