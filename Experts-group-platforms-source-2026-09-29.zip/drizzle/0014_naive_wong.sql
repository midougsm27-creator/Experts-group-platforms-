ALTER TABLE `purchases` ADD `settlement_type` text DEFAULT 'À terme' NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `cashbox_id` integer REFERENCES cashboxes(id);--> statement-breakpoint
CREATE INDEX `idx_purchases_cashbox_id` ON `purchases` (`cashbox_id`);