DROP INDEX `customers_phone_unique`;--> statement-breakpoint
ALTER TABLE `customers` ADD `shop` text DEFAULT 'ProPhone' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `customers_shop_phone_unique` ON `customers` (`shop`,`phone`);--> statement-breakpoint
CREATE INDEX `idx_customers_shop` ON `customers` (`shop`);--> statement-breakpoint
CREATE INDEX `idx_repairs_shop` ON `repairs` (`shop`);--> statement-breakpoint
PRAGMA optimize;
