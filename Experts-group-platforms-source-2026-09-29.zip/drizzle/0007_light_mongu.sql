CREATE TABLE `cash_movements` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`cashbox_id` integer NOT NULL,
	`shop` text NOT NULL,
	`direction` text NOT NULL,
	`movement_type` text NOT NULL,
	`amount` integer NOT NULL,
	`reason` text NOT NULL,
	`reference` text DEFAULT '' NOT NULL,
	`transfer_group` text DEFAULT '' NOT NULL,
	`related_cashbox_id` integer,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`cashbox_id`) REFERENCES `cashboxes`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_cash_movements_cashbox` ON `cash_movements` (`cashbox_id`);--> statement-breakpoint
CREATE INDEX `idx_cash_movements_shop` ON `cash_movements` (`shop`);--> statement-breakpoint
CREATE INDEX `idx_cash_movements_transfer` ON `cash_movements` (`transfer_group`);--> statement-breakpoint
CREATE TABLE `cashboxes` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`shop` text NOT NULL,
	`name` text NOT NULL,
	`type` text DEFAULT 'Caisse principale' NOT NULL,
	`opening_balance` integer DEFAULT 0 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `cashboxes_shop_name_unique` ON `cashboxes` (`shop`,`name`);--> statement-breakpoint
CREATE INDEX `idx_cashboxes_shop` ON `cashboxes` (`shop`);--> statement-breakpoint
CREATE TABLE `products` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`sku` text NOT NULL,
	`barcode` text NOT NULL,
	`name` text NOT NULL,
	`family` text NOT NULL,
	`subfamily` text DEFAULT '' NOT NULL,
	`brand` text DEFAULT '' NOT NULL,
	`model` text DEFAULT '' NOT NULL,
	`compatibility` text DEFAULT '' NOT NULL,
	`quality` text DEFAULT '' NOT NULL,
	`color` text DEFAULT '' NOT NULL,
	`capacity` text DEFAULT '' NOT NULL,
	`unit` text DEFAULT 'Pièce' NOT NULL,
	`warranty` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `products_sku_unique` ON `products` (`sku`);--> statement-breakpoint
CREATE UNIQUE INDEX `products_barcode_unique` ON `products` (`barcode`);--> statement-breakpoint
CREATE INDEX `idx_products_family` ON `products` (`family`);--> statement-breakpoint
CREATE INDEX `idx_products_brand` ON `products` (`brand`);--> statement-breakpoint
CREATE TABLE `stock_movements` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`product_id` integer NOT NULL,
	`shop` text NOT NULL,
	`location` text DEFAULT 'Magasin' NOT NULL,
	`movement_type` text NOT NULL,
	`quantity` integer NOT NULL,
	`purchase_price` integer DEFAULT 0 NOT NULL,
	`unit_cost` integer DEFAULT 0 NOT NULL,
	`sale_price` integer DEFAULT 0 NOT NULL,
	`reference` text DEFAULT '' NOT NULL,
	`repair_id` integer,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`repair_id`) REFERENCES `repairs`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_stock_movements_product_shop` ON `stock_movements` (`product_id`,`shop`);--> statement-breakpoint
CREATE INDEX `idx_stock_movements_repair` ON `stock_movements` (`repair_id`);--> statement-breakpoint
PRAGMA optimize;
