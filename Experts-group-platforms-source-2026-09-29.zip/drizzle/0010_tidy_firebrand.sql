CREATE TABLE `customer_payments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`customer_id` integer NOT NULL,
	`shop` text NOT NULL,
	`amount` integer NOT NULL,
	`cashbox_id` integer,
	`method` text DEFAULT 'Espèces' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_customer_payments_customer` ON `customer_payments` (`customer_id`);--> statement-breakpoint
CREATE INDEX `idx_customer_payments_shop` ON `customer_payments` (`shop`);--> statement-breakpoint
CREATE TABLE `supplier_payments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`supplier_id` integer NOT NULL,
	`shop` text NOT NULL,
	`amount` integer NOT NULL,
	`cashbox_id` integer,
	`method` text DEFAULT 'Espèces' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_supplier_payments_supplier` ON `supplier_payments` (`supplier_id`);--> statement-breakpoint
CREATE INDEX `idx_supplier_payments_shop` ON `supplier_payments` (`shop`);--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`shop` text DEFAULT 'ProPhone' NOT NULL,
	`supplier_type` text DEFAULT 'Accessoires' NOT NULL,
	`origin` text DEFAULT 'Algérien' NOT NULL,
	`city` text DEFAULT '' NOT NULL,
	`currency` text DEFAULT 'DZD' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `suppliers_shop_name_unique` ON `suppliers` (`shop`,`name`);--> statement-breakpoint
CREATE INDEX `idx_suppliers_shop_type` ON `suppliers` (`shop`,`supplier_type`);--> statement-breakpoint
CREATE INDEX `idx_suppliers_shop_origin` ON `suppliers` (`shop`,`origin`);--> statement-breakpoint
ALTER TABLE `customers` ADD `email` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `address` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `customer_type` text DEFAULT 'Détail' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `source` text DEFAULT 'Magasin' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `notes` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `active` integer DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `updated_at` text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_customers_shop_type` ON `customers` (`shop`,`customer_type`);
