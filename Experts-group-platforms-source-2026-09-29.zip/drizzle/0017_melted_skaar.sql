ALTER TABLE `products` ADD `manufacturer` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `source_reference` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `purchase_price` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `pv1` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `pv2` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `pv3` integer DEFAULT 0 NOT NULL;