ALTER TABLE `repair_parts` ADD `supplier_status` text DEFAULT 'En attente' NOT NULL;--> statement-breakpoint
ALTER TABLE `repair_parts` ADD `order_status` text DEFAULT 'À commander' NOT NULL;