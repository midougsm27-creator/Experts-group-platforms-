import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const customers = sqliteTable("customers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  shop: text("shop").notNull().default("ProPhone"),
  email: text("email").notNull().default(""),
  address: text("address").notNull().default(""),
  customerType: text("customer_type").notNull().default("Détail"),
  source: text("source").notNull().default("Magasin"),
  notes: text("notes").notNull().default(""),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(""),
}, (table) => [
  uniqueIndex("customers_shop_phone_unique").on(table.shop, table.phone),
  index("idx_customers_shop").on(table.shop),
  index("idx_customers_shop_type").on(table.shop, table.customerType),
]);

export const customerPayments = sqliteTable("customer_payments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  shop: text("shop").notNull(),
  amount: integer("amount").notNull(),
  cashboxId: integer("cashbox_id"),
  method: text("method").notNull().default("Espèces"),
  notes: text("notes").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_customer_payments_customer").on(table.customerId),
  index("idx_customer_payments_shop").on(table.shop),
]);

export const suppliers = sqliteTable("suppliers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  phone: text("phone").notNull().default(""),
  email: text("email").notNull().default(""),
  shop: text("shop").notNull().default("ProPhone"),
  supplierType: text("supplier_type").notNull().default("Accessoires"),
  origin: text("origin").notNull().default("Algérien"),
  city: text("city").notNull().default(""),
  currency: text("currency").notNull().default("DZD"),
  notes: text("notes").notNull().default(""),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("suppliers_shop_name_unique").on(table.shop, table.name),
  index("idx_suppliers_shop_type").on(table.shop, table.supplierType),
  index("idx_suppliers_shop_origin").on(table.shop, table.origin),
]);

export const supplierPayments = sqliteTable("supplier_payments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  supplierId: integer("supplier_id").notNull().references(() => suppliers.id),
  shop: text("shop").notNull(),
  amount: integer("amount").notNull(),
  cashboxId: integer("cashbox_id"),
  method: text("method").notNull().default("Espèces"),
  notes: text("notes").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_supplier_payments_supplier").on(table.supplierId),
  index("idx_supplier_payments_shop").on(table.shop),
]);

export const repairs = sqliteTable("repairs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ticketNumber: text("ticket_number").notNull().unique(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  shop: text("shop").notNull().default("ProPhone"),
  deviceType: text("device_type").notNull().default("Smartphone"),
  brand: text("brand").notNull(),
  model: text("model").notNull(),
  storageLocation: text("storage_location").notNull().default("Comptoir réception"),
  partQuality: text("part_quality").notNull().default(""),
  issue: text("issue").notNull(),
  price: integer("price").notNull().default(0),
  deposit: integer("deposit").notNull().default(0),
  technician: text("technician").notNull().default("Non assigné"),
  status: text("status").notNull().default("En attente"),
  notes: text("notes").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("idx_repairs_shop").on(table.shop)]);

export const catalogEntries = sqliteTable("catalog_entries", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  category: text("category").notNull(),
  name: text("name").notNull(),
  parent: text("parent").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("catalog_entries_category_parent_name_unique").on(table.category, table.parent, table.name),
]);

export const repairParts = sqliteTable("repair_parts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  repairId: integer("repair_id").notNull().references(() => repairs.id),
  productId: integer("product_id"),
  shop: text("shop").notNull().default("ProPhone"),
  itemName: text("item_name").notNull(),
  quality: text("quality").notNull().default(""),
  quantity: integer("quantity").notNull().default(1),
  receivedQuantity: integer("received_quantity").notNull().default(0),
  reservedQuantity: integer("reserved_quantity").notNull().default(0),
  unitPrice: integer("unit_price").notNull().default(0),
  status: text("status").notNull().default("Demandée"),
  flow: text("flow").notNull().default("Stock local"),
  supplierStatus: text("supplier_status").notNull().default("En attente"),
  orderStatus: text("order_status").notNull().default("À commander"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(""),
}, (table) => [
  index("idx_repair_parts_repair_id").on(table.repairId),
  index("idx_repair_parts_product_shop").on(table.productId, table.shop),
  index("idx_repair_parts_status_shop").on(table.status, table.shop),
]);

export const stockRequests = sqliteTable("stock_requests", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  productId: integer("product_id").notNull(),
  shop: text("shop").notNull(),
  quantity: integer("quantity").notNull().default(1),
  receivedQuantity: integer("received_quantity").notNull().default(0),
  supplierStatus: text("supplier_status").notNull().default("En attente"),
  orderStatus: text("order_status").notNull().default("À commander"),
  notes: text("notes").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(""),
}, (table) => [
  index("idx_stock_requests_shop_status").on(table.shop, table.orderStatus),
  index("idx_stock_requests_product_shop").on(table.productId, table.shop),
]);

export const appUsers = sqliteTable("app_users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  externalUserId: text("external_user_id"),
  email: text("email").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("Employé"),
  shops: text("shops").notNull().default("[]"),
  permissions: text("permissions").notNull().default("[]"),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  protected: integer("protected", { mode: "boolean" }).notNull().default(false),
  lastSeenAt: text("last_seen_at").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("app_users_email_unique").on(table.email),
  uniqueIndex("app_users_external_user_id_unique").on(table.externalUserId),
  index("idx_app_users_active").on(table.active),
]);

export const auditLogs = sqliteTable("audit_logs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => appUsers.id),
  userEmail: text("user_email").notNull(),
  shop: text("shop").notNull().default(""),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull().default(""),
  details: text("details").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_audit_logs_user_created").on(table.userId, table.createdAt),
  index("idx_audit_logs_shop_created").on(table.shop, table.createdAt),
]);

export const shopSettings = sqliteTable("shop_settings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  shop: text("shop").notNull().unique(),
  negativeStockPolicy: text("negative_stock_policy").notNull().default("manager_reason"),
  reserveRepairParts: integer("reserve_repair_parts", { mode: "boolean" }).notNull().default(true),
  lowStockThreshold: integer("low_stock_threshold").notNull().default(3),
  receiptPaper: text("receipt_paper").notNull().default("A4"),
  showSku: integer("show_sku", { mode: "boolean" }).notNull().default(true),
  showBarcode: integer("show_barcode", { mode: "boolean" }).notNull().default(true),
  invoiceFooter: text("invoice_footer").notNull().default("Merci pour votre confiance"),
  updatedAt: text("updated_at").notNull().default(""),
}, (table) => [uniqueIndex("shop_settings_shop_unique").on(table.shop)]);

export const cashboxes = sqliteTable("cashboxes", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  shop: text("shop").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull().default("Caisse principale"),
  openingBalance: integer("opening_balance").notNull().default(0),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("cashboxes_shop_name_unique").on(table.shop, table.name),
  index("idx_cashboxes_shop").on(table.shop),
]);

export const cashMovements = sqliteTable("cash_movements", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  cashboxId: integer("cashbox_id").notNull().references(() => cashboxes.id),
  shop: text("shop").notNull(),
  direction: text("direction").notNull(),
  movementType: text("movement_type").notNull(),
  amount: integer("amount").notNull(),
  reason: text("reason").notNull(),
  reference: text("reference").notNull().default(""),
  transferGroup: text("transfer_group").notNull().default(""),
  relatedCashboxId: integer("related_cashbox_id"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_cash_movements_cashbox").on(table.cashboxId),
  index("idx_cash_movements_shop").on(table.shop),
  index("idx_cash_movements_transfer").on(table.transferGroup),
]);

export const products = sqliteTable("products", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  sku: text("sku").notNull().unique(),
  barcode: text("barcode").notNull().unique(),
  name: text("name").notNull(),
  family: text("family").notNull(),
  subfamily: text("subfamily").notNull().default(""),
  brand: text("brand").notNull().default(""),
  model: text("model").notNull().default(""),
  compatibility: text("compatibility").notNull().default(""),
  quality: text("quality").notNull().default(""),
  manufacturer: text("manufacturer").notNull().default(""),
  color: text("color").notNull().default(""),
  sourceReference: text("source_reference").notNull().default(""),
  purchasePrice: integer("purchase_price").notNull().default(0),
  pv1: integer("pv1").notNull().default(0),
  pv2: integer("pv2").notNull().default(0),
  pv3: integer("pv3").notNull().default(0),
  capacity: text("capacity").notNull().default(""),
  unit: text("unit").notNull().default("Pièce"),
  warranty: text("warranty").notNull().default(""),
  notes: text("notes").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_products_family").on(table.family),
  index("idx_products_brand").on(table.brand),
]);

export const productTaxonomy = sqliteTable("product_taxonomy", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  category: text("category").notNull(),
  name: text("name").notNull(),
  abbreviation: text("abbreviation").notNull(),
  parent: text("parent").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("product_taxonomy_category_parent_name_unique").on(table.category, table.parent, table.name),
  index("idx_product_taxonomy_category_parent").on(table.category, table.parent),
]);

export const stockMovements = sqliteTable("stock_movements", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  productId: integer("product_id").notNull().references(() => products.id),
  shop: text("shop").notNull(),
  location: text("location").notNull().default("Magasin"),
  movementType: text("movement_type").notNull(),
  quantity: integer("quantity").notNull(),
  purchasePrice: integer("purchase_price").notNull().default(0),
  unitCost: integer("unit_cost").notNull().default(0),
  salePrice: integer("sale_price").notNull().default(0),
  reference: text("reference").notNull().default(""),
  repairId: integer("repair_id").references(() => repairs.id),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_stock_movements_product_shop").on(table.productId, table.shop),
  index("idx_stock_movements_repair").on(table.repairId),
]);

export const sales = sqliteTable("sales", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  receiptNumber: text("receipt_number").notNull().unique(),
  shop: text("shop").notNull(),
  customerName: text("customer_name").notNull().default("VENTE-COMPTOIR"),
  grossAmount: integer("gross_amount").notNull(),
  discountAmount: integer("discount_amount").notNull().default(0),
  netAmount: integer("net_amount").notNull(),
  paidAmount: integer("paid_amount").notNull().default(0),
  cashboxId: integer("cashbox_id").references(() => cashboxes.id),
  status: text("status").notNull().default("Validée"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_sales_shop_created").on(table.shop, table.createdAt),
]);

export const saleLines = sqliteTable("sale_lines", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  saleId: integer("sale_id").notNull().references(() => sales.id),
  productId: integer("product_id").notNull().references(() => products.id),
  productName: text("product_name").notNull(),
  sku: text("sku").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: integer("unit_price").notNull(),
  lineTotal: integer("line_total").notNull(),
}, (table) => [index("idx_sale_lines_sale").on(table.saleId)]);

export const purchases = sqliteTable("purchases", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  receiptNumber: text("receipt_number").notNull().unique(),
  supplierId: integer("supplier_id").references(() => suppliers.id),
  supplier: text("supplier").notNull(),
  supplierInvoice: text("supplier_invoice").notNull().default(""),
  shop: text("shop").notNull(),
  settlementType: text("settlement_type").notNull().default("À terme"),
  cashboxId: integer("cashbox_id").references(() => cashboxes.id),
  grossAmount: integer("gross_amount").notNull(),
  discountAmount: integer("discount_amount").notNull().default(0),
  netAmount: integer("net_amount").notNull(),
  paidAmount: integer("paid_amount").notNull().default(0),
  notes: text("notes").notNull().default(""),
  status: text("status").notNull().default("Confirmé"),
  documentKey: text("document_key").notNull().default(""),
  documentName: text("document_name").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_purchases_shop_created").on(table.shop, table.createdAt),
  index("idx_purchases_supplier_id").on(table.supplierId),
  index("idx_purchases_cashbox_id").on(table.cashboxId),
  index("idx_purchases_supplier").on(table.supplier),
]);

export const purchaseLines = sqliteTable("purchase_lines", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  purchaseId: integer("purchase_id").notNull().references(() => purchases.id),
  productId: integer("product_id").notNull().references(() => products.id),
  productName: text("product_name").notNull(),
  sku: text("sku").notNull(),
  quantity: integer("quantity").notNull(),
  purchasePrice: integer("purchase_price").notNull(),
  salePrice: integer("sale_price").notNull().default(0),
  lineTotal: integer("line_total").notNull(),
}, (table) => [index("idx_purchase_lines_purchase").on(table.purchaseId)]);
